<?php
date_default_timezone_set('Europe/Paris');

$maintenant = date('Y-m-d H:i:s');
$en_cours = ($maintenant >= $article['date_debut_enchere'] && $maintenant <= $article['date_fin_enchere']);

if (
    $en_cours &&
    isset($_POST['placer_enchere']) &&
    isset($_POST['prix_max']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id']
) {
    $prix_max = floatval($_POST['prix_max']);
    $acheteur_id = intval($_SESSION['user_id']);
    $article_id = intval($article['id']);
    $prix_actuel = floatval($article['prix_actuel']);
    if ($prix_max < $prix_actuel + 1) {
        $enchere_message = "Votre enchère maximum doit être supérieure au prix actuel.";
    } else {
        // Cherche si déjà enchère
        $sql = "SELECT id FROM Enchere WHERE article_id=$article_id AND acheteur_id=$acheteur_id";
        $result = mysqli_query($db_handle, $sql);
        if ($result && mysqli_num_rows($result) > 0) {
            $sql = "UPDATE Enchere SET prix_max=$prix_max, date_enchere=NOW() WHERE article_id=$article_id AND acheteur_id=$acheteur_id";
            mysqli_query($db_handle, $sql);
            $enchere_message = "Votre enchère maximum a été modifiée.";
        } else {
            $sql = "INSERT INTO Enchere (article_id, acheteur_id, prix_max, date_enchere)
                    VALUES ($article_id, $acheteur_id, $prix_max, NOW())";
            mysqli_query($db_handle, $sql);
            $enchere_message = "Votre enchère a bien été enregistrée.";
        }
        // Notif vendeur
        $vendeur_id = $article['vendeur_id'];
        $acheteur_nom = $_SESSION['user_prenom']." ".$_SESSION['user_nom'];
        $contenu = "Nouvelle enchère de $acheteur_nom sur l'article : ".$article['titre']." (offre max : ".number_format($prix_max,2,',',' ')." €)";
        $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
        $date_notif = date('Y-m-d H:i:s');
        $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
              VALUES ($vendeur_id, '$contenu_sql', '$date_notif', $article_id)";
        mysqli_query($db_handle, $sql_notif);

        // Proxy-bid: maj prix actuel
        $sql = "SELECT prix_max FROM Enchere WHERE article_id=$article_id ORDER BY prix_max DESC, date_enchere ASC";
        $result = mysqli_query($db_handle, $sql);
        $prix1 = $prix2 = $article['prix_initial'];
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $prix1 = $row['prix_max'];
            if (mysqli_num_rows($result) > 1) {
                $row2 = mysqli_fetch_assoc($result);
                $prix2 = $row2['prix_max'];
            }
        }
        $nouveau_prix = ($prix1 && $prix2 && $prix2 + 1 > $article['prix_initial']) ? $prix2 + 1 : max($article['prix_initial'], $prix1);
        $sql = "UPDATE Article SET prix_actuel=$nouveau_prix WHERE id=$article_id";
        mysqli_query($db_handle, $sql);
        // Recharge l'article si besoin (optionnel ici)
    }
}
?>

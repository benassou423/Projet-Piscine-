<?php
if (
    isset($_POST['achat_direct']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id'] &&
    $article['statut'] == 'disponible'
) {
    $acheteur_id = intval($_SESSION['user_id']);
    $article_id = intval($article['id']);

    // Chercher ou créer le panier de l'utilisateur
    $sql = "SELECT id FROM Panier WHERE acheteur_id=$acheteur_id";
    $result = mysqli_query($db_handle, $sql);
    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $panier_id = $row['id'];
    } else {
        $sql = "INSERT INTO Panier (acheteur_id, date_creation) VALUES ($acheteur_id, NOW())";
        mysqli_query($db_handle, $sql);
        $panier_id = mysqli_insert_id($db_handle);
    }
    // Ajouter l'article au panier (si pas déjà présent)
    $sql = "SELECT * FROM ArticlePanier WHERE panier_id=$panier_id AND article_id=$article_id";
    $result = mysqli_query($db_handle, $sql);
    if (!$result || mysqli_num_rows($result) == 0) {
        $sql = "INSERT INTO ArticlePanier (panier_id, article_id, mode_achat)
                VALUES ($panier_id, $article_id, 'immediat')";
        mysqli_query($db_handle, $sql);
    }
    header("Location: panier.php");
    exit();
}
?>

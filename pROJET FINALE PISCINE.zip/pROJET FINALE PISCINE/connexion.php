<?php
session_start();
$database = "agorafixe";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $db_found) {
    $email = mysqli_real_escape_string($db_handle, trim($_POST['email']));
    $password = $_POST['password'];

    // Vérifier si l'utilisateur existe
    $sql = "SELECT id, nom, prenom, email, mot_de_passe, role FROM Utilisateur WHERE email = '$email'";
    $result = mysqli_query($db_handle, $sql);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['mot_de_passe'])) {
            // Connexion réussie : on stocke l'utilisateur en session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nom'] = $user['nom'];
            $_SESSION['user_prenom'] = $user['prenom'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_email'] = $user['email'];
            // Redirection vers accueil (ou page personnalisée)
            header("Location: index.php");
            exit();
        } else {
            $message = "Mot de passe incorrect.";
        }
    } else {
        $message = "Utilisateur non trouvé.";
    }
} elseif (!$db_found) {
    $message = "Base de données non trouvée.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Agora Francia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Connexion</h2>
    <?php if ($message): ?>
        <div class="alert alert-danger"><?= $message ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="mb-3">
            <input required name="email" type="email" class="form-control" placeholder="Email">
        </div>
        <div class="mb-3">
            <input required name="password" type="password" class="form-control" placeholder="Mot de passe">
        </div>
        <button type="submit" class="btn btn-primary w-100">Se connecter</button>
    </form>
    <p class="mt-4 text-center">Pas encore inscrit ? <a href="inscription.php">Créer un compte</a></p>
</div>
<?php include 'footer.php'; ?>
</body>
</html>

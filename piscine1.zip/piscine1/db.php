<?php
$db_handle = mysqli_connect('localhost', 'root', 'root');
if (!$db_handle) {
    die("Connection failed: " . mysqli_connect_error());
}

if (!mysqli_select_db($db_handle, 'agora')) {
    die("Database selection failed: " . mysqli_error($db_handle));
}
?>

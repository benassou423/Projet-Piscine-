<?php
session_start();
// Sécurité : accès réservé à l'admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}

$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', 'root');
$db_found = mysqli_select_db($db_handle, $database);

$message_ajout = "";

// Traitement rétrogradation vendeur
if (isset($_POST['retrograder_vendeur']) && !empty($_POST['retrograder_vendeur'])) {
    $id_vendeur = intval($_POST['retrograder_vendeur']);
    $sql_update = "UPDATE Utilisateur SET role = 'acheteur' WHERE id = ?";
    $stmt = mysqli_prepare($db_handle, $sql_update);
    mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
    if (mysqli_stmt_execute($stmt)) {
        $message_ajout = "Le vendeur a été rétrogradé en acheteur avec succès.";
        header('Location: admin_gestion_vendeurs.php');
        exit();
    } else {
        $message_ajout = "Erreur lors de la rétrogradation : " . mysqli_error($db_handle);
    }
}

// Traitement suppression vendeur
if (isset($_POST['supprimer_vendeur']) && !empty($_POST['supprimer_vendeur'])) {
    $id_vendeur = intval($_POST['supprimer_vendeur']);
    mysqli_begin_transaction($db_handle);
    try {
        $sql_delete_panier = "DELETE FROM Panier WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_panier);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_enchere_acheteur = "DELETE FROM Enchere WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_enchere_acheteur);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_enchere_articles = "DELETE e FROM Enchere e INNER JOIN Article a ON e.article_id = a.id WHERE a.vendeur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_enchere_articles);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_transactions_acheteur = "DELETE FROM Transaction WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_transactions_acheteur);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_transactions_vendeur = "DELETE t FROM Transaction t INNER JOIN Article a ON t.article_id = a.id WHERE a.vendeur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_transactions_vendeur);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_alertes = "DELETE FROM Alerte WHERE user_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_alertes);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_notifs = "DELETE FROM Notification WHERE user_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_notifs);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_nego = "DELETE FROM Negociation WHERE vendeur_id = ? OR acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_nego);
        mysqli_stmt_bind_param($stmt, "ii", $id_vendeur, $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_articles = "DELETE FROM Article WHERE vendeur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_articles);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_user = "DELETE FROM Utilisateur WHERE id = ? AND role = 'vendeur'";
        $stmt = mysqli_prepare($db_handle, $sql_delete_user);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        mysqli_commit($db_handle);
        $message_ajout = "Le vendeur et toutes ses données associées ont été supprimés avec succès.";
        header('Location: admin_gestion_vendeurs.php');
        exit();
    } catch (Exception $e) {
        mysqli_rollback($db_handle);
        $message_ajout = "Erreur lors de la suppression du vendeur : " . $e->getMessage();
    }
}

// Traitement ajout vendeur (idem que ton code initial)
if (isset($_POST['ajouter_vendeur']) && $_SERVER['REQUEST_METHOD'] == 'POST' && $db_found) {
    // ... (code d'ajout du vendeur ici, inchangé)
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des vendeurs - Admin | Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style-site.css">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Gestion des vendeurs</h2>
    <?php if ($message_ajout): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message_ajout) ?></div>
    <?php endif; ?>
    <!-- Ajout d'un vendeur (formulaire identique à avant, pas de styles inline) -->
    <!-- ... -->
    <!-- Liste des vendeurs -->
    <div class="card">
        <div class="card-header">Liste des vendeurs</div>
        <div class="card-body">
            <?php
            $sql = "SELECT * FROM Utilisateur WHERE role='vendeur' ORDER BY nom, prenom";
            $result = mysqli_query($db_handle, $sql);
            if ($result && mysqli_num_rows($result) > 0):
            ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($vendeur = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <?php if (isset($vendeur['photo']) && $vendeur['photo']): ?>
                                    <img src="<?= htmlspecialchars($vendeur['photo']) ?>" alt="photo" class="admin-photo-vendeur">
                                <?php else: ?>
                                    <div class="admin-photo-vendeur bg-secondary"></div>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($vendeur['nom']) ?></td>
                            <td><?= htmlspecialchars($vendeur['prenom']) ?></td>
                            <td><?= htmlspecialchars($vendeur['email']) ?></td>
                            <td>
                                <form method="post" class="d-inline me-1" onsubmit="return confirm('Voulez-vous rétrograder ce vendeur en acheteur ? Ses articles seront conservés mais non visibles jusqu\'à ce qu\'il redevienne vendeur.');">
                                    <input type="hidden" name="retrograder_vendeur" value="<?= (int)$vendeur['id'] ?>">
                                    <button type="submit" class="btn btn-warning btn-sm">Rétrograder</button>
                                </form>
                                <form method="post" class="d-inline" onsubmit="return confirm('ATTENTION : Êtes-vous sûr de vouloir supprimer définitivement ce vendeur ? Cette action supprimera tous ses articles et transactions.');">
                                    <input type="hidden" name="supprimer_vendeur" value="<?= (int)$vendeur['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <p class="text-muted text-center">Aucun vendeur enregistré.</p>
            <?php endif; ?>
        </div>
    </div>
    <a href="admin.php" class="btn btn-secondary mt-3">Retour à l'espace admin</a>
</div>
<?php include 'footer.php'; ?>
</body>
</html>

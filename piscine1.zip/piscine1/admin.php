<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Administration - Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style-site.css"></head>
<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Espace Administration</h2>
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-header bg-primary text-white">Gestion des utilisateurs</div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="admin_gestion_vendeurs.php" class="btn btn-outline-primary w-100">Gérer les vendeurs</a></li>
                        <li class="mb-2"><a href="admin_gestion_utilisateurs.php" class="btn btn-outline-primary w-100">Gérer les acheteurs</a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-header bg-success text-white">Gestion du catalogue</div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="admin_gestion_categories.php" class="btn btn-outline-success w-100">Gérer les catégories</a></li>
                        <li class="mb-2"><a href="admin_gestion_articles.php" class="btn btn-outline-success w-100">Gérer les articles</a></li>
                        <li class="mb-2"><a href="ajout_article.php" class="btn btn-outline-success w-100">Ajouter un article</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-header bg-info text-white">Statistiques & Rapports</div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="admin_stats_ventes.php" class="btn btn-outline-info w-100">Statistiques des ventes</a></li>
                        <li class="mb-2"><a href="admin_meilleures_ventes.php" class="btn btn-outline-info w-100">Meilleures ventes</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center mt-4">
        <a href="logout.php" class="btn btn-danger">Se déconnecter</a>
        <a href="index.php" class="btn btn-secondary ms-2">Retour à l'accueil</a>
    </div>

        <!-- Ajoute ici les liens vers les autres pages admin si besoin -->
    </ul>
    <a href="index.php" class="btn btn-secondary mt-4">Retour à l'accueil</a>
</div>
<?php include 'footer.php'; ?>
</body>
</html>

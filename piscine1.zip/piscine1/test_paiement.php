<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test du Système de Paiement - Agora Francia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style-site.css">
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3><i class="bi bi-credit-card"></i> Test du Système de Paiement</h3>
                </div>
                <div class="card-body">
                    <h5>Fonctionnalités Implémentées :</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary">✅ Pages créées :</h6>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-check-circle text-success"></i> <code>paiement.php</code> - Page de paiement complète</li>
                                <li><i class="bi bi-check-circle text-success"></i> <code>mes_achats.php</code> - Historique des achats</li>
                                <li><i class="bi bi-check-circle text-success"></i> <code>database_payment_setup.sql</code> - Script de base de données</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary">✅ Méthodes de paiement :</h6>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-credit-card text-info"></i> Carte bancaire (Visa, Mastercard, CB)</li>
                                <li><i class="bi bi-bank text-success"></i> Virement bancaire</li>
                                <li><i class="bi bi-apple text-dark"></i> Apple Pay</li>
                            </ul>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h5>Fonctionnalités du Système :</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary">Interface Utilisateur :</h6>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-check text-success"></i> Design moderne et responsive</li>
                                <li><i class="bi bi-check text-success"></i> Sélection intuitive des méthodes de paiement</li>
                                <li><i class="bi bi-check text-success"></i> Formulaires adaptatifs selon la méthode</li>
                                <li><i class="bi bi-check text-success"></i> Résumé de commande en temps réel</li>
                                <li><i class="bi bi-check text-success"></i> Badges de sécurité et confiance</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-primary">Sécurité et Données :</h6>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-shield-check text-success"></i> Validation côté client et serveur</li>
                                <li><i class="bi bi-shield-check text-success"></i> Formatage automatique des champs</li>
                                <li><i class="bi bi-shield-check text-success"></i> Vérification de disponibilité des articles</li>
                                <li><i class="bi bi-shield-check text-success"></i> Gestion des erreurs et succès</li>
                                <li><i class="bi bi-shield-check text-success"></i> Historique complet des transactions</li>
                            </ul>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h5>Workflow du Paiement :</h5>
                    <div class="d-flex flex-wrap gap-2 mb-3">
                        <span class="badge bg-primary fs-6">1. Panier</span>
                        <i class="bi bi-arrow-right align-self-center"></i>
                        <span class="badge bg-info fs-6">2. Paiement</span>
                        <i class="bi bi-arrow-right align-self-center"></i>
                        <span class="badge bg-warning fs-6">3. Traitement</span>
                        <i class="bi bi-arrow-right align-self-center"></i>
                        <span class="badge bg-success fs-6">4. Confirmation</span>
                        <i class="bi bi-arrow-right align-self-center"></i>
                        <span class="badge bg-dark fs-6">5. Historique</span>
                    </div>
                    
                    <div class="alert alert-info">
                        <h6><i class="bi bi-info-circle"></i> Instructions de Test :</h6>
                        <ol>
                            <li>Connectez-vous avec un compte utilisateur</li>
                            <li>Ajoutez des articles au panier</li>
                            <li>Cliquez sur "Procéder au paiement" depuis le panier</li>
                            <li>Testez les différentes méthodes de paiement</li>
                            <li>Vérifiez l'historique dans "Mes Achats"</li>
                        </ol>
                    </div>
                    
                    <div class="alert alert-warning">
                        <h6><i class="bi bi-exclamation-triangle"></i> Base de Données :</h6>
                        <p class="mb-2">Assurez-vous d'exécuter le script SQL <code>database_payment_setup.sql</code> pour créer les tables nécessaires :</p>
                        <ul class="mb-0">
                            <li><strong>Transaction</strong> - Stockage des transactions</li>
                            <li><strong>MethodePaiement</strong> - Méthodes de paiement sauvegardées</li>
                            <li>Mise à jour de la table <strong>Achat</strong> avec transaction_id</li>
                            <li>Mise à jour de la table <strong>Utilisateur</strong> avec champs d'adresse</li>
                        </ul>
                    </div>
                    
                    <div class="d-flex gap-2 justify-content-center">
                        <a href="index.php" class="btn btn-primary">
                            <i class="bi bi-house"></i> Retour à l'accueil
                        </a>
                        <a href="panier.php" class="btn btn-success">
                            <i class="bi bi-cart"></i> Tester le panier
                        </a>
                        <a href="mes_achats.php" class="btn btn-info">
                            <i class="bi bi-bag-check"></i> Voir mes achats
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

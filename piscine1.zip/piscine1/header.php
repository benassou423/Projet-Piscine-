<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include_once "db.php";

// Compteur de notifications non lues
$notif_count = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
    $sql_notif = "SELECT COUNT(*) AS nb FROM Notification WHERE user_id=$user_id AND lu=0";
    $result_notif = mysqli_query($db_handle, $sql_notif);
    if ($result_notif && $row = mysqli_fetch_assoc($result_notif)) {
        $notif_count = $row['nb'];
    }
}
$panier_count = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
    // Chercher le panier
    $sql_pan = "SELECT id FROM Panier WHERE acheteur_id=$user_id";
    $result_pan = mysqli_query($db_handle, $sql_pan);
    if ($result_pan && $row = mysqli_fetch_assoc($result_pan)) {
        $panier_id = $row['id'];
        $sql_count = "SELECT COUNT(*) AS nb FROM ArticlePanier WHERE panier_id=$panier_id";
        $result_count = mysqli_query($db_handle, $sql_count);
        if ($result_count && $row2 = mysqli_fetch_assoc($result_count)) {
            $panier_count = $row2['nb'];
        }
    }
}

?>
<!-- HEADER -->
<div class="header">

    <img src="images/logo1.png" alt="Logo Agora Francia">
</div>
<!-- NAVIGATION -->
<nav class="navigation">
    <a href="index.php">Accueil</a>
    <a href="catalogue.php">Tout Parcourir</a>
    <a href="notifications.php" class="nav-link-notif">
        Notifications
        <?php if ($notif_count > 0): ?>
            <span class="notif-badge"><?= $notif_count ?></span>
        <?php endif; ?>
    </a>
    <a href="panier.php" class="nav-link-panier">
        Panier
        <?php if ($panier_count > 0): ?>
            <span class="panier-badge"><?= $panier_count ?></span>
        <?php endif; ?>
    </a>
    <a href="compte.php">Votre Compte</a>
    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin'): ?>
        <a href="admin.php">Administration</a>
    <?php endif; ?>
    <?php
        if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['vendeur', 'admin'])) {
            echo '<a href="ajout_article.php">Ajouter un article</a>';
        }
    ?>
</nav>

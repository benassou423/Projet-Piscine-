<?php
// Script pour créer la table achat manquante
// Fichier: setup_achat_table.php

$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if (!$db_found) {
    die("Base de données non trouvée !");
}

$sql = "CREATE TABLE IF NOT EXISTS `achat` (
    `id` int NOT NULL AUTO_INCREMENT,
    `acheteur_id` int NOT NULL,
    `vendeur_id` int NOT NULL,
    `article_id` int NOT NULL,
    `transaction_id` int DEFAULT NULL,
    `prix_achat` decimal(10,2) NOT NULL,
    `mode_achat` enum('achat','negociation','enchere') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'achat',
    `date_achat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `statut` enum('en_attente','confirme','annule') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'confirme',
    PRIMARY KEY (`id`),
    KEY `acheteur_id` (`acheteur_id`),
    KEY `vendeur_id` (`vendeur_id`),
    KEY `article_id` (`article_id`),
    KEY `transaction_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

if (mysqli_query($db_handle, $sql)) {
    echo "✅ Table 'achat' créée avec succès !<br>";
} else {
    echo "❌ Erreur lors de la création de la table 'achat': " . mysqli_error($db_handle) . "<br>";
}

// Vérifier que la table existe maintenant
$result = mysqli_query($db_handle, "SHOW TABLES LIKE 'achat'");
if (mysqli_num_rows($result) > 0) {
    echo "✅ Table 'achat' existe maintenant dans la base de données.<br>";
} else {
    echo "❌ La table 'achat' n'a pas pu être créée.<br>";
}

// Ajouter les contraintes de clé étrangère séparément (au cas où il y aurait des problèmes)
$constraints = [
    "ALTER TABLE `achat` ADD CONSTRAINT `achat_ibfk_1` FOREIGN KEY (`acheteur_id`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE",
    "ALTER TABLE `achat` ADD CONSTRAINT `achat_ibfk_2` FOREIGN KEY (`vendeur_id`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE", 
    "ALTER TABLE `achat` ADD CONSTRAINT `achat_ibfk_3` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE CASCADE",
    "ALTER TABLE `achat` ADD CONSTRAINT `achat_ibfk_4` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`id`) ON DELETE SET NULL"
];

echo "<br>🔗 Ajout des contraintes de clé étrangère :<br>";
foreach ($constraints as $constraint) {
    if (mysqli_query($db_handle, $constraint)) {
        echo "✅ Contrainte ajoutée avec succès<br>";
    } else {
        // Les contraintes peuvent déjà exister, donc on ignore certaines erreurs
        $error = mysqli_error($db_handle);
        if (strpos($error, 'Duplicate key name') !== false || strpos($error, 'already exists') !== false) {
            echo "ℹ️ Contrainte déjà existante (ignoré)<br>";
        } else {
            echo "⚠️ Erreur contrainte (peut être ignorée): " . $error . "<br>";
        }
    }
}

mysqli_close($db_handle);

echo "<br>🎉 <strong>Configuration terminée !</strong><br>";
echo "Vous pouvez maintenant utiliser le système de paiement et consulter vos achats.";
?>

<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}

include_once "db.php";

$message = "";

// Ajout d'une catégorie
if (isset($_POST['ajouter_categorie'])) {
    $nom = mysqli_real_escape_string($db_handle, trim($_POST['nom']));
    $type = mysqli_real_escape_string($db_handle, trim($_POST['type']));
    
    $sql = "INSERT INTO Categorie (nom, type) VALUES ('$nom', '$type')";
    if (mysqli_query($db_handle, $sql)) {
        $message = "Catégorie ajoutée avec succès !";
    } else {
        $message = "Erreur lors de l'ajout : " . mysqli_error($db_handle);
    }
}

// Suppression d'une catégorie
if (isset($_POST['supprimer_categorie'])) {
    $id = intval($_POST['supprimer_categorie']);
    
    $sql = "DELETE FROM Categorie WHERE id = $id";
    if (mysqli_query($db_handle, $sql)) {
        $message = "Catégorie supprimée avec succès !";
    } else {
        $message = "Erreur lors de la suppression : " . mysqli_error($db_handle);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Catégories - Admin | Agora Francia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style-site.css"></head>
<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Gestion des Catégories</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>

    <!-- Ajout d'une catégorie -->
    <div class="card mb-4">
        <div class="card-header">Ajouter une catégorie</div>
        <div class="card-body">
            <form method="post">
                <div class="mb-3">
                    <input required name="nom" type="text" class="form-control" placeholder="Nom de la catégorie">
                </div>
                <div class="mb-3">
                    <select name="type" class="form-control" required>
                        <option value="">-- Type de catégorie --</option>
                        <option value="Meubles et objets d'art">Meubles et objets d'art</option>
                        <option value="Accessoire VIP">Accessoire VIP</option>
                        <option value="Matériels scolaires">Matériels scolaires</option>
                    </select>
                </div>
                <button type="submit" name="ajouter_categorie" class="btn btn-success">Ajouter</button>
            </form>
        </div>
    </div>

    <!-- Liste des catégories -->
    <div class="card">
        <div class="card-header">Liste des catégories</div>
        <div class="card-body">
            <?php
            $sql = "SELECT * FROM Categorie ORDER BY type, nom";
            $result = mysqli_query($db_handle, $sql);
            if (mysqli_num_rows($result) > 0):
            ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Type</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($cat = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $cat['nom'] ?></td>
                            <td><?= $cat['type'] ?></td>
                            <td>
                                <form method="post" class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?');">
                                    <input type="hidden" name="supprimer_categorie" value="<?= $cat['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <p class="text-muted">Aucune catégorie enregistrée.</p>
            <?php endif; ?>
        </div>
    </div>

    <a href="admin.php" class="btn btn-secondary mt-3">Retour à l'administration</a>
</div>
<?php include 'footer.php'; ?>
</body>
</html>

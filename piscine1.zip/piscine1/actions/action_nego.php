<?php
date_default_timezone_set('Europe/Paris');

// Acheteur fait une offre
if (
    isset($_POST['faire_offre']) &&
    isset($_POST['prix_offre']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id']
) {
    $acheteur_id = intval($_SESSION['user_id']);
    $vendeur_id = intval($article['vendeur_id']);
    $article_id = intval($article['id']);
    $prix_offre = floatval($_POST['prix_offre']);
    $sql = "SELECT * FROM Negociation WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND etat='en cours' ORDER BY tour DESC LIMIT 1";
    $res = mysqli_query($db_handle, $sql);
    $acheteur_nom = $_SESSION['user_prenom'] . " " . $_SESSION['user_nom'];
    $contenu = "Nouvelle offre de $acheteur_nom sur l'article : " . $article['titre'] . " (" . number_format($prix_offre,2,',',' ') . " €)";
    $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
    $date_notif = date('Y-m-d H:i:s');

    if ($res && mysqli_num_rows($res) > 0) {
        $nego = mysqli_fetch_assoc($res);
        if ($nego['tour'] >= 5) {
            $nego_message = "Vous avez atteint la limite de 5 tentatives de négociation.";
        } else {
            $tour = $nego['tour'] + 1;
            $sql2 = "INSERT INTO Negociation (article_id, acheteur_id, vendeur_id, tour, offre_acheteur, date_action) 
                     VALUES ($article_id, $acheteur_id, $vendeur_id, $tour, $prix_offre, NOW())";
            mysqli_query($db_handle, $sql2);
            $nego_message = "Votre nouvelle offre a été soumise au vendeur.";
            // Notification vendeur
            $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
                          VALUES ($vendeur_id, '$contenu_sql', '$date_notif', $article_id)";
            mysqli_query($db_handle, $sql_notif);
        }
    } else {
        // PREMIER TOUR : AJOUTE LA NOTIF ICI AUSSI
        $sql2 = "INSERT INTO Negociation (article_id, acheteur_id, vendeur_id, tour, offre_acheteur, date_action) 
                 VALUES ($article_id, $acheteur_id, $vendeur_id, 1, $prix_offre, NOW())";
        mysqli_query($db_handle, $sql2);
        $nego_message = "Votre offre a été soumise au vendeur.";
        // Notification vendeur
        $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
                      VALUES ($vendeur_id, '$contenu_sql', '$date_notif', $article_id)";
        mysqli_query($db_handle, $sql_notif);
    }
}

// Acheteur accepte une contre-offre
if (
    isset($_POST['accept_contre_offre']) &&
    isset($_POST['tour']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id']
) {
    $acheteur_id = intval($_SESSION['user_id']);
    $tour = intval($_POST['tour']);
    $article_id = intval($article['id']);
    $sql = "UPDATE Negociation SET etat='accepte' WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
    mysqli_query($db_handle, $sql);
    $sql2 = "UPDATE Article SET statut='vendu' WHERE id=$article_id";
    mysqli_query($db_handle, $sql2);
    $nego_message = "Vous avez accepté la contre-offre du vendeur !";
    // Notification vendeur
    $contenu = "L'acheteur a accepté votre contre-offre sur l'article « " . $article['titre'] . " » !";
    $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
    $date_notif = date('Y-m-d H:i:s');
    $vendeur_id = intval($article['vendeur_id']);
    $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
                  VALUES ($vendeur_id, '$contenu_sql', '$date_notif', $article_id)";
    mysqli_query($db_handle, $sql_notif);
}

// Vendeur répond à une offre (accepte, refuse, contre-offre)
if (
    isset($_POST['repondre_nego']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] == $article['vendeur_id'] &&
    isset($_POST['acheteur_id']) &&
    isset($_POST['tour'])
) {
    $acheteur_id = intval($_POST['acheteur_id']);
    $tour = intval($_POST['tour']);
    $article_id = intval($article['id']);
    if (isset($_POST['accepter'])) {
        $sql = "UPDATE Negociation SET etat='accepte' WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
        mysqli_query($db_handle, $sql);
        $sql2 = "UPDATE Article SET statut='vendu' WHERE id=$article_id";
        mysqli_query($db_handle, $sql2);
        $nego_message = "Vous avez accepté l'offre de l'acheteur !";
        // Notification acheteur
        $contenu = "Votre offre sur l'article « " . $article['titre'] . " » a été acceptée par le vendeur !";
        $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
        $date_notif = date('Y-m-d H:i:s');
        $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
                      VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";
        mysqli_query($db_handle, $sql_notif);
    } elseif (isset($_POST['refuser'])) {
        $sql = "UPDATE Negociation SET etat='refuse' WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
        mysqli_query($db_handle, $sql);
        $nego_message = "Vous avez refusé l'offre.";
        // Notification acheteur
        $contenu = "Votre offre sur l'article « " . $article['titre'] . " » a été refusée par le vendeur.";
        $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
        $date_notif = date('Y-m-d H:i:s');
        $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
                      VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";
        mysqli_query($db_handle, $sql_notif);
    } elseif (isset($_POST['contre_offre']) && isset($_POST['prix_contre_offre'])) {
        $prix_contre = floatval($_POST['prix_contre_offre']);
        $sql = "UPDATE Negociation SET contre_offre_vendeur=$prix_contre WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
        mysqli_query($db_handle, $sql);
        $nego_message = "Votre contre-offre a été envoyée à l'acheteur.";
        // Notification acheteur
        $contenu = "Le vendeur a fait une contre-offre (" . number_format($prix_contre,2,',',' ') . " €) sur l'article « " . $article['titre'] . " ». Consultez votre historique de négociation !";
        $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
        $date_notif = date('Y-m-d H:i:s');
        $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
                      VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";
        mysqli_query($db_handle, $sql_notif);
    }
}
?>

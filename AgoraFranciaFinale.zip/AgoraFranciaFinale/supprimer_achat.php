<?php
session_start();
$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

// Vérifier que l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Vous devez être connecté pour effectuer cette action.";
    header('Location: compte.php');
    exit();
}

// Vérifier que l'ID de l'achat est fourni
if (!isset($_POST['achat_id']) || !is_numeric($_POST['achat_id'])) {
    $_SESSION['error'] = "ID d'achat invalide.";
    header('Location: mes_achats.php');
    exit();
}

$achat_id = intval($_POST['achat_id']);
$user_id = $_SESSION['user_id'];

try {
    // Commencer une transaction
    mysqli_autocommit($db_handle, false);
    
    // Vérifier que l'achat appartient bien à l'utilisateur connecté
    $check_sql = "SELECT id, transaction_id, article_id FROM Achat WHERE id = ? AND acheteur_id = ?";
    $check_stmt = mysqli_prepare($db_handle, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "ii", $achat_id, $user_id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($check_result) === 0) {
        throw new Exception("Achat non trouvé ou vous n'avez pas l'autorisation de le supprimer.");
    }
    
    $achat_data = mysqli_fetch_assoc($check_result);
    $transaction_id = $achat_data['transaction_id'];
    $article_id = $achat_data['article_id'];
    
    // Supprimer l'achat
    $delete_achat_sql = "DELETE FROM Achat WHERE id = ? AND acheteur_id = ?";
    $delete_achat_stmt = mysqli_prepare($db_handle, $delete_achat_sql);
    mysqli_stmt_bind_param($delete_achat_stmt, "ii", $achat_id, $user_id);
    
    if (!mysqli_stmt_execute($delete_achat_stmt)) {
        throw new Exception("Erreur lors de la suppression de l'achat.");
    }
    
    // Supprimer la transaction associée si elle existe
    if ($transaction_id) {
        $delete_transaction_sql = "DELETE FROM transaction WHERE id = ?";
        $delete_transaction_stmt = mysqli_prepare($db_handle, $delete_transaction_sql);
        mysqli_stmt_bind_param($delete_transaction_stmt, "i", $transaction_id);
        
        if (!mysqli_stmt_execute($delete_transaction_stmt)) {
            throw new Exception("Erreur lors de la suppression de la transaction.");
        }
    }
      // Valider la transaction
    mysqli_commit($db_handle);
    
    $_SESSION['success'] = "Achat supprimé avec succès.";
    
} catch (Exception $e) {
    // Annuler la transaction en cas d'erreur
    mysqli_rollback($db_handle);
    $_SESSION['error'] = $e->getMessage();
}

// Restaurer l'autocommit
mysqli_autocommit($db_handle, true);

// Rediriger vers la page des achats
header('Location: mes_achats.php');
exit();
?>

<footer class="footer" >
    <div class="text-center" >
        <div><strong>Email</strong> : agora.francia@email.fr</div>
        <div><strong>Téléphone</strong> : 01 23 45 67 89</div>
        <div><strong>Adresse</strong> : 10 avenue de la République, 75000 Paris</div>
        <div ><em>Notre équipe est à votre écoute du lundi au samedi de 8h à 20h.</em></div>
        <div >
            &copy; 2025 Agora Francia | Projet ECE Web Dynamique
        </div>
    </div>
</footer>

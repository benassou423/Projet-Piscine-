<?php
session_start();
// Sécurité : accès réservé à l'admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}

$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

$message_ajout = "";

// Traitement rétrogradation vendeur
if (isset($_POST['retrograder_vendeur']) && !empty($_POST['retrograder_vendeur'])) {
    $id_vendeur = intval($_POST['retrograder_vendeur']);
    $sql_update = "UPDATE Utilisateur SET role = 'acheteur' WHERE id = ?";
    $stmt = mysqli_prepare($db_handle, $sql_update);
    mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
    if (mysqli_stmt_execute($stmt)) {
        $message_ajout = "Le vendeur a été rétrogradé en acheteur avec succès.";
        header('Location: admin_gestion_vendeurs.php');
        exit();
    } else {
        $message_ajout = "Erreur lors de la rétrogradation : " . mysqli_error($db_handle);
    }
}

// Traitement suppression vendeur
if (isset($_POST['supprimer_vendeur']) && !empty($_POST['supprimer_vendeur'])) {
    $id_vendeur = intval($_POST['supprimer_vendeur']);
    mysqli_begin_transaction($db_handle);
    try {
        $sql_delete_panier = "DELETE FROM Panier WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_panier);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_enchere_acheteur = "DELETE FROM Enchere WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_enchere_acheteur);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_enchere_articles = "DELETE e FROM Enchere e INNER JOIN Article a ON e.article_id = a.id WHERE a.vendeur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_enchere_articles);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_transactions_acheteur = "DELETE FROM Transaction WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_transactions_acheteur);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_transactions_vendeur = "DELETE t FROM Transaction t INNER JOIN Article a ON t.article_id = a.id WHERE a.vendeur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_transactions_vendeur);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_alertes = "DELETE FROM Alerte WHERE user_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_alertes);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_notifs = "DELETE FROM Notification WHERE user_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_notifs);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_nego = "DELETE FROM Negociation WHERE vendeur_id = ? OR acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_nego);
        mysqli_stmt_bind_param($stmt, "ii", $id_vendeur, $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_articles = "DELETE FROM Article WHERE vendeur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_articles);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $sql_delete_user = "DELETE FROM Utilisateur WHERE id = ? AND role = 'vendeur'";
        $stmt = mysqli_prepare($db_handle, $sql_delete_user);
        mysqli_stmt_bind_param($stmt, "i", $id_vendeur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        mysqli_commit($db_handle);
        $message_ajout = "Le vendeur et toutes ses données associées ont été supprimés avec succès.";
        header('Location: admin_gestion_vendeurs.php');
        exit();
    } catch (Exception $e) {
        mysqli_rollback($db_handle);
        $message_ajout = "Erreur lors de la suppression du vendeur : " . $e->getMessage();
    }
}

// Traitement ajout vendeur
if (isset($_POST['ajouter_vendeur']) && $_SERVER['REQUEST_METHOD'] == 'POST' && $db_found) {
    $email = mysqli_real_escape_string($db_handle, trim($_POST['email']));
    
    // Vérifie si email déjà utilisé
    $sql = "SELECT id, role, nom, prenom FROM Utilisateur WHERE email = ?";
    $stmt = mysqli_prepare($db_handle, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($result) > 0) {
        // Si l'utilisateur existe
        $user = mysqli_fetch_assoc($result);
        if ($user['role'] == 'vendeur') {
            $message_ajout = "Cet email est déjà utilisé par un vendeur !";
        } else {
            // Conversion d'un compte acheteur en vendeur
            $sql = "UPDATE Utilisateur SET role = 'vendeur' WHERE id = ?";
            $stmt = mysqli_prepare($db_handle, $sql);
            mysqli_stmt_bind_param($stmt, "i", $user['id']);
            
            // Gestion de la photo si fournie
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
                $target_dir = "images/";
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                
                $extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                $allowed = array('jpg', 'jpeg', 'png', 'gif');
                
                if (in_array($extension, $allowed)) {
                    $photo_name = uniqid('profile_') . '.' . $extension;
                    $target_file = $target_dir . $photo_name;
                    
                    if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                        $sql = "UPDATE Utilisateur SET role = 'vendeur', photo = ? WHERE id = ?";
                        $stmt = mysqli_prepare($db_handle, $sql);
                        mysqli_stmt_bind_param($stmt, "si", $target_file, $user['id']);
                    }
                }
            }
            
            if (mysqli_stmt_execute($stmt)) {
                $message_ajout = "Le compte de {$user['prenom']} {$user['nom']} a été converti en compte vendeur avec succès !";
            } else {
                $message_ajout = "Erreur lors de la conversion du compte : " . mysqli_error($db_handle);
            }
        }
    } else {
        // Création d'un nouveau compte vendeur
        if (empty($_POST['nom']) || empty($_POST['prenom']) || empty($_POST['password']) || 
            empty($_POST['password2']) || empty($_POST['adresse1']) || empty($_POST['ville']) || 
            empty($_POST['code_postal']) || empty($_POST['pays']) || empty($_POST['telephone'])) {
            $message_ajout = "Tous les champs marqués d'une étoile sont requis pour créer un nouveau compte vendeur.";
        } else {
            $nom = mysqli_real_escape_string($db_handle, trim($_POST['nom']));
            $prenom = mysqli_real_escape_string($db_handle, trim($_POST['prenom']));
            $password = $_POST['password'];
            $password2 = $_POST['password2'];
            $adresse1 = mysqli_real_escape_string($db_handle, trim($_POST['adresse1']));
            $adresse2 = mysqli_real_escape_string($db_handle, trim($_POST['adresse2']));
            $ville = mysqli_real_escape_string($db_handle, trim($_POST['ville']));
            $code_postal = mysqli_real_escape_string($db_handle, trim($_POST['code_postal']));
            $pays = mysqli_real_escape_string($db_handle, trim($_POST['pays']));
            $telephone = mysqli_real_escape_string($db_handle, trim($_POST['telephone']));

            if ($password !== $password2) {
                $message_ajout = "Les mots de passe ne correspondent pas.";
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                
                // Gestion de la photo
                $photo_path = null;
                if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
                    $target_dir = "images/";
                    if (!file_exists($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    
                    $extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                    $allowed = array('jpg', 'jpeg', 'png', 'gif');
                    
                    if (in_array($extension, $allowed)) {
                        $photo_name = uniqid('profile_') . '.' . $extension;
                        $target_file = $target_dir . $photo_name;
                        
                        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                            $photo_path = $target_file;
                        }
                    }
                }
                
                $sql = "INSERT INTO Utilisateur (nom, prenom, email, mot_de_passe, role, photo) VALUES (?, ?, ?, ?, 'vendeur', ?)";
                $stmt = mysqli_prepare($db_handle, $sql);
                
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "sssss",
                        $nom, $prenom, $email, $hash, $photo_path
                    );
                    
                    if (mysqli_stmt_execute($stmt)) {
                        $message_ajout = "Nouveau vendeur ajouté avec succès !";
                        header('Location: admin_gestion_vendeurs.php');
                        exit();
                    } else {
                        $message_ajout = "Erreur lors de l'ajout : " . mysqli_error($db_handle);
                    }
                    mysqli_stmt_close($stmt);
                } else {
                    $message_ajout = "Erreur de préparation de la requête : " . mysqli_error($db_handle);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des vendeurs - Admin | Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style-site.css">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Gestion des vendeurs</h2>
    <?php if ($message_ajout): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message_ajout) ?></div>
    <?php endif; ?>
    <!-- Ajout d'un vendeur -->
    <div class="card mb-4">
        <div class="card-header">Ajouter un vendeur</div>
        <div class="card-body">
            <form method="post" class="mb-3" enctype="multipart/form-data" id="vendeurForm">
                <div class="mb-2">
                    <input required name="email" type="email" class="form-control" placeholder="Email ECE" id="emailInput">
                    <small class="text-muted">Commencez par entrer l'email pour vérifier si le compte existe déjà</small>
                </div>
                
                <div id="newVendeurFields" style="display: none;">
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <input name="nom" type="text" class="form-control" placeholder="Nom *" required>
                        </div>
                        <div class="col-md-6 mb-2">
                            <input name="prenom" type="text" class="form-control" placeholder="Prénom *" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <input name="password" type="password" class="form-control" placeholder="Mot de passe *" required>
                        </div>
                        <div class="col-md-6 mb-2">
                            <input name="password2" type="password" class="form-control" placeholder="Confirmer mot de passe *" required>
                        </div>
                    </div>

                    <div class="mb-2">
                        <input name="adresse1" type="text" class="form-control" placeholder="Adresse (ligne 1) *" required>
                    </div>
                    <div class="mb-2">
                        <input name="adresse2" type="text" class="form-control" placeholder="Adresse (ligne 2)">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <input name="ville" type="text" class="form-control" placeholder="Ville *" required>
                        </div>
                        <div class="col-md-3 mb-2">
                            <input name="code_postal" type="text" class="form-control" placeholder="Code postal *" required>
                        </div>
                        <div class="col-md-3 mb-2">
                            <input name="pays" type="text" class="form-control" placeholder="Pays *" required>
                        </div>
                    </div>

                    <div class="mb-2">
                        <input name="telephone" type="tel" class="form-control" placeholder="Téléphone *" required>
                    </div>
                </div>
                
                <div class="mb-2">
                    <label>Photo de profil</label>
                    <input type="file" name="photo" class="form-control" accept="image/*">
                </div>
                
                <button type="submit" name="ajouter_vendeur" class="btn btn-success w-100">Créer le vendeur</button>
            </form>

            <div id="emailError" class="alert alert-danger" style="display: none;">
                Cet email correspond déjà à un compte vendeur !
            </div>
            <div id="emailWarning" class="alert alert-warning" style="display: none;">
                Cet email correspond à un compte acheteur. Voulez-vous le convertir en compte vendeur ?
                <div class="mt-2">
                    <button type="button" id="confirmConversion" class="btn btn-warning btn-sm">Oui, convertir en vendeur</button>
                    <button type="button" id="cancelConversion" class="btn btn-secondary btn-sm ms-2">Annuler</button>
                </div>
            </div>

            <script>
            let isAcheteur = false;
            document.getElementById('emailInput').addEventListener('blur', function() {
                const email = this.value;
                const errorDiv = document.getElementById('emailError');
                const warningDiv = document.getElementById('emailWarning');
                const submitButton = document.querySelector('button[name="ajouter_vendeur"]');
                
                if (email) {
                    fetch('check_email.php?email=' + encodeURIComponent(email))
                        .then(response => response.json())
                        .then(data => {
                            const newVendeurFields = document.getElementById('newVendeurFields');
                            const inputs = newVendeurFields.querySelectorAll('input');
                            
                            if (data.exists && data.role === 'vendeur') {
                                // Email existe déjà et c'est un vendeur
                                errorDiv.style.display = 'block';
                                warningDiv.style.display = 'none';
                                newVendeurFields.style.display = 'none';
                                submitButton.style.display = 'none';
                                inputs.forEach(input => input.required = false);
                                isAcheteur = false;
                            } else if (data.exists && data.role === 'acheteur') {
                                // Email existe et c'est un acheteur
                                errorDiv.style.display = 'none';
                                warningDiv.style.display = 'block';
                                newVendeurFields.style.display = 'none';
                                submitButton.style.display = 'none';
                                inputs.forEach(input => input.required = false);
                                isAcheteur = true;
                            } else {
                                // Nouvel email
                                errorDiv.style.display = 'none';
                                warningDiv.style.display = 'none';
                                newVendeurFields.style.display = 'block';
                                submitButton.style.display = 'block';
                                submitButton.disabled = false;
                                inputs.forEach(input => {
                                    if (input.name !== 'adresse2') {
                                        input.required = true;
                                    }
                                });
                            }
                        });
                }
            });

            // Gestion des boutons de confirmation
            document.getElementById('confirmConversion').addEventListener('click', function() {
                const warningDiv = document.getElementById('emailWarning');
                const submitButton = document.querySelector('button[name="ajouter_vendeur"]');
                
                warningDiv.style.display = 'none';
                submitButton.style.display = 'block';
                if (isAcheteur) {
                    submitButton.textContent = 'Convertir en vendeur';
                    submitButton.classList.remove('btn-success');
                    submitButton.classList.add('btn-warning');
                }
            });

            document.getElementById('cancelConversion').addEventListener('click', function() {
                const warningDiv = document.getElementById('emailWarning');
                const submitButton = document.querySelector('button[name="ajouter_vendeur"]');
                const emailInput = document.getElementById('emailInput');
                
                warningDiv.style.display = 'none';
                submitButton.style.display = 'none';
                emailInput.value = '';
                isAcheteur = false;
            });
            </script>
        </div>
    </div>
    <!-- Liste des vendeurs -->
    <div class="card">
        <div class="card-header">Liste des vendeurs</div>
        <div class="card-body">
            <?php
            $sql = "SELECT * FROM Utilisateur WHERE role='vendeur' ORDER BY nom, prenom";
            $result = mysqli_query($db_handle, $sql);
            if ($result && mysqli_num_rows($result) > 0):
            ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($vendeur = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                <?php if (isset($vendeur['photo']) && $vendeur['photo']): ?>
                    <img src="<?= htmlspecialchars($vendeur['photo']) ?>" alt="photo" style="width:50px;height:50px;object-fit:cover;">
                <?php else: ?>
                    <div class="bg-secondary" style="width:50px;height:50px;"></div>
                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($vendeur['nom']) ?></td>
                            <td><?= htmlspecialchars($vendeur['prenom']) ?></td>
                            <td><?= htmlspecialchars($vendeur['email']) ?></td>
                            <td>
                                <form method="post" class="d-inline me-1" onsubmit="return confirm('Voulez-vous rétrograder ce vendeur en acheteur ? Ses articles seront conservés mais non visibles jusqu\'à ce qu\'il redevienne vendeur.');">
                                    <input type="hidden" name="retrograder_vendeur" value="<?= (int)$vendeur['id'] ?>">
                                    <button type="submit" class="btn btn-warning btn-sm">Rétrograder</button>
                                </form>
                                <form method="post" class="d-inline" onsubmit="return confirm('ATTENTION : Êtes-vous sûr de vouloir supprimer définitivement ce vendeur ? Cette action supprimera tous ses articles et transactions.');">
                                    <input type="hidden" name="supprimer_vendeur" value="<?= (int)$vendeur['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <p class="text-muted text-center">Aucun vendeur enregistré.</p>
            <?php endif; ?>
        </div>
    </div>
    <a href="admin.php" class="btn btn-secondary mt-3">Retour à l'espace admin</a>
</div>
<?php include 'footer.php'; ?>
</body>
</html>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 28 mai 2025 à 17:32
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `agora`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat`
--

DROP TABLE IF EXISTS `achat`;
CREATE TABLE IF NOT EXISTS `achat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acheteur_id` int NOT NULL,
  `vendeur_id` int NOT NULL,
  `article_id` int NOT NULL,
  `transaction_id` int DEFAULT NULL,
  `prix_achat` decimal(10,2) NOT NULL,
  `mode_achat` enum('achat','negociation','enchere') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'achat',
  `date_achat` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `statut` enum('en_attente','confirme','annule') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'confirme',
  PRIMARY KEY (`id`),
  KEY `acheteur_id` (`acheteur_id`),
  KEY `vendeur_id` (`vendeur_id`),
  KEY `article_id` (`article_id`),
  KEY `transaction_id` (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `achat`
--

INSERT INTO `achat` (`id`, `acheteur_id`, `vendeur_id`, `article_id`, `transaction_id`, `prix_achat`, `mode_achat`, `date_achat`, `statut`) VALUES
(7, 17, 4, 50, 16, 900.00, 'achat', '2025-05-28 13:25:30', 'confirme'),
(8, 17, 4, 45, 17, 150.00, '', '2025-05-28 15:27:15', 'confirme'),
(17, 17, 4, 61, 26, 51.00, 'enchere', '2025-05-28 18:26:15', 'confirme'),
(18, 19, 4, 61, 27, 51.00, 'enchere', '2025-05-28 18:29:23', 'confirme'),
(19, 19, 4, 62, 28, 46.00, 'enchere', '2025-05-28 18:30:15', 'confirme'),
(20, 19, 4, 61, 29, 51.00, 'enchere', '2025-05-28 18:30:49', 'confirme'),
(21, 19, 4, 61, 30, 51.00, 'enchere', '2025-05-28 18:36:13', 'confirme'),
(24, 17, 4, 63, 33, 46.00, 'enchere', '2025-05-28 19:09:23', 'confirme'),
(25, 17, 4, 63, 34, 46.00, 'enchere', '2025-05-28 19:21:50', 'confirme');

-- --------------------------------------------------------

--
-- Structure de la table `alerte`
--

DROP TABLE IF EXISTS `alerte`;
CREATE TABLE IF NOT EXISTS `alerte` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `categorie_id` int DEFAULT NULL,
  `type_vente` varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mots_cles` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prix_min` float DEFAULT NULL,
  `prix_max` float DEFAULT NULL,
  `date_creation` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `categorie_id` (`categorie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `alerte`
--

INSERT INTO `alerte` (`id`, `user_id`, `categorie_id`, `type_vente`, `mots_cles`, `prix_min`, `prix_max`, `date_creation`) VALUES
(1, 4, 2, 'immediat', '', 0.01, 0, '2025-05-26 23:25:10'),
(2, 4, 2, 'negociation', '', NULL, NULL, '2025-05-26 23:25:26'),
(6, 4, 2, 'immediat', '', 0, NULL, '2025-05-27 13:25:51');

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `qualite` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `defaut` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `video` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `prix_initial` decimal(10,2) NOT NULL,
  `categorie_id` int NOT NULL,
  `vendeur_id` int NOT NULL,
  `type_vente` enum('immediat','negociation','enchere') COLLATE utf8mb4_general_ci NOT NULL,
  `statut` enum('disponible','vendu','retire') COLLATE utf8mb4_general_ci DEFAULT 'disponible',
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_debut_enchere` datetime DEFAULT NULL,
  `date_fin_enchere` datetime DEFAULT NULL,
  `prix_actuel` float DEFAULT NULL,
  `type_marchandise` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'regulier',
  PRIMARY KEY (`id`),
  KEY `categorie_id` (`categorie_id`),
  KEY `vendeur_id` (`vendeur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id`, `titre`, `description`, `qualite`, `defaut`, `photo`, `video`, `prix_initial`, `categorie_id`, `vendeur_id`, `type_vente`, `statut`, `date_creation`, `date_debut_enchere`, `date_fin_enchere`, `prix_actuel`, `type_marchandise`) VALUES
(27, 'aée', 'eé', NULL, NULL, 'images/art_6834df4691feb.png', NULL, 1.00, 5, 4, 'immediat', 'vendu', '2025-05-26 23:38:14', NULL, NULL, NULL, 'haut_de_gamme'),
(45, 'Vase Romain', 'de l\'Age romaine', NULL, NULL, 'images/art_6836e2fa5e9a3.png', NULL, 150.00, 1, 4, 'immediat', 'vendu', '2025-05-28 12:18:34', NULL, NULL, NULL, 'haut_de_gamme'),
(46, 'Statue de bronze', 'Vendu par x2, statue grandeur nature 3m15.', NULL, NULL, 'images/art_6836e32d43034.png', NULL, 800.00, 6, 4, 'negociation', 'disponible', '2025-05-28 12:19:25', NULL, NULL, NULL, 'rare'),
(47, 'Coupe de soupe égyptienne', 'Efficace pour boire un bon soupé', NULL, NULL, 'images/art_6836e36aeb95e.png', NULL, 40.00, 2, 4, 'immediat', 'disponible', '2025-05-28 12:20:26', NULL, NULL, NULL, 'regulier'),
(48, 'Vase de platre', 'Bonne imitation de l\'Age Gallo romaine.', NULL, NULL, 'images/art_6836e392bbece.png', NULL, 30.00, 6, 4, 'negociation', 'disponible', '2025-05-28 12:21:06', NULL, NULL, NULL, 'regulier'),
(49, 'Statuette Dauphine Atlante', 'Tout droit sortie de l\'Atlantide', NULL, NULL, 'images/art_6836e3cfbbcb0.png', NULL, 5000.00, 1, 4, 'negociation', 'disponible', '2025-05-28 12:22:07', NULL, NULL, NULL, 'rare'),
(50, 'Statue de Dame', 'Grandeur nature 2m15, on raconte qu\'elle servait a boire dans les larges contrée', NULL, NULL, 'images/art_6836e4342f561.png', NULL, 900.00, 1, 4, 'immediat', 'vendu', '2025-05-28 12:23:48', NULL, NULL, NULL, 'haut_de_gamme'),
(51, 'Statue d\'enfance', 'Très mignon a mettre près des lavabo', NULL, NULL, 'images/art_6836e4f4db3a1.png', NULL, 345.00, 2, 17, 'negociation', 'disponible', '2025-05-28 12:27:00', NULL, NULL, NULL, 'haut_de_gamme'),
(58, 'test 2 supprimer', 'a supprimer', NULL, NULL, 'images/art_68371857d9ff6.png', NULL, 45.00, 1, 4, 'enchere', 'vendu', '2025-05-28 16:06:15', '2025-05-28 16:00:00', '2025-05-28 16:15:00', 56, 'regulier'),
(59, 'test 2 supprimer', 'sup', NULL, NULL, 'images/art_68371cfac4381.png', NULL, 45.00, 2, 4, 'enchere', 'vendu', '2025-05-28 16:26:02', '2025-05-25 15:00:00', '2025-05-28 16:30:00', 46, 'regulier'),
(60, 'test 2 supprimer', 'sup', NULL, NULL, 'images/art_6837212a86e3d.png', NULL, 45.00, 2, 4, 'enchere', 'vendu', '2025-05-28 16:43:54', '2025-05-20 10:00:00', '2025-05-28 16:50:00', 51, 'haut_de_gamme'),
(61, 'test 3 supprimer', 'TEST', NULL, NULL, 'images/art_683723b54c02f.png', NULL, 45.00, 2, 4, 'enchere', 'vendu', '2025-05-28 16:54:45', '2015-05-15 20:00:00', '2025-05-28 17:00:00', 51, 'regulier'),
(62, 'test 3 supprimer', 'test', NULL, NULL, 'images/art_68373990e4d1b.png', NULL, 45.00, 2, 4, 'enchere', 'vendu', '2025-05-28 18:28:00', '2024-05-15 10:00:00', '2025-05-28 18:30:00', 46, 'regulier'),
(63, 'test 3 supprimer', 'test', NULL, NULL, 'images/art_68373de22e859.png', NULL, 45.00, 2, 4, 'enchere', 'vendu', '2025-05-28 18:46:26', '2025-05-28 10:00:00', '2025-05-28 18:50:00', 46, 'regulier');

-- --------------------------------------------------------

--
-- Structure de la table `articlepanier`
--

DROP TABLE IF EXISTS `articlepanier`;
CREATE TABLE IF NOT EXISTS `articlepanier` (
  `panier_id` int NOT NULL,
  `article_id` int NOT NULL,
  `mode_achat` enum('immediat','negociation','enchere') COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`panier_id`,`article_id`),
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `carte`
--

DROP TABLE IF EXISTS `carte`;
CREATE TABLE IF NOT EXISTS `carte` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilisateur_id` int NOT NULL,
  `type` enum('Visa','MasterCard','Amex','PayPal') COLLATE utf8mb4_general_ci NOT NULL,
  `numero` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `nom_affiche` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `expiration` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `cvv` varchar(4) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `utilisateur_id` (`utilisateur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`) VALUES
(1, 'Objets d\'art'),
(2, 'Accessoires VIP'),
(3, 'Matériel scolaire'),
(4, 'Livres'),
(5, 'Informatique'),
(6, 'Décoration'),
(7, 'Textile'),
(8, 'Instruments de musique');

-- --------------------------------------------------------

--
-- Structure de la table `enchere`
--

DROP TABLE IF EXISTS `enchere`;
CREATE TABLE IF NOT EXISTS `enchere` (
  `id` int NOT NULL AUTO_INCREMENT,
  `article_id` int NOT NULL,
  `acheteur_id` int NOT NULL,
  `date_offre` datetime DEFAULT CURRENT_TIMESTAMP,
  `prix_max` float NOT NULL,
  `date_enchere` datetime NOT NULL,
  `etat` enum('en_cours','gagnant','perdu','finalise') COLLATE utf8mb4_general_ci DEFAULT 'en_cours',
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`),
  KEY `acheteur_id` (`acheteur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `enchere`
--

INSERT INTO `enchere` (`id`, `article_id`, `acheteur_id`, `date_offre`, `prix_max`, `date_enchere`, `etat`) VALUES
(18, 63, 17, '2025-05-28 18:47:13', 55, '2025-05-28 18:50:00', 'finalise');

-- --------------------------------------------------------

--
-- Structure de la table `methodepaiement`
--

DROP TABLE IF EXISTS `methodepaiement`;
CREATE TABLE IF NOT EXISTS `methodepaiement` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilisateur_id` int NOT NULL,
  `type_methode` enum('carte','virement','apple_pay','paypal') NOT NULL,
  `nom_affichage` varchar(100) NOT NULL,
  `details_cryptes` text,
  `est_defaut` tinyint(1) DEFAULT '0',
  `date_ajout` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_expiration` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `utilisateur_id` (`utilisateur_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `negociation`
--

DROP TABLE IF EXISTS `negociation`;
CREATE TABLE IF NOT EXISTS `negociation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `article_id` int NOT NULL,
  `acheteur_id` int NOT NULL,
  `vendeur_id` int NOT NULL,
  `tour` int NOT NULL DEFAULT '1',
  `offre_acheteur` decimal(10,2) NOT NULL,
  `contre_offre_vendeur` decimal(10,2) DEFAULT NULL,
  `etat` enum('en_cours','accepte','refuse','expire') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'en_cours',
  `date_action` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_expiration` datetime DEFAULT NULL,
  `commentaire_acheteur` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `commentaire_vendeur` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`),
  KEY `acheteur_id` (`acheteur_id`),
  KEY `vendeur_id` (`vendeur_id`),
  KEY `etat` (`etat`),
  KEY `date_action` (`date_action`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `negociation`
--

INSERT INTO `negociation` (`id`, `article_id`, `acheteur_id`, `vendeur_id`, `tour`, `offre_acheteur`, `contre_offre_vendeur`, `etat`, `date_action`, `date_expiration`, `commentaire_acheteur`, `commentaire_vendeur`) VALUES
(1, 49, 17, 4, 1, 4000.00, NULL, 'en_cours', '2025-05-28 19:28:06', NULL, NULL, NULL),
(2, 49, 17, 4, 2, 3000.00, NULL, 'en_cours', '2025-05-28 19:29:23', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `contenu` text COLLATE utf8mb4_general_ci NOT NULL,
  `date_creation` datetime NOT NULL,
  `lu` tinyint(1) DEFAULT '0',
  `article_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `notification`
--

INSERT INTO `notification` (`id`, `user_id`, `contenu`, `date_creation`, `lu`, `article_id`) VALUES
(3, 4, 'Le vendeur a fait une contre-offre (1 222,00 €) sur l\'article « 12 ». Consultez votre historique de négociation !', '2025-05-26 22:41:03', 1, NULL),
(5, 4, 'Le vendeur a fait une contre-offre (20 000,00 €) sur l\'article « 12 ». Consultez votre historique de négociation !', '2025-05-26 22:42:53', 1, NULL),
(7, 4, 'Votre offre sur l\'article « 12 » a été refusée par le vendeur.', '2025-05-26 22:43:44', 1, NULL),
(8, 4, 'Votre offre sur l\'article « 12 » a été acceptée par le vendeur !', '2025-05-26 22:43:44', 1, NULL),
(12, 4, 'Le vendeur a fait une contre-offre (0,00 €) sur l\'article « fzfze ». Consultez votre historique de négociation !', '2025-05-26 23:04:48', 1, 20),
(13, 4, 'Le vendeur a fait une contre-offre (123,00 €) sur l\'article « fzfze ». Consultez votre historique de négociation !', '2025-05-26 23:04:52', 1, 20),
(15, 4, 'Un nouvel article correspondant à votre alerte est disponible : \"les misérables\"', '2025-05-26 21:26:20', 1, 24),
(30, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=32\'>un bg</a>', '2025-05-27 11:27:07', 1, 32),
(32, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=32\'>un bg</a>', '2025-05-27 11:27:07', 1, 32),
(33, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=33\'>rox en l\\\'air</a>', '2025-05-27 12:37:03', 1, 33),
(42, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=40\'>zdazd</a>', '2025-05-27 18:29:33', 1, 40),
(43, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=40\'>zdazd</a>', '2025-05-27 18:29:33', 1, 40),
(46, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=42\'>un bg</a>', '2025-05-28 09:42:39', 1, 42),
(47, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=42\'>un bg</a>', '2025-05-28 09:42:39', 1, 42),
(52, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=47\'>Coupe de soupe égyptienne</a>', '2025-05-28 10:20:26', 1, 47),
(53, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=47\'>Coupe de soupe égyptienne</a>', '2025-05-28 10:20:26', 1, 47),
(55, 4, 'Un nouvel article correspondant à votre alerte est disponible : <a href=\'article.php?id=51\'>Statue d\\\'enfance</a>', '2025-05-28 10:27:00', 1, 51),
(56, 17, 'Votre offre sur l\'article « Vase de platre » a été refusée par le vendeur.', '2025-05-28 14:15:13', 1, 48),
(57, 17, 'Votre offre sur l\'article « Vase de platre » a été acceptée par le vendeur !', '2025-05-28 14:15:13', 1, 48),
(61, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 2 supprimer (enchère max : 55,00 €)', '2025-05-28 16:12:04', 1, 58),
(62, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 2 supprimer (enchère max : 50,00 €)', '2025-05-28 16:12:50', 1, 58),
(63, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 2 supprimer (enchère max : 60,00 €)', '2025-05-28 16:14:09', 1, 58),
(64, 19, 'Félicitations ! Vous avez gagné l\'enchère pour l\'article \'test 2 supprimer\' pour 56.00€. Vous pouvez maintenant finaliser votre achat.', '2025-05-28 16:15:06', 1, 58),
(65, 4, 'Votre article \'test 2 supprimer\' a été vendu aux enchères pour 56.00€.', '2025-05-28 16:15:06', 1, 58),
(66, 17, 'L\'enchère pour l\'article \'test 2 supprimer\' s\'est terminée. Vous n\'avez malheureusement pas remporté cette enchère.', '2025-05-28 16:15:06', 1, 58),
(67, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 2 supprimer (enchère max : 50,00 €)', '2025-05-28 16:26:27', 1, 59),
(68, 19, 'Félicitations ! Vous avez gagné l\'enchère pour l\'article \'test 2 supprimer\' pour 46.00€. Vous pouvez maintenant finaliser votre achat.', '2025-05-28 16:32:31', 1, 59),
(69, 4, 'Votre article \'test 2 supprimer\' a été vendu aux enchères pour 46.00€.', '2025-05-28 16:32:31', 1, 59),
(70, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 2 supprimer (enchère max : 50,00 €)', '2025-05-28 16:44:28', 1, 60),
(71, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 2 supprimer (enchère max : 50,00 €)', '2025-05-28 16:47:02', 1, 60),
(72, 19, 'Félicitations ! Vous avez gagné l\'enchère pour l\'article \'test 2 supprimer\' pour 51.00€. Vous pouvez maintenant finaliser votre achat.', '2025-05-28 16:50:03', 1, 60),
(73, 4, 'Votre article \'test 2 supprimer\' a été vendu aux enchères pour 51.00€.', '2025-05-28 16:50:03', 1, 60),
(74, 17, 'L\'enchère pour l\'article \'test 2 supprimer\' s\'est terminée. Vous n\'avez malheureusement pas remporté cette enchère.', '2025-05-28 16:50:03', 1, 60),
(75, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 3 supprimer (enchère max : 50,00 €)', '2025-05-28 16:55:03', 1, 61),
(76, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 3 supprimer (enchère max : 50,00 €)', '2025-05-28 16:56:13', 1, 61),
(77, 17, 'Félicitations ! Vous avez gagné l\'enchère pour l\'article \'test 3 supprimer\' pour 51.00€. Vous pouvez maintenant finaliser votre achat.', '2025-05-28 17:00:03', 1, 61),
(78, 4, 'Votre article \'test 3 supprimer\' a été vendu aux enchères pour 51.00€.', '2025-05-28 17:00:03', 1, 61),
(79, 19, 'L\'enchère pour l\'article \'test 3 supprimer\' s\'est terminée. Vous n\'avez malheureusement pas remporté cette enchère.', '2025-05-28 17:00:03', 1, 61),
(80, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 3 supprimer (enchère max : 50,00 €)', '2025-05-28 18:28:56', 1, 62),
(81, 19, 'Félicitations ! Vous avez gagné l\'enchère pour l\'article \'test 3 supprimer\' pour 46.00€. Vous pouvez maintenant finaliser votre achat.', '2025-05-28 18:30:03', 1, 62),
(82, 4, 'Votre article \'test 3 supprimer\' a été vendu aux enchères pour 46.00€.', '2025-05-28 18:30:03', 1, 62),
(83, 4, 'Nouvelle enchère automatique de Benjamin Assouline sur l\'article : test 3 supprimer (enchère max : 55,00 €)', '2025-05-28 18:47:13', 1, 63),
(84, 17, 'Félicitations ! Vous avez gagné l\'enchère pour l\'article \'test 3 supprimer\' pour 46.00€. Vous pouvez maintenant finaliser votre achat.', '2025-05-28 18:50:00', 1, 63),
(85, 4, 'Votre article \'test 3 supprimer\' a été vendu aux enchères pour 46.00€.', '2025-05-28 18:50:00', 1, 63);

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

DROP TABLE IF EXISTS `panier`;
CREATE TABLE IF NOT EXISTS `panier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acheteur_id` int NOT NULL,
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `acheteur_id` (`acheteur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `panier`
--

INSERT INTO `panier` (`id`, `acheteur_id`, `date_creation`) VALUES
(1, 4, '2025-05-26 21:02:56'),
(6, 17, '2025-05-27 17:04:48'),
(7, 19, '2025-05-28 15:26:35');

-- --------------------------------------------------------

--
-- Structure de la table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acheteur_id` int NOT NULL,
  `article_id` int NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `mode_paiement` enum('carte','paypal','cheque-cadeau') COLLATE utf8mb4_general_ci NOT NULL,
  `date_paiement` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `acheteur_id` (`acheteur_id`),
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `transaction`
--

INSERT INTO `transaction` (`id`, `acheteur_id`, `article_id`, `montant`, `mode_paiement`, `date_paiement`) VALUES
(9, 17, 27, 1.00, 'carte', '2025-05-27 19:52:50'),
(16, 17, 50, 900.00, 'paypal', '2025-05-28 13:25:30'),
(17, 17, 45, 150.00, 'paypal', '2025-05-28 15:27:15'),
(26, 17, 61, 51.00, 'paypal', '2025-05-28 18:26:15'),
(27, 19, 61, 51.00, 'paypal', '2025-05-28 18:29:23'),
(28, 19, 62, 46.00, 'paypal', '2025-05-28 18:30:15'),
(29, 19, 61, 51.00, 'paypal', '2025-05-28 18:30:49'),
(30, 19, 61, 51.00, 'paypal', '2025-05-28 18:36:13'),
(33, 17, 63, 46.00, 'paypal', '2025-05-28 19:09:23'),
(34, 17, 63, 46.00, 'paypal', '2025-05-28 19:21:50');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `prenom` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `mot_de_passe` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('acheteur','vendeur','admin') COLLATE utf8mb4_general_ci NOT NULL,
  `adresse_ligne1` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `adresse_ligne2` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ville` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code_postal` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pays` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `telephone` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `image_fond` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `prenom`, `email`, `mot_de_passe`, `role`, `adresse_ligne1`, `adresse_ligne2`, `ville`, `code_postal`, `pays`, `telephone`, `photo`, `image_fond`) VALUES
(1, 'lucas', 'leblond', 'lucassurf0907@gmail.com', '$2y$10$o22r37Sbxk/kE7K91QpDlueSP52TV50ETHtQHh20BcNhk/xuhPsty', 'vendeur', '4 route de dampierre', '', 'Lévis saint nom', '78320', 'france', '0695384996', NULL, NULL),
(3, 'admin', 'admin', 'admin@gmail.fr', 'admin1234', 'admin', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Admin', 'Admin', 'admin@agora.fr', '$2y$10$NhRDxNC/YVmR45iklfIU8.Zkj/Ky5UptSJOQ2u1tpsdurSDK5lTAu', 'admin', '', '', '', '', '', '', 'images/profile_6836e3d74c8cc.png', NULL),
(17, 'Assouline', 'Benjamin', 'benassou423@gmail.com', '$2y$10$ZUzAWMuFa8kCiLrOxFnZseGuv..rQAnK6yutdCNEjPM8qITG7j87q', 'vendeur', '3bis rue vergniaud', '3e etage; interphone assouline', 'LEVALLOIS PERRET', '92300', 'France', '0768662789', 'images/profile_6836fdf04fcd9.png', NULL),
(19, 'Assouline', 'Benjamin', 'assoulineben@gmail.com', '$2y$10$HVCGpPAmxuevYoWWI1eNSOqo6CzGC17bUPcHi0M4WN6BlaH.9eVR.', 'acheteur', '3bis rue vergniaud', '3e etage; interphone assouline', 'LEVALLOIS PERRET', '92300', 'France', '0768662789', NULL, NULL),
(20, 'Assouline', 'Benjamin', 'letrou@gmail.com', '$2y$10$vf1cERQ4KyQ4Su0JRRZNue4lcOJaIPNLwDX0Y4e04gqnlDrkP52cq', 'acheteur', '3bis rue vergniaud', '3e etage; interphone assouline', 'LEVALLOIS PERRET', '92300', 'France', '0768662789', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `vente`
--

DROP TABLE IF EXISTS `vente`;
CREATE TABLE IF NOT EXISTS `vente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `article_id` int NOT NULL,
  `type` enum('immediat','negociation','enchere') COLLATE utf8mb4_general_ci NOT NULL,
  `date_debut` datetime DEFAULT NULL,
  `date_fin` datetime DEFAULT NULL,
  `prix_min` decimal(10,2) DEFAULT NULL,
  `prix_final` decimal(10,2) DEFAULT NULL,
  `gagnant_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `article_id` (`article_id`),
  KEY `gagnant_id` (`gagnant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `achat`
--
ALTER TABLE `achat`
  ADD CONSTRAINT `achat_ibfk_1` FOREIGN KEY (`acheteur_id`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `achat_ibfk_2` FOREIGN KEY (`vendeur_id`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `achat_ibfk_3` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `achat_ibfk_4` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `alerte`
--
ALTER TABLE `alerte`
  ADD CONSTRAINT `alerte_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `alerte_ibfk_2` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`);

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `article_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`),
  ADD CONSTRAINT `article_ibfk_2` FOREIGN KEY (`vendeur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `articlepanier`
--
ALTER TABLE `articlepanier`
  ADD CONSTRAINT `articlepanier_ibfk_1` FOREIGN KEY (`panier_id`) REFERENCES `panier` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `articlepanier_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`);

--
-- Contraintes pour la table `carte`
--
ALTER TABLE `carte`
  ADD CONSTRAINT `carte_ibfk_1` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `enchere`
--
ALTER TABLE `enchere`
  ADD CONSTRAINT `enchere_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  ADD CONSTRAINT `enchere_ibfk_2` FOREIGN KEY (`acheteur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `negociation`
--
ALTER TABLE `negociation`
  ADD CONSTRAINT `negociation_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `negociation_ibfk_2` FOREIGN KEY (`acheteur_id`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `negociation_ibfk_3` FOREIGN KEY (`vendeur_id`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateur` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `panier`
--
ALTER TABLE `panier`
  ADD CONSTRAINT `panier_ibfk_1` FOREIGN KEY (`acheteur_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`acheteur_id`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`);

--
-- Contraintes pour la table `vente`
--
ALTER TABLE `vente`
  ADD CONSTRAINT `vente_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  ADD CONSTRAINT `vente_ibfk_2` FOREIGN KEY (`gagnant_id`) REFERENCES `utilisateur` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

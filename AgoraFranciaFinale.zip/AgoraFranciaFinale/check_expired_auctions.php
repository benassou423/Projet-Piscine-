<?php
// Script de vérification des enchères expirées à exécuter périodiquement
// Peut être appelé via cron job ou lors de certaines actions du site

include_once "db.php";
require_once "systeme_enchere_automatique.php";

// Utiliser le nouveau système d'enchères automatiques pour vérifier les enchères expirées
$systeme_enchere = new SystemeEnchereAutomatique($db_handle);
$systeme_enchere->verifierEncheresExpirees();

// Vérifier les négociations expirées (plus de 7 jours sans réponse)
$sql_nego_expirees = "SELECT n.*, a.titre as article_nom 
                     FROM negociation n
                     JOIN article a ON n.article_id = a.id 
                     WHERE n.etat = 'en cours' 
                     AND n.date_action < DATE_SUB(NOW(), INTERVAL 7 DAY)";

$result_nego_expirees = mysqli_query($db_handle, $sql_nego_expirees);

while ($result_nego_expirees && $nego = mysqli_fetch_assoc($result_nego_expirees)) {
    // Marquer comme expirée
    $sql_expire = "UPDATE negociation SET etat = 'expire' WHERE id = {$nego['id']}";
    mysqli_query($db_handle, $sql_expire);
      // Notifier l'acheteur
    $article_nom = mysqli_real_escape_string($db_handle, $nego['article_nom']);
    $contenu_expire = "Votre négociation pour l'article '$article_nom' a expiré faute de réponse du vendeur.";
    $contenu_expire = mysqli_real_escape_string($db_handle, $contenu_expire);
    $sql_notif_expire = "INSERT INTO notification (user_id, contenu, date_creation, article_id) 
                        VALUES ({$nego['acheteur_id']}, '$contenu_expire', NOW(), {$nego['article_id']})";
    mysqli_query($db_handle, $sql_notif_expire);
}

// Vérification des enchères et négociations terminée silencieusement
?>

<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include_once "db.php";

// Compteur de notifications non lues
$notif_count = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
    $sql_notif = "SELECT COUNT(*) AS nb FROM Notification WHERE user_id=$user_id AND lu=0";
    $result_notif = mysqli_query($db_handle, $sql_notif);
    if ($result_notif && $row = mysqli_fetch_assoc($result_notif)) {
        $notif_count = $row['nb'];
    }
}
$panier_count = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
    // Chercher le panier
    $sql_pan = "SELECT id FROM Panier WHERE acheteur_id=$user_id";
    $result_pan = mysqli_query($db_handle, $sql_pan);
    if ($result_pan && $row = mysqli_fetch_assoc($result_pan)) {
        $panier_id = $row['id'];
        $sql_count = "SELECT COUNT(*) AS nb FROM ArticlePanier WHERE panier_id=$panier_id";
        $result_count = mysqli_query($db_handle, $sql_count);
        if ($result_count && $row2 = mysqli_fetch_assoc($result_count)) {
            $panier_count = $row2['nb'];
        }
    }
}

?>
<!-- Bootstrap Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
<!-- HEADER -->
<div class="header">
    <img src="images/logo agora.png" alt="Logo Agora Francia">
</div>
<!-- NAVIGATION -->
<nav class="navigation">
    <a href="index.php"><i class="bi bi-house-door"></i> Accueil</a>
    <a href="catalogue.php"><i class="bi bi-grid-3x3-gap"></i> Tout Parcourir</a>
    <a href="notifications.php" class="nav-link-notif">
        <i class="bi bi-bell"></i> Notifications
        <?php if ($notif_count > 0): ?>
            <span class="notif-badge"><?= $notif_count ?></span>
        <?php endif; ?>
    </a>
    <a href="panier.php" class="nav-link-panier">
        <i class="bi bi-cart3"></i> Panier
        <?php if ($panier_count > 0): ?>
            <span class="panier-badge"><?= $panier_count ?></span>
        <?php endif; ?>
    </a>
    <?php if (isset($_SESSION['user_id'])): ?>
        <div class="dropdown">
            <a href="#" class="dropdown-toggle" onclick="return false;" aria-expanded="false" aria-haspopup="true" role="button" tabindex="0">
                <i class="bi bi-bag-check"></i> Mes Achats <i class="bi bi-chevron-down dropdown-arrow"></i>
            </a>
            <ul class="dropdown-menu" role="menu" aria-label="Menu Mes Achats">
                <li role="none"><a class="dropdown-item" href="mes_achats.php" role="menuitem"><i class="bi bi-bag-check"></i> Mes Achats</a></li>
                <li role="none"><a class="dropdown-item" href="mes_encheres.php" role="menuitem"><i class="bi bi-hammer"></i> Mes Enchères</a></li>
                <li role="none"><a class="dropdown-item" href="mes_offres.php" role="menuitem"><i class="bi bi-chat-dots"></i> Mes Offres</a></li>
            </ul>
        </div>
    <?php endif; ?>
    <a href="compte.php" class="user-profile">
        <?php if (isset($_SESSION['user_id'])): ?>
            <?php if (isset($_SESSION['user_photo']) && !empty($_SESSION['user_photo'])): ?>
                <img src="<?= htmlspecialchars($_SESSION['user_photo']) ?>" class="profile-mini" alt="Photo de profil">
            <?php else: ?>
                <span class="default-profile-icon">
                    <i class="bi bi-person"></i>
                </span>
            <?php endif; ?>
        <?php else: ?>
            <i class="bi bi-person"></i>
        <?php endif; ?>
        Votre Compte
    </a>
    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin'): ?>
        <a href="admin.php"><i class="bi bi-gear"></i>Administration</a>
    <?php endif; ?>
    <?php
        if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['vendeur', 'admin'])) {
            echo '<a href="ajout_article.php"><i class="bi bi-plus-circle"></i>Ajouter un article</a>';
        }
    ?>
</nav>

<!-- Script pour améliorer la navigation du dropdown -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const dropdown = document.querySelector('.navigation .dropdown');
    const dropdownToggle = document.querySelector('.navigation .dropdown-toggle');
    const dropdownMenu = document.querySelector('.navigation .dropdown-menu');
    
    if (!dropdown || !dropdownToggle || !dropdownMenu) return;
    
    let hideTimeout;
    
    // Fonction pour afficher le menu
    function showMenu() {
        clearTimeout(hideTimeout);
        dropdown.classList.add('active');
        dropdownMenu.classList.add('show');
        dropdownToggle.setAttribute('aria-expanded', 'true');
    }
    
    // Fonction pour masquer le menu avec délai
    function hideMenu() {
        hideTimeout = setTimeout(() => {
            dropdown.classList.remove('active');
            dropdownMenu.classList.remove('show');
            dropdownToggle.setAttribute('aria-expanded', 'false');
        }, 150);
    }
    
    // Événements pour le toggle
    dropdownToggle.addEventListener('mouseenter', showMenu);
    dropdownToggle.addEventListener('mouseleave', hideMenu);
    dropdownToggle.addEventListener('focus', showMenu);
    
    // Événements pour le menu
    dropdownMenu.addEventListener('mouseenter', showMenu);
    dropdownMenu.addEventListener('mouseleave', hideMenu);
    
    // Navigation au clavier
    dropdownToggle.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
            e.preventDefault();
            showMenu();
            
            if (e.key === 'ArrowDown') {
                const firstItem = dropdownMenu.querySelector('.dropdown-item');
                if (firstItem) firstItem.focus();
            }
        } else if (e.key === 'Escape') {
            hideMenu();
            dropdownToggle.blur();
        }
    });
    
    // Navigation dans le menu
    const dropdownItems = dropdownMenu.querySelectorAll('.dropdown-item');
    dropdownItems.forEach((item, index) => {
        item.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                const next = dropdownItems[index + 1] || dropdownItems[0];
                next.focus();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                const prev = dropdownItems[index - 1] || dropdownItems[dropdownItems.length - 1];
                prev.focus();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                hideMenu();
                dropdownToggle.focus();
            } else if (e.key === 'Tab') {
                hideMenu();
            }
        });
        
        item.addEventListener('blur', function(e) {
            // Si le focus ne va pas vers un autre élément du dropdown, on ferme
            if (!dropdown.contains(e.relatedTarget)) {
                hideMenu();
            }
        });
    });
    
    // Fermer le menu si on clique ailleurs
    document.addEventListener('click', function(e) {
        if (!dropdown.contains(e.target)) {
            hideMenu();
        }
    });
    
    // Améliorer le clic sur le toggle
    dropdownToggle.addEventListener('click', function(e) {
        e.preventDefault();
        if (dropdown.classList.contains('active')) {
            hideMenu();
        } else {
            showMenu();
        }
    });
});
</script>

<?php
session_start();
// Sécurité : accès réservé à l'admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Administration | Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style-site.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        .admin-title {
            color: #2c3e50;
            font-weight: 600;
            font-size: 2.5rem;
            margin-bottom: 2rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            border-radius: 15px 15px 0 0 !important;
            font-weight: 500;
            font-size: 1.2rem;
            padding: 1.25rem;
        }
        .btn-custom {
            border-radius: 10px;
            font-weight: 500;
            padding: 12px 20px;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
        }
        .btn-custom:hover {
            transform: scale(1.02);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .btn-logout {
            background: linear-gradient(45deg, #e74c3c, #c0392b);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .btn-logout:hover {
            background: linear-gradient(45deg, #c0392b, #e74c3c);
            transform: scale(1.05);
            color: white;
        }
        .card-body {
            padding: 2rem;
        }
        .list-unstyled li:last-child {
            margin-bottom: 0 !important;
        }
    </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="container mt-5">
    <h1 class="admin-title text-center mb-5">Espace Administration</h1>

    <div class="row justify-content-center">
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-gradient text-white" style="background-color: #3498db;">
                    Gestion des Utilisateurs
                </div>
                <div class="card-body p-4">
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <a href="admin_gestion_acheteurs.php" class="btn btn-custom btn-outline-primary w-100">
                                Gérer les acheteurs
                            </a>
                        </li>
                        <li class="mb-3">
                            <a href="admin_gestion_vendeurs.php" class="btn btn-custom btn-outline-primary w-100">
                                Gérer les vendeurs
                            </a>
                        </li>
                        <li class="mb-3">
                            <a href="admin_gestion_categories.php" class="btn btn-custom btn-outline-primary w-100">
                                Gérer les catégories
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center mt-5">
        <a href="logout.php" class="btn btn-logout">Se déconnecter</a>
    </div>
</div>

<?php include 'footer.php'; ?>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

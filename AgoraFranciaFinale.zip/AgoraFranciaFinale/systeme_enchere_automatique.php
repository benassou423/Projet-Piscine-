<?php
/**
 * Système d'Enchères Automatiques (Proxy Bidding)
 * 
 * Ce système gère les enchères automatiques selon les spécifications suivantes :
 * 1. L'utilisateur définit une enchère maximale
 * 2. Le système enchérit automatiquement jusqu'à ce maximum
 * 3. Le prix final est le minimum nécessaire pour gagner (pas le maximum)
 * 4. Les enchères se terminent automatiquement à la date/heure prévue
 */

class SystemeEnchereAutomatique {
    private $db_handle;
    
    public function __construct($db_handle) {
        $this->db_handle = $db_handle;
    }
    
    /**
     * Place ou met à jour une enchère automatique
     */    public function placerEnchereAutomatique($article_id, $acheteur_id, $prix_max) {
        // Définir le fuseau horaire explicitement pour éviter les décalages
        date_default_timezone_set('Europe/Paris');
        
        // Vérifier que l'article existe et est en cours d'enchère
        $sql_article = "SELECT * FROM article WHERE id = ? AND type_vente = 'enchere' AND statut = 'disponible'";
        $stmt = mysqli_prepare($this->db_handle, $sql_article);
        mysqli_stmt_bind_param($stmt, "i", $article_id);
        mysqli_stmt_execute($stmt);
        $result_article = mysqli_stmt_get_result($stmt);
        $article = mysqli_fetch_assoc($result_article);
        
        if (!$article) {
            return ['success' => false, 'message' => 'Article non trouvé ou enchère non disponible'];
        }
        
        // Vérifier que l'enchère est en cours
        $maintenant = date('Y-m-d H:i:s');
        if ($maintenant < $article['date_debut_enchere'] || $maintenant > $article['date_fin_enchere']) {
            return ['success' => false, 'message' => 'L\'enchère n\'est pas en cours'];
        }
        
        // Vérifier que l'acheteur n'est pas le vendeur
        if ($acheteur_id == $article['vendeur_id']) {
            return ['success' => false, 'message' => 'Le vendeur ne peut pas enchérir sur son propre article'];
        }
        
        // Vérifier que le prix maximum est suffisant
        $prix_actuel = $article['prix_actuel'] ?? $article['prix_initial'];
        if ($prix_max <= $prix_actuel) {
            return ['success' => false, 'message' => 'Votre enchère maximale doit être supérieure au prix actuel'];
        }
        
        // Chercher si l'utilisateur a déjà une enchère sur cet article
        $sql_existing = "SELECT * FROM enchere WHERE article_id = ? AND acheteur_id = ?";
        $stmt = mysqli_prepare($this->db_handle, $sql_existing);
        mysqli_stmt_bind_param($stmt, "ii", $article_id, $acheteur_id);
        mysqli_stmt_execute($stmt);
        $result_existing = mysqli_stmt_get_result($stmt);
        $existing_bid = mysqli_fetch_assoc($result_existing);
        
        if ($existing_bid) {
            // Mettre à jour l'enchère existante
            $sql_update = "UPDATE enchere SET prix_max = ?, date_offre = NOW() 
                          WHERE article_id = ? AND acheteur_id = ?";
            $stmt = mysqli_prepare($this->db_handle, $sql_update);
            mysqli_stmt_bind_param($stmt, "dii", $prix_max, $article_id, $acheteur_id);
            $success = mysqli_stmt_execute($stmt);
            
            if ($success) {
                // Recalculer le prix actuel
                $this->recalculerPrixActuel($article_id);
                return ['success' => true, 'message' => 'Votre enchère maximale a été mise à jour'];
            }
        } else {
            // Créer une nouvelle enchère
            $sql_insert = "INSERT INTO enchere (article_id, acheteur_id, prix_max, date_offre, date_enchere) 
                          VALUES (?, ?, ?, NOW(), ?)";
            $stmt = mysqli_prepare($this->db_handle, $sql_insert);
            $date_fin = $article['date_fin_enchere'];
            mysqli_stmt_bind_param($stmt, "iids", $article_id, $acheteur_id, $prix_max, $date_fin);
            $success = mysqli_stmt_execute($stmt);
            
            if ($success) {
                // Recalculer le prix actuel
                $this->recalculerPrixActuel($article_id);
                return ['success' => true, 'message' => 'Votre enchère a été enregistrée'];
            }
        }
        
        return ['success' => false, 'message' => 'Erreur lors de l\'enregistrement de l\'enchère'];
    }
    
    /**
     * Recalcule le prix actuel selon la logique des enchères automatiques
     * Le prix actuel est le minimum nécessaire pour être en tête
     */
    public function recalculerPrixActuel($article_id) {
        // Récupérer l'article
        $sql_article = "SELECT * FROM article WHERE id = ?";
        $stmt = mysqli_prepare($this->db_handle, $sql_article);
        mysqli_stmt_bind_param($stmt, "i", $article_id);
        mysqli_stmt_execute($stmt);
        $result_article = mysqli_stmt_get_result($stmt);
        $article = mysqli_fetch_assoc($result_article);
        
        if (!$article) {
            return false;
        }
        
        // Récupérer toutes les enchères triées par prix_max décroissant
        $sql_encheres = "SELECT prix_max FROM enchere WHERE article_id = ? ORDER BY prix_max DESC, date_offre ASC";
        $stmt = mysqli_prepare($this->db_handle, $sql_encheres);
        mysqli_stmt_bind_param($stmt, "i", $article_id);
        mysqli_stmt_execute($stmt);
        $result_encheres = mysqli_stmt_get_result($stmt);
        
        $encheres = [];
        while ($row = mysqli_fetch_assoc($result_encheres)) {
            $encheres[] = $row['prix_max'];
        }
        
        // Calculer le nouveau prix actuel
        $prix_initial = $article['prix_initial'];
        $nouveau_prix_actuel = $prix_initial;
        
        if (count($encheres) == 0) {
            // Aucune enchère, prix reste au prix initial
            $nouveau_prix_actuel = $prix_initial;
        } elseif (count($encheres) == 1) {
            // Une seule enchère, prix actuel = prix initial + 1 (ou minimum d'enchère)
            $nouveau_prix_actuel = $prix_initial + 1;
        } else {
            // Plusieurs enchères, prix actuel = deuxième meilleure enchère + 1
            $meilleure_enchere = $encheres[0];
            $deuxieme_enchere = $encheres[1];
            $nouveau_prix_actuel = min($deuxieme_enchere + 1, $meilleure_enchere);
        }
        
        // Mettre à jour le prix actuel dans la base
        $sql_update = "UPDATE Article SET prix_actuel = ? WHERE id = ?";
        $stmt = mysqli_prepare($this->db_handle, $sql_update);
        mysqli_stmt_bind_param($stmt, "di", $nouveau_prix_actuel, $article_id);
        return mysqli_stmt_execute($stmt);
    }
    
    /**
     * Obtient l'enchère gagnante actuelle pour un article
     */
    public function obtenirEnchereGagnante($article_id) {
        $sql = "SELECT e.*, u.nom, u.prenom, u.email 
                FROM enchere e 
                JOIN Utilisateur u ON e.acheteur_id = u.id 
                WHERE e.article_id = ? 
                ORDER BY e.prix_max DESC, e.date_offre ASC 
                LIMIT 1";
        $stmt = mysqli_prepare($this->db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $article_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($result);
    }
    
    /**
     * Vérifie et termine les enchères expirées
     */    public function verifierEncheresExpirees() {
        // Définir le fuseau horaire explicitement pour éviter les décalages
        date_default_timezone_set('Europe/Paris');
        $maintenant = date('Y-m-d H:i:s');
        
        // Trouver les enchères qui viennent de se terminer
        $sql_terminees = "SELECT DISTINCT a.id as article_id, a.titre as article_nom, a.vendeur_id
                         FROM article a
                         WHERE a.type_vente = 'enchere'
                         AND a.date_fin_enchere <= ?
                         AND a.statut = 'disponible'";
        
        $stmt = mysqli_prepare($this->db_handle, $sql_terminees);
        mysqli_stmt_bind_param($stmt, "s", $maintenant);
        mysqli_stmt_execute($stmt);
        $result_terminees = mysqli_stmt_get_result($stmt);
        
        while ($result_terminees && $enchere_finie = mysqli_fetch_assoc($result_terminees)) {
            $article_id = $enchere_finie['article_id'];
            $article_nom = $enchere_finie['article_nom'];
            $vendeur_id = $enchere_finie['vendeur_id'];
            
            // Obtenir l'enchère gagnante
            $enchere_gagnante = $this->obtenirEnchereGagnante($article_id);
              if ($enchere_gagnante) {
                // Il y a un gagnant
                $gagnant_id = $enchere_gagnante['acheteur_id'];
                $prix_final = $this->calculerPrixFinal($article_id);
                
                // Marquer l'article comme vendu (en attente de paiement)
                $sql_update = "UPDATE article SET statut = 'vendu' WHERE id = ?";
                $stmt = mysqli_prepare($this->db_handle, $sql_update);
                mysqli_stmt_bind_param($stmt, "i", $article_id);
                mysqli_stmt_execute($stmt);
                
                // Mettre à jour le statut de l'enchère gagnante
                $sql_update_winner = "UPDATE enchere SET etat = 'gagnant' 
                                     WHERE article_id = ? AND acheteur_id = ?";
                $stmt_winner = mysqli_prepare($this->db_handle, $sql_update_winner);
                mysqli_stmt_bind_param($stmt_winner, "ii", $article_id, $gagnant_id);
                mysqli_stmt_execute($stmt_winner);
                
                // Mettre à jour les autres enchères comme perdues
                $sql_update_losers = "UPDATE enchere SET etat = 'perdu' 
                                     WHERE article_id = ? AND acheteur_id != ?";
                $stmt_losers = mysqli_prepare($this->db_handle, $sql_update_losers);
                mysqli_stmt_bind_param($stmt_losers, "ii", $article_id, $gagnant_id);
                mysqli_stmt_execute($stmt_losers);
                
                // Notifier le gagnant
                $contenu_gagnant = "Félicitations ! Vous avez gagné l'enchère pour l'article '" . 
                                  mysqli_real_escape_string($this->db_handle, $article_nom) . 
                                  "' pour " . number_format($prix_final, 2) . "€. Vous pouvez maintenant finaliser votre achat.";
                $this->envoyerNotification($gagnant_id, $contenu_gagnant, $article_id);
                
                // Notifier le vendeur
                $contenu_vendeur = "Votre article '" . mysqli_real_escape_string($this->db_handle, $article_nom) . 
                                  "' a été vendu aux enchères pour " . number_format($prix_final, 2) . "€.";
                $this->envoyerNotification($vendeur_id, $contenu_vendeur, $article_id);
                
                // Notifier les perdants
                $this->notifierPerdants($article_id, $gagnant_id, $article_nom);
                
            } else {
                // Aucune enchère
                $contenu_vendeur = "L'enchère pour votre article '" . mysqli_real_escape_string($this->db_handle, $article_nom) . 
                                  "' s'est terminée sans aucune offre.";
                $this->envoyerNotification($vendeur_id, $contenu_vendeur, $article_id);
            }
        }
    }
    
    /**
     * Calcule le prix final à payer (qui peut être différent de l'enchère maximale)
     */
    private function calculerPrixFinal($article_id) {
        // Le prix final est le prix actuel calculé automatiquement
        $sql = "SELECT prix_actuel, prix_initial FROM article WHERE id = ?";
        $stmt = mysqli_prepare($this->db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $article_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $article = mysqli_fetch_assoc($result);
        
        return $article['prix_actuel'] ?? $article['prix_initial'];
    }
    
    /**
     * Envoie une notification à un utilisateur
     */
    private function envoyerNotification($user_id, $contenu, $article_id = null) {
        $sql = "INSERT INTO notification (user_id, contenu, date_creation, article_id) VALUES (?, ?, NOW(), ?)";
        $stmt = mysqli_prepare($this->db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "isi", $user_id, $contenu, $article_id);
        return mysqli_stmt_execute($stmt);
    }
    
    /**
     * Notifie tous les perdants d'une enchère
     */
    private function notifierPerdants($article_id, $gagnant_id, $article_nom) {
        $sql_perdants = "SELECT DISTINCT acheteur_id FROM enchere WHERE article_id = ? AND acheteur_id != ?";
        $stmt = mysqli_prepare($this->db_handle, $sql_perdants);
        mysqli_stmt_bind_param($stmt, "ii", $article_id, $gagnant_id);
        mysqli_stmt_execute($stmt);
        $result_perdants = mysqli_stmt_get_result($stmt);
        
        while ($perdant = mysqli_fetch_assoc($result_perdants)) {
            $contenu_perdant = "L'enchère pour l'article '" . mysqli_real_escape_string($this->db_handle, $article_nom) . 
                              "' s'est terminée. Vous n'avez malheureusement pas remporté cette enchère.";
            $this->envoyerNotification($perdant['acheteur_id'], $contenu_perdant, $article_id);
        }
    }
    
    /**
     * Obtient le statut d'enchère pour un utilisateur sur un article
     */
    public function obtenirStatutEnchereUtilisateur($article_id, $acheteur_id) {
        // Vérifier si l'utilisateur a une enchère sur cet article
        $sql_user_bid = "SELECT * FROM enchere WHERE article_id = ? AND acheteur_id = ?";
        $stmt = mysqli_prepare($this->db_handle, $sql_user_bid);
        mysqli_stmt_bind_param($stmt, "ii", $article_id, $acheteur_id);
        mysqli_stmt_execute($stmt);
        $result_user_bid = mysqli_stmt_get_result($stmt);
        $user_bid = mysqli_fetch_assoc($result_user_bid);
        
        if (!$user_bid) {
            return ['a_enchere' => false];
        }
        
        // Vérifier si c'est l'enchère gagnante
        $enchere_gagnante = $this->obtenirEnchereGagnante($article_id);
        $est_gagnant = $enchere_gagnante && $enchere_gagnante['acheteur_id'] == $acheteur_id;
        
        return [
            'a_enchere' => true,
            'prix_max' => $user_bid['prix_max'],
            'est_gagnant' => $est_gagnant,
            'date_offre' => $user_bid['date_offre']
        ];
    }
}
?>

<?php
session_start();
// Sécurité : accès réservé aux vendeurs et admins
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['vendeur', 'admin'])) {
    header('Location: compte.php');
    exit();
}

include_once "db.php";
if (!$db_handle) {
    die("Erreur de connexion à la base de données");
}

$db_found = mysqli_select_db($db_handle, "agora");
if (!$db_found) {
    die("Erreur de connexion à la base de données Agora");
}

$message = "";

// Traitement de la suppression d'article
if (isset($_POST['supprimer_article'])) {
    $id_article = intval($_POST['supprimer_article']);
    
    // Vérifier que l'article appartient au vendeur (sauf si admin)
    if ($_SESSION['user_role'] !== 'admin') {
        $check_sql = "SELECT vendeur_id FROM Article WHERE id = ?";
        $check_stmt = mysqli_prepare($db_handle, $check_sql);
        mysqli_stmt_bind_param($check_stmt, "i", $id_article);
        mysqli_stmt_execute($check_stmt);
        $result = mysqli_stmt_get_result($check_stmt);
        $article = mysqli_fetch_assoc($result);
        
        if (!$article || $article['vendeur_id'] != $_SESSION['user_id']) {
            header('Location: catalogue.php');
            exit();
        }
    }

    mysqli_autocommit($db_handle, false);
    try {
        // 1. Delete from ArticlePanier
        $sql = "DELETE FROM ArticlePanier WHERE article_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_article);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 2. Delete from Enchere
        $sql = "DELETE FROM Enchere WHERE article_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_article);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 3. Delete from Transaction
        $sql = "DELETE FROM Transaction WHERE article_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_article);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 4. Delete from Negociation
        $sql = "DELETE FROM Negociation WHERE article_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_article);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 5. Delete from Notification
        $sql = "DELETE FROM Notification WHERE article_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_article);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 6. Finally delete the Article
        $sql = "DELETE FROM Article WHERE id = ?";
        $stmt = mysqli_prepare($db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_article);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);        mysqli_commit($db_handle);
        $_SESSION['success_message'] = "Article supprimé avec succès !";
    } catch (Exception $e) {
        mysqli_rollback($db_handle);
        $_SESSION['error_message'] = "Erreur lors de la suppression : " . $e->getMessage();
    }
    mysqli_autocommit($db_handle, true);
    
    // Rediriger vers l'accueil
    header('Location: index.php');
    exit();
}
?>

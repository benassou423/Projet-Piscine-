<?php
session_start();
$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

$message_connexion = "";
$message_inscription = "";
$message_update = "";

// Traitement connexion
if (isset($_POST['action']) && $_POST['action'] == 'connexion' && $db_found) {
    $email = mysqli_real_escape_string($db_handle, trim($_POST['email']));
    $password = $_POST['password'];
    $sql = "SELECT id, nom, prenom, email, mot_de_passe, role FROM Utilisateur WHERE email = '$email'";
    $result = mysqli_query($db_handle, $sql);
    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['mot_de_passe'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nom'] = $user['nom'];
            $_SESSION['user_prenom'] = $user['prenom'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_email'] = $user['email'];
            header("Location: compte.php");
            exit();
        } else {
            $message_connexion = "Mot de passe incorrect.";
        }
    } else {
        $message_connexion = "Utilisateur non trouvé.";
    }
}

// Traitement inscription
if (isset($_POST['action']) && $_POST['action'] == 'inscription' && $db_found) {
    $nom      = mysqli_real_escape_string($db_handle, trim($_POST['nom']));
    $prenom   = mysqli_real_escape_string($db_handle, trim($_POST['prenom']));
    $email    = mysqli_real_escape_string($db_handle, trim($_POST['email']));
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $adresse1 = mysqli_real_escape_string($db_handle, trim($_POST['adresse1']));
    $adresse2 = mysqli_real_escape_string($db_handle, trim($_POST['adresse2']));
    $ville    = mysqli_real_escape_string($db_handle, trim($_POST['ville']));
    $cp       = mysqli_real_escape_string($db_handle, trim($_POST['code_postal']));
    $pays     = mysqli_real_escape_string($db_handle, trim($_POST['pays']));
    $tel      = mysqli_real_escape_string($db_handle, trim($_POST['telephone']));
    if ($password !== $password2) {
        $message_inscription = "Les mots de passe ne correspondent pas.";
    } else {
        $sql = "SELECT id FROM Utilisateur WHERE email = '$email'";
        $result = mysqli_query($db_handle, $sql);
        if (mysqli_num_rows($result) > 0) {
            $message_inscription = "Cet email est déjà utilisé.";
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $sql = "INSERT INTO Utilisateur 
                (nom, prenom, email, mot_de_passe, role, adresse_ligne1, adresse_ligne2, ville, code_postal, pays, telephone)
                VALUES 
                ('$nom', '$prenom', '$email', '$hash', 'acheteur', '$adresse1', '$adresse2', '$ville', '$cp', '$pays', '$tel')";
            if (mysqli_query($db_handle, $sql)) {
                $message_inscription = "Inscription réussie ! Vous pouvez vous connecter.";
            } else {
                $message_inscription = "Erreur lors de l'inscription : " . mysqli_error($db_handle);
            }
        }
    }
} elseif (!$db_found) {
    $message_connexion = "Base de données non trouvée.";
    $message_inscription = "Base de données non trouvée.";
}

// Traitement de la mise à jour du profil
if (isset($_POST['action']) && $_POST['action'] == 'update' && isset($_SESSION['user_id'])) {
    $id = intval($_SESSION['user_id']);
    $nom = mysqli_real_escape_string($db_handle, trim($_POST['nom']));
    $prenom = mysqli_real_escape_string($db_handle, trim($_POST['prenom']));
    $email = mysqli_real_escape_string($db_handle, trim($_POST['email']));
    $adresse1 = mysqli_real_escape_string($db_handle, trim($_POST['adresse1']));
    $adresse2 = mysqli_real_escape_string($db_handle, trim($_POST['adresse2']));
    $ville = mysqli_real_escape_string($db_handle, trim($_POST['ville']));
    $cp = mysqli_real_escape_string($db_handle, trim($_POST['code_postal']));
    $pays = mysqli_real_escape_string($db_handle, trim($_POST['pays']));
    $tel = mysqli_real_escape_string($db_handle, trim($_POST['telephone']));
    
    // Vérification si un nouveau mot de passe est fourni
    $password_update = "";
    if (!empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
        if ($_POST['new_password'] === $_POST['confirm_password']) {
            $hash = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
            $password_update = ", mot_de_passe = '$hash'";
        } else {
            $message_update = "Les mots de passe ne correspondent pas.";
        }
    }
    
    // Gestion de la photo
    $photo_update = "";
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $target_dir = "images/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        $allowed = array('jpg', 'jpeg', 'png', 'gif');
        
        if (in_array($extension, $allowed)) {
            $photo_name = uniqid('profile_') . '.' . $extension;
            $target_file = $target_dir . $photo_name;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                $photo_update = ", photo = '$target_file'";
                $_SESSION['user_photo'] = $target_file; // Mise à jour de la session avec la nouvelle photo
            }
        }
    }
    
    if (empty($message_update)) {
        $sql = "UPDATE Utilisateur SET 
                nom = ?, prenom = ?, email = ?,
                adresse_ligne1 = ?, adresse_ligne2 = ?, 
                ville = ?, code_postal = ?, pays = ?, 
                telephone = ? $password_update $photo_update
                WHERE id = ?";
                
        $stmt = mysqli_prepare($db_handle, $sql);
        mysqli_stmt_bind_param($stmt, "sssssssssi",
            $nom, $prenom, $email,
            $adresse1, $adresse2, $ville,
            $cp, $pays, $tel, $id
        );
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['user_nom'] = $nom;
            $_SESSION['user_prenom'] = $prenom;
            $_SESSION['user_email'] = $email;
            $message_update = "Profil mis à jour avec succès !";
        } else {
            $message_update = "Erreur lors de la mise à jour : " . mysqli_error($db_handle);
        }
    }
}

// Affichage compte connecté
if (isset($_SESSION['user_id'])) {
    // Récupération des informations complètes de l'utilisateur
    $id = intval($_SESSION['user_id']);
    $sql = "SELECT * FROM Utilisateur WHERE id = ?";
    $stmt = mysqli_prepare($db_handle, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    // Fonction helper pour gérer les valeurs NULL
    function display_value($value) {
        return htmlspecialchars($value ?? '');
    }
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>Mon compte - Agora Francia</title>
    <!-- Bootstrap d'abord -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Ensuite tes Google Fonts (optionnel pour luxe/épure) -->
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@700&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <!-- EN DERNIER ton CSS personnalisé -->
    <link rel="stylesheet" href="css/style-site.css">
</head>

<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Bienvenue <?= display_value($user['prenom']) ?> <?= display_value($user['nom']) ?></h2>
    <p class="text-center">Vous êtes connecté en tant que <strong><?= display_value($user['role']) ?></strong>.</p>
    
    <?php if (!empty($message_update)): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message_update) ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title mb-0">Vos informations personnelles</h3>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update">
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Prénom</label>
                        <input type="text" name="prenom" class="form-control" value="<?= display_value($user['prenom']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Nom</label>
                        <input type="text" name="nom" class="form-control" value="<?= display_value($user['nom']) ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= display_value($user['email']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Adresse (ligne 1)</label>
                    <input type="text" name="adresse1" class="form-control" value="<?= display_value($user['adresse_ligne1']) ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Adresse (ligne 2)</label>
                    <input type="text" name="adresse2" class="form-control" value="<?= display_value($user['adresse_ligne2']) ?>">
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Ville</label>
                        <input type="text" name="ville" class="form-control" value="<?= display_value($user['ville']) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Code postal</label>
                        <input type="text" name="code_postal" class="form-control" value="<?= display_value($user['code_postal']) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Pays</label>
                        <input type="text" name="pays" class="form-control" value="<?= display_value($user['pays']) ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Téléphone</label>
                    <input type="tel" name="telephone" class="form-control" value="<?= display_value($user['telephone']) ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Photo de profil</label>
                    <?php if (!empty($user['photo'])): ?>
                        <div class="mb-2">
                            <img src="<?= htmlspecialchars($user['photo']) ?>" alt="Photo de profil" style="width:100px;height:100px;object-fit:cover;" class="rounded">
                        </div>
                    <?php endif; ?>
                    <input type="file" name="photo" class="form-control" accept="image/*">
                </div>

                <div class="mb-3">
                    <label class="form-label">Nouveau mot de passe</label>
                    <input type="password" name="new_password" class="form-control">
                    <small class="text-muted">Laissez vide pour conserver le mot de passe actuel</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirmer le nouveau mot de passe</label>
                    <input type="password" name="confirm_password" class="form-control">
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Mettre à jour le profil</button>
                </div>
            </form>
        </div>
    </div>

    <div class="d-grid gap-2 mt-4">
        <a href="logout.php" class="btn btn-danger">Se déconnecter</a>
        <a href="index.php" class="btn btn-secondary">Retour à l'accueil</a>
    </div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>
<?php
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Votre Compte - Agora Francia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style-site.css">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Votre Compte Agora Francia</h2>
    <ul class="nav nav-tabs" id="tab-compte" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="connexion-tab" data-bs-toggle="tab" data-bs-target="#connexion" type="button" role="tab">Connexion</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="inscription-tab" data-bs-toggle="tab" data-bs-target="#inscription" type="button" role="tab">Inscription</button>
        </li>
    </ul>
    <div class="tab-content" id="tabContentCompte">
        <!-- Connexion -->
        <div class="tab-pane fade show active" id="connexion" role="tabpanel">
            <?php if ($message_connexion): ?>
                <div class="alert alert-danger"><?= $message_connexion ?></div>
            <?php endif; ?>
            <form method="post">
                <input type="hidden" name="action" value="connexion">
                <div class="mb-3"><input required name="email" type="email" class="form-control" placeholder="Email"></div>
                <div class="mb-3"><input required name="password" type="password" class="form-control" placeholder="Mot de passe"></div>
                <button type="submit" class="btn btn-primary w-100">Se connecter</button>
            </form>
        </div>
        <!-- Inscription -->
        <div class="tab-pane fade" id="inscription" role="tabpanel">
            <?php if ($message_inscription): ?>
                <div class="alert alert-info"><?= $message_inscription ?></div>
            <?php endif; ?>
            <form method="post">
                <input type="hidden" name="action" value="inscription">
                <div class="mb-2"><input required name="nom" type="text" class="form-control" placeholder="Nom"></div>
                <div class="mb-2"><input required name="prenom" type="text" class="form-control" placeholder="Prénom"></div>
                <div class="mb-2"><input required name="email" type="email" class="form-control" placeholder="Email"></div>
                <div class="mb-2"><input required name="password" type="password" class="form-control" placeholder="Mot de passe"></div>
                <div class="mb-2"><input required name="password2" type="password" class="form-control" placeholder="Confirmer mot de passe"></div>
                <div class="mb-2"><input name="adresse1" type="text" class="form-control" placeholder="Adresse (ligne 1)"></div>
                <div class="mb-2"><input name="adresse2" type="text" class="form-control" placeholder="Adresse (ligne 2)"></div>
                <div class="mb-2"><input name="ville" type="text" class="form-control" placeholder="Ville"></div>
                <div class="mb-2"><input name="code_postal" type="text" class="form-control" placeholder="Code postal"></div>
                <div class="mb-2"><input name="pays" type="text" class="form-control" placeholder="Pays"></div>
                <div class="mb-3"><input name="telephone" type="text" class="form-control" placeholder="Téléphone"></div>
                <button type="submit" class="btn btn-success w-100">S'inscrire</button>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap JS for tabs -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Afficher l'onglet inscription si erreur lors de l'inscription
<?php if (!empty($message_inscription)) : ?>
    var tab = new bootstrap.Tab(document.getElementById('inscription-tab'));
    tab.show();
<?php endif; ?>
</script>
<?php include 'footer.php'; ?>
</body>
</html>

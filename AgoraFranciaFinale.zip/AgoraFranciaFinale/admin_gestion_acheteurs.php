<?php
session_start();
// Sécurité : accès réservé à l'admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}

$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

$message_ajout = "";

// Traitement promotion acheteur en vendeur
if (isset($_POST['promouvoir_acheteur']) && !empty($_POST['promouvoir_acheteur'])) {
    $id_acheteur = intval($_POST['promouvoir_acheteur']);
    $sql_update = "UPDATE Utilisateur SET role = 'vendeur' WHERE id = ?";
    $stmt = mysqli_prepare($db_handle, $sql_update);
    mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
    if (mysqli_stmt_execute($stmt)) {
        $message_ajout = "L'acheteur a été promu en vendeur avec succès.";
        header('Location: admin_gestion_acheteurs.php');
        exit();
    } else {
        $message_ajout = "Erreur lors de la promotion : " . mysqli_error($db_handle);
    }
}

// Traitement suppression acheteur
if (isset($_POST['supprimer_acheteur']) && !empty($_POST['supprimer_acheteur'])) {
    $id_acheteur = intval($_POST['supprimer_acheteur']);
    mysqli_begin_transaction($db_handle);
    try {
        // 1. Suppression du panier
        $sql_delete_panier = "DELETE FROM Panier WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_panier);
        mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 2. Suppression des enchères
        $sql_delete_encheres = "DELETE FROM Enchere WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_encheres);
        mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 3. Suppression des transactions
        $sql_delete_transactions = "DELETE FROM Transaction WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_transactions);
        mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 4. Suppression des alertes
        $sql_delete_alertes = "DELETE FROM Alerte WHERE user_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_alertes);
        mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 5. Suppression des notifications
        $sql_delete_notifs = "DELETE FROM Notification WHERE user_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_notifs);
        mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 6. Suppression des négociations
        $sql_delete_nego = "DELETE FROM Negociation WHERE acheteur_id = ?";
        $stmt = mysqli_prepare($db_handle, $sql_delete_nego);
        mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // 7. Suppression de l'utilisateur
        $sql_delete_user = "DELETE FROM Utilisateur WHERE id = ? AND role = 'acheteur'";
        $stmt = mysqli_prepare($db_handle, $sql_delete_user);
        mysqli_stmt_bind_param($stmt, "i", $id_acheteur);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        mysqli_commit($db_handle);
        $message_ajout = "L'acheteur et toutes ses données associées ont été supprimés avec succès.";
        header('Location: admin_gestion_acheteurs.php');
        exit();
    } catch (Exception $e) {
        mysqli_rollback($db_handle);
        $message_ajout = "Erreur lors de la suppression de l'acheteur : " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des acheteurs - Admin | Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style-site.css">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Gestion des acheteurs</h2>
    <?php if ($message_ajout): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message_ajout) ?></div>
    <?php endif; ?>

    <!-- Liste des acheteurs -->
    <div class="card">
        <div class="card-header">Liste des acheteurs</div>
        <div class="card-body">
            <?php
            $sql = "SELECT * FROM Utilisateur WHERE role='acheteur' ORDER BY nom, prenom";
            $result = mysqli_query($db_handle, $sql);
            if ($result && mysqli_num_rows($result) > 0):
            ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($acheteur = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <?php if (isset($acheteur['photo']) && $acheteur['photo']): ?>
                                    <img src="<?= htmlspecialchars($acheteur['photo']) ?>" alt="photo" style="width:50px;height:50px;object-fit:cover;">
                                <?php else: ?>
                                    <div class="bg-secondary" style="width:50px;height:50px;"></div>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($acheteur['nom']) ?></td>
                            <td><?= htmlspecialchars($acheteur['prenom']) ?></td>
                            <td><?= htmlspecialchars($acheteur['email']) ?></td>
                            <td>
                                <form method="post" class="d-inline me-1" onsubmit="return confirm('Voulez-vous promouvoir cet acheteur en vendeur ?');">
                                    <input type="hidden" name="promouvoir_acheteur" value="<?= (int)$acheteur['id'] ?>">
                                    <button type="submit" class="btn btn-success btn-sm">Promouvoir en vendeur</button>
                                </form>
                                <form method="post" class="d-inline" onsubmit="return confirm('ATTENTION : Êtes-vous sûr de vouloir supprimer définitivement cet acheteur ? Cette action supprimera toutes ses transactions et données associées.');">
                                    <input type="hidden" name="supprimer_acheteur" value="<?= (int)$acheteur['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <p class="text-muted text-center">Aucun acheteur enregistré.</p>
            <?php endif; ?>
        </div>
    </div>
    <a href="admin.php" class="btn btn-secondary mt-3">Retour à l'espace admin</a>
</div>
<?php include 'footer.php'; ?>
</body>
</html>

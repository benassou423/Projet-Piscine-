<?php
require_once __DIR__ . '/../config/base_donnees.php';

function initialiserBaseDeDonnees() {
    global $bdd;
    
    try {
        // Lecture et exécution du fichier schema.sql
        $sql = file_get_contents(__DIR__ . '/schema.sql');
        
        // Diviser le SQL en instructions individuelles
        $instructions = array_filter(array_map('trim', explode(';', $sql)));
        
        // Exécuter chaque instruction
        foreach ($instructions as $instruction) {
            if (!empty($instruction)) {
                try {
                    $bdd->exec($instruction);
                } catch (PDOException $e) {
                    // Ignorer les erreurs si la table existe déjà
                    if (!strpos($e->getMessage(), '1050 Table')) {
                        throw $e;
                    }
                }
            }
        }
        
        // Création de l'utilisateur admin
        $email = 'admin@agorafrancia.fr';
        $motDePasse = password_hash('admin123', PASSWORD_DEFAULT);
        $nom = 'System';
        $prenom = 'Admin';
        
        // Insertion de l'adresse de l'administrateur
        $stmt = $bdd->prepare("INSERT INTO adresses (ligne1, ville, code_postal, pays, telephone) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['37 Quai de Grenelle', 'Paris', '75015', 'France', '0123456789']);
        
        // Récupérer l'ID de l'adresse nouvellement créée
        $idAdresse = $bdd->lastInsertId();
        
        // Insertion de l'administrateur
        $stmt = $bdd->prepare("INSERT INTO utilisateurs (email, mot_de_passe, nom, prenom, type_utilisateur, id_adresse) VALUES (?, ?, ?, ?, 'administrateur', ?)");
        $stmt->execute([$email, $motDePasse, $nom, $prenom, $idAdresse]);
        
        // Création des catégories de base
        $categories = [
            ['Meubles et objets d\'art', 'Meubles anciens, tableaux, sculptures et autres objets d\'art', 'rare'],
            ['Accessoires VIP', 'Montres, bijoux, sacs et autres accessoires de luxe', 'haut_de_gamme'],
            ['Matériels scolaires', 'Livres, fournitures et équipements pour les études', 'regulier']
        ];
        
        $stmt = $bdd->prepare("INSERT INTO categories (nom, description, type) VALUES (?, ?, ?)");
        foreach ($categories as $categorie) {
            $stmt->execute([$categorie[0], $categorie[1], $categorie[2]]);
        }
        
        echo "Base de données initialisée avec succès !\n";
        echo "Utilisateur admin créé avec email: admin@agorafrancia.fr et mot de passe: admin123\n";
        return true;
        
    } catch(PDOException $e) {
        die("Erreur lors de l'initialisation de la base de données : " . $e->getMessage());
        return false;
    }
}

// Exécuter l'initialisation si le script est lancé directement
if (php_sapi_name() === 'cli' || isset($_GET['init'])) {
    initialiserBaseDeDonnees();
}
?>

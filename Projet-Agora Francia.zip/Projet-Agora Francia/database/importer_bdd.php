<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Paramètres de connexion MySQL
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'agoriafrancia';

try {
    // Créer la connexion
    $conn = new mysqli($host, $user, $pass);

    // Vérifier la connexion
    if ($conn->connect_error) {
        throw new Exception("Erreur de connexion : " . $conn->connect_error);
    }

    // Créer la base de données si elle n'existe pas
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if (!$conn->query($sql)) {
        throw new Exception("Erreur lors de la création de la base de données : " . $conn->error);
    }

    // Sélectionner la base de données
    $conn->select_db($dbname);

    // Lire le fichier SQL
    $sql = file_get_contents(__DIR__ . '/agoriafrancia.sql');

    // Exécuter les requêtes SQL
    if ($conn->multi_query($sql)) {
        do {
            // Stocker le premier résultat
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->next_result()); // Passer au résultat suivant
    }

    echo "Base de données importée avec succès!";

} catch (Exception $e) {
    die("Erreur : " . $e->getMessage());
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>

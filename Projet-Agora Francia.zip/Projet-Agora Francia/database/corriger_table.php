<?php
require_once __DIR__ . '/../config/base_donnees.php';

try {
    // Lecture du fichier SQL
    $sql = file_get_contents(__DIR__ . '/correction_table.sql');
    
    // Exécution des requêtes
    $bdd->exec($sql);
    
    echo "La structure de la table adresses a été corrigée avec succès !";
    echo "<br><a href='/pages/inscription.php'>Retourner à la page d'inscription</a>";
    
} catch(PDOException $e) {
    die("Erreur lors de la correction de la table : " . $e->getMessage());
}
?>

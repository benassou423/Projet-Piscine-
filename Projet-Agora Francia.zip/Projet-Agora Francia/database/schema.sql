-- Création de la base de données
CREATE DATABASE IF NOT EXISTS agora_francia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE agora_francia;

-- Table des adresses
CREATE TABLE adresses (
    id_adresse INT AUTO_INCREMENT PRIMARY KEY,
    ligne1 VARCHAR(255) NOT NULL,
    ligne2 VARCHAR(255),
    ville VARCHAR(100) NOT NULL,
    code_postal VARCHAR(10) NOT NULL,
    pays VARCHAR(100) NOT NULL,
    telephone VARCHAR(20) NOT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des utilisateurs
CREATE TABLE utilisateurs (
    id_utilisateur INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(191) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    type_utilisateur ENUM('administrateur', 'vendeur', 'acheteur') NOT NULL,
    photo_profil VARCHAR(255),
    image_fond VARCHAR(255),
    id_adresse INT,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_adresse) REFERENCES adresses(id_adresse)
);

-- Table des catégories
CREATE TABLE categories (
    id_categorie INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    type ENUM('rare', 'haut_de_gamme', 'regulier') NOT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des produits
CREATE TABLE produits (
    id_produit INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    prix_initial DECIMAL(10,2) NOT NULL,
    type_vente ENUM('immediate', 'negociation', 'enchere') NOT NULL,
    etat VARCHAR(50) NOT NULL,
    photos JSON NOT NULL, -- Stocke un tableau de chemins de photos
    video VARCHAR(255),
    id_categorie INT NOT NULL,
    id_vendeur INT NOT NULL,
    statut ENUM('disponible', 'vendu', 'expire') DEFAULT 'disponible',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_fin TIMESTAMP,
    FOREIGN KEY (id_categorie) REFERENCES categories(id_categorie),
    FOREIGN KEY (id_vendeur) REFERENCES utilisateurs(id_utilisateur)
);

-- Table des enchères
CREATE TABLE encheres (
    id_enchere INT AUTO_INCREMENT PRIMARY KEY,
    id_produit INT NOT NULL,
    id_acheteur INT NOT NULL,
    montant DECIMAL(10,2) NOT NULL,
    montant_max DECIMAL(10,2) NOT NULL,
    date_enchere TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut ENUM('en_cours', 'gagnante', 'perdue') DEFAULT 'en_cours',
    FOREIGN KEY (id_produit) REFERENCES produits(id_produit),
    FOREIGN KEY (id_acheteur) REFERENCES utilisateurs(id_utilisateur)
);

-- Table des négociations
CREATE TABLE negociations (
    id_negociation INT AUTO_INCREMENT PRIMARY KEY,
    id_produit INT NOT NULL,
    id_acheteur INT NOT NULL,
    prix_propose DECIMAL(10,2) NOT NULL,
    prix_contre_offre DECIMAL(10,2),
    nombre_echanges INT DEFAULT 1,
    statut ENUM('en_cours', 'acceptee', 'refusee') DEFAULT 'en_cours',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_mise_a_jour TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_produit) REFERENCES produits(id_produit),
    FOREIGN KEY (id_acheteur) REFERENCES utilisateurs(id_utilisateur)
);

-- Table des commandes
CREATE TABLE commandes (
    id_commande INT AUTO_INCREMENT PRIMARY KEY,
    id_acheteur INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    statut ENUM('en_attente', 'payee', 'expediee', 'livree') DEFAULT 'en_attente',
    id_adresse_livraison INT NOT NULL,
    date_commande TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_acheteur) REFERENCES utilisateurs(id_utilisateur),
    FOREIGN KEY (id_adresse_livraison) REFERENCES adresses(id_adresse)
);

-- Table des lignes de commande
CREATE TABLE lignes_commande (
    id_ligne INT AUTO_INCREMENT PRIMARY KEY,
    id_commande INT NOT NULL,
    id_produit INT NOT NULL,
    quantite INT NOT NULL DEFAULT 1,
    prix_unitaire DECIMAL(10,2) NOT NULL,
    type_achat ENUM('immediate', 'negociation', 'enchere') NOT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_commande) REFERENCES commandes(id_commande),
    FOREIGN KEY (id_produit) REFERENCES produits(id_produit)
);

-- Table des paiements
CREATE TABLE paiements (
    id_paiement INT AUTO_INCREMENT PRIMARY KEY,
    id_commande INT NOT NULL,
    montant DECIMAL(10,2) NOT NULL,
    type_paiement ENUM('carte', 'cheque_cadeau') NOT NULL,
    numero_carte VARCHAR(255),
    nom_carte VARCHAR(100),
    date_expiration DATE,
    code_securite VARCHAR(255),
    statut ENUM('en_attente', 'valide', 'refuse') DEFAULT 'en_attente',
    date_paiement TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_commande) REFERENCES commandes(id_commande)
);

-- Table des notifications
CREATE TABLE notifications (
    id_notification INT AUTO_INCREMENT PRIMARY KEY,
    id_utilisateur INT NOT NULL,
    titre VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    est_lu BOOLEAN DEFAULT FALSE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id_utilisateur)
);

-- Création des index pour optimiser les performances
CREATE INDEX idx_produits_vendeur ON produits(id_vendeur);
CREATE INDEX idx_produits_categorie ON produits(id_categorie);
CREATE INDEX idx_encheres_produit ON encheres(id_produit);
CREATE INDEX idx_negociations_produit ON negociations(id_produit);
CREATE INDEX idx_negociations_acheteur ON negociations(id_acheteur);
CREATE INDEX idx_commandes_acheteur ON commandes(id_acheteur);
CREATE INDEX idx_notifications_utilisateur ON notifications(id_utilisateur);

-- Insertion des données initiales pour les catégories
INSERT INTO categories (nom, description, type) VALUES 
('Meubles et objets d''art', 'Meubles anciens, sculptures, tableaux et autres objets d''art', 'rare'),
('Accessoire VIP', 'Accessoires de luxe et articles de collection', 'haut_de_gamme'),
('Matériels scolaires', 'Fournitures et équipements pour les études', 'regulier');

-- Insertion d'un administrateur par défaut
INSERT INTO adresses (ligne1, ville, code_postal, pays, telephone) VALUES 
('37 Quai de Grenelle', 'Paris', '75015', 'France', '0123456789');

INSERT INTO utilisateurs (email, mot_de_passe, nom, prenom, type_utilisateur, id_adresse) VALUES 
('admin@agorafrancia.fr', SHA2('admin123', 256), 'Admin', 'System', 'administrateur', 1);

-- Sauvegarde des données existantes
CREATE TABLE IF NOT EXISTS adresses_temp AS SELECT * FROM adresses;

-- Suppression de l'ancienne table
DROP TABLE IF EXISTS adresses;

-- Recréation de la table avec la bonne structure
CREATE TABLE adresses (
    ID_adresse INT NOT NULL AUTO_INCREMENT,
    ligne1 VARCHAR(255) NOT NULL,
    ligne2 VARCHAR(255) DEFAULT NULL,
    ville VARCHAR(100) NOT NULL,
    code_postal VARCHAR(10) NOT NULL,
    pays VARCHAR(100) NOT NULL,
    telephone VARCHAR(20) NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (ID_adresse)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Restauration des données
INSERT INTO adresses (ID_adresse, ligne1, ligne2, ville, code_postal, pays, telephone, date_creation)
SELECT ID_adresse, ligne1, ligne2, ville, `code postal`, pays, telephone, date_creation
FROM adresses_temp;

-- Suppression de la table temporaire
DROP TABLE IF EXISTS adresses_temp;

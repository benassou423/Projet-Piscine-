<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Configuration de la base de données
define('DB_HOST', 'localhost');     // Hôte de la base de données
define('DB_NAME', 'agoriafrancia'); // Nom de la base de données
define('DB_USER', 'root');          // Nom d'utilisateur MySQL (par défaut 'root' sur WAMP)
define('DB_PASS', '');              // Mot de passe MySQL (vide par défaut sur WAMP)

try {
    // Création d'une nouvelle connexion PDO
    $bdd = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        )
    );
} catch(PDOException $e) {
    // En cas d'erreur, afficher un message et arrêter le script
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>

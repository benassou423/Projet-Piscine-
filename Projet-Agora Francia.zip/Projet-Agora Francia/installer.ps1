# Installation rapide d'Agora Francia
Write-Host "Installation d'Agora Francia..." -ForegroundColor Green

# 1. Vérifier WAMP
if (-not (Test-Path "C:\wamp64\bin\apache\apache2.4.54.2\bin\httpd.exe")) {
    Write-Host "WAMP n'est pas installé ou n'est pas trouvé dans le chemin par défaut." -ForegroundColor Red
    Write-Host "Veuillez installer WAMP et réessayer." -ForegroundColor Red
    exit 1
}

# 2. Configurer le virtual host
Write-Host "Configuration du virtual host..." -ForegroundColor Cyan
try {
    & "$PSScriptRoot\setup-vhost.ps1"
} catch {
    Write-Host "Erreur lors de la configuration du virtual host : $_" -ForegroundColor Red
    exit 1
}

# 3. Redémarrer Apache via le wampmanager
Write-Host "Redémarrage d'Apache..." -ForegroundColor Cyan
$wampManager = "C:\wamp64\wampmanager.exe"
if (Test-Path $wampManager) {
    Start-Process $wampManager -ArgumentList "--restart-apache"
} else {
    Write-Host "WampManager non trouvé. Veuillez redémarrer Apache manuellement." -ForegroundColor Yellow
}

# 4. Initialiser la base de données
Write-Host "Initialisation de la base de données..." -ForegroundColor Cyan
$php = "C:\wamp64\bin\php\php8.2.0\php.exe"
if (Test-Path $php) {
    & $php "$PSScriptRoot\database\initialisation.php"
} else {
    Write-Host "PHP non trouvé. Veuillez initialiser la base de données manuellement." -ForegroundColor Yellow
}

Write-Host "`nInstallation terminée !" -ForegroundColor Green
Write-Host "Accédez à votre site via : http://agora-francia.local" -ForegroundColor Green
Write-Host "Compte administrateur :" -ForegroundColor Green
Write-Host "Email : admin@agorafrancia.fr" -ForegroundColor Green
Write-Host "Mot de passe : admin123" -ForegroundColor Green

<?php
// Inclure les fichiers nécessaires
require_once 'config/base_donnees.php';
require_once 'includes/authentification.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agora Francia - Votre Marché en Ligne</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
</head>
<body>
    <?php include 'includes/entete.php'; ?>

    <main class="container mt-4">
        <!-- Carrousel -->
        <div id="mainCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
            <div class="carousel-inner">
                <!-- Will be populated dynamically -->
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Précédent</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Suivant</span>
            </button>
        </div>

        <!-- Sélection du jour -->
        <section class="daily-selection mb-5">
            <h2 class="section-title">Sélection du Jour</h2>
            <div class="row" id="dailySelection">
                <!-- Will be populated dynamically -->
            </div>
        </section>

        <!-- Catégories -->
        <section class="categories mb-5">
            <h2 class="section-title">Nos Catégories</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="category-card">
                        <h3>Articles Rares</h3>
                        <a href="pages/category.php?type=rare" class="btn btn-primary">Découvrir</a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="category-card">
                        <h3>Articles Haut de Gamme</h3>
                        <a href="pages/category.php?type=luxe" class="btn btn-primary">Découvrir</a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="category-card">
                        <h3>Articles Réguliers</h3>
                        <a href="pages/category.php?type=regular" class="btn btn-primary">Découvrir</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact -->
        <section class="contact-info mb-5">
            <h2 class="section-title">Nous Contacter</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="contact-details">
                        <p><strong>Email:</strong> contact@agorafrancia.fr</p>
                        <p><strong>Téléphone:</strong> +33 1 XX XX XX XX</p>
                        <p><strong>Adresse:</strong> XX Rue XXXXX, Paris, France</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div id="map">
                        <!-- Google Maps will be integrated here -->
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include 'includes/pied.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="js/main.js"></script>
</body>
</html>

# Ce script doit être exécuté en tant qu'administrateur
$siteName = "agora-francia.local"
$siteRoot = $PWD.Path

# Ajouter l'entrée dans le fichier hosts
Add-Content -Path "C:\Windows\System32\drivers\etc\hosts" -Value "`n127.0.0.1 $siteName"

# Créer la configuration du virtual host
$vhostConfig = @"
<VirtualHost *:80>
    ServerName $siteName
    DocumentRoot "$siteRoot"
    <Directory "$siteRoot">
        Options Indexes FollowSymLinks MultiViews
        AllowOverride All
        Require all granted
    </Directory>
    ErrorLog "logs/$siteName-error.log"
    CustomLog "logs/$siteName-access.log" common
</VirtualHost>
"@

# Chemin vers le fichier de configuration Apache (ajustez selon votre installation WAMP)
$apacheConfigPath = "C:\wamp64\bin\apache\apache2.4.54.2\conf\extra\httpd-vhosts.conf"

# Ajouter la configuration au fichier vhosts
Add-Content -Path $apacheConfigPath -Value $vhostConfig

Write-Host "Virtual host configuré. N'oubliez pas de :"
Write-Host "1. Redémarrer Apache dans WAMP"
Write-Host "2. Créer la base de données en important le fichier schema.sql"
Write-Host "3. Accéder au site via http://$siteName"

<?php
require_once('../includes/auth.php');
require_once('../includes/encheres.php');

// Vérifier si l'ID de l'enchère est fourni
if (!isset($_GET['id'])) {
    header('Location: /pages/encheres.php');
    exit;
}

$enchereId = (int)$_GET['id'];
$enchere = $gestionnaireEncheres->obtenirDetailEnchere($enchereId);

if (!$enchere) {
    header('Location: /pages/encheres.php');
    exit;
}

// Traiter la soumission d'une enchère
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $auth->estConnecte()) {
    $montant = (float)$_POST['montant'];
    $resultat = $gestionnaireEncheres->placerEnchere($enchereId, $_SESSION['utilisateur_id'], $montant);
    if ($resultat['succes']) {
        header("Location: /pages/enchere.php?id={$enchereId}&status=success");
        exit;
    }
}

// Obtenir l'historique des offres
$historiqueOffres = $gestionnaireEncheres->obtenirHistoriqueOffres($enchereId);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($enchere['nom']); ?> - Enchères - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container mt-4">
        <?php if (isset($_GET['status']) && $_GET['status'] === 'success'): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Votre enchère a été placée avec succès !
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <?php if ($enchere['chemin_image']): ?>
                        <img src="<?php echo htmlspecialchars($enchere['chemin_image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($enchere['nom']); ?>">
                    <?php endif; ?>
                    <div class="card-body">
                        <h1 class="card-title"><?php echo htmlspecialchars($enchere['nom']); ?></h1>
                        <p class="card-text"><?php echo nl2br(htmlspecialchars($enchere['description'])); ?></p>
                        
                        <div class="auction-details mt-4">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>Prix actuel</h5>
                                    <p class="display-4"><?php echo number_format($enchere['prix_actuel'], 2); ?> €</p>
                                    <p class="text-muted">Prix de départ : <?php echo number_format($enchere['prix_depart'], 2); ?> €</p>
                                </div>
                                <div class="col-md-6">
                                    <h5>Temps restant</h5>
                                    <div class="time-left" data-end="<?php echo $enchere['date_fin']; ?>">
                                        <span class="countdown display-4"></span>
                                    </div>
                                    <p class="text-muted">
                                        Fin : <?php echo date('d/m/Y H:i', strtotime($enchere['date_fin'])); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <?php if ($auth->estConnecte()): ?>
                            <div class="bid-form mt-4">
                                <h5>Placer une enchère</h5>
                                <form method="POST" id="bidForm">
                                    <div class="input-group mb-3">
                                        <input type="number" class="form-control" name="montant" id="montant" 
                                               step="0.01" min="<?php echo $enchere['prix_actuel'] + 0.01; ?>"
                                               placeholder="Votre offre (min. <?php echo number_format($enchere['prix_actuel'] + 0.01, 2); ?> €)">
                                        <button class="btn btn-primary" type="submit">Enchérir</button>
                                    </div>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info mt-4">
                                <a href="/pages/login.php">Connectez-vous</a> pour participer à cette enchère.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Historique des enchères</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($historiqueOffres)): ?>
                            <p class="text-muted">Aucune enchère n'a encore été placée.</p>
                        <?php else: ?>
                            <div class="bids-history">
                                <?php foreach ($historiqueOffres as $offre): ?>
                                    <div class="bid-item mb-2">
                                        <div class="bid-amount">
                                            <strong><?php echo number_format($offre['montant'], 2); ?> €</strong>
                                        </div>
                                        <div class="bid-info">
                                            par <?php echo htmlspecialchars($offre['prenom'] . ' ' . substr($offre['nom'], 0, 1) . '.'); ?>
                                            <br>
                                            <small class="text-muted">
                                                <?php echo date('d/m/Y H:i', strtotime($offre['date_creation'])); ?>
                                            </small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Mettre à jour le compteur
        function updateCountdown() {
            const endTime = new Date($('.time-left').data('end')).getTime();
            const now = new Date().getTime();
            const distance = endTime - now;
            
            if (distance < 0) {
                $('.time-left').html('Enchère terminée');
                $('#bidForm').remove();
                return;
            }
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            $('.countdown').html(`${days}j ${hours}h ${minutes}m ${seconds}s`);
        }
        
        // Mettre à jour toutes les secondes
        updateCountdown();
        setInterval(updateCountdown, 1000);
        
        // Validation du formulaire d'enchère
        $('#bidForm').on('submit', function(e) {
            const montant = parseFloat($('#montant').val());
            const minMontant = parseFloat($('#montant').attr('min'));
            
            if (montant < minMontant) {
                e.preventDefault();
                alert('Le montant doit être supérieur à l\'enchère actuelle');
            }
        });
    });
    </script>
</body>
</html>

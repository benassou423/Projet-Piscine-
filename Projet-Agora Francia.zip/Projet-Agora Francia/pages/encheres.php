<?php
require_once('../includes/auth.php');
require_once('../includes/encheres.php');

// Obtenir la liste des enchères actives
$encheresActives = $gestionnaireEncheres->obtenirEncheresActives(20);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enchères en cours - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container mt-4">
        <h1 class="mb-4">Enchères en cours</h1>
        
        <div class="row">
            <?php foreach ($encheresActives as $enchere): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?php if ($enchere['chemin_image']): ?>
                            <img src="<?php echo htmlspecialchars($enchere['chemin_image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($enchere['nom']); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($enchere['nom']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars(substr($enchere['description'], 0, 100)) . '...'; ?></p>
                            
                            <div class="price-info mb-3">
                                <div class="current-price">
                                    Prix actuel : <strong><?php echo number_format($enchere['prix_actuel'], 2); ?> €</strong>
                                </div>
                                <div class="starting-price text-muted">
                                    Prix de départ : <?php echo number_format($enchere['prix_depart'], 2); ?> €
                                </div>
                            </div>
                            
                            <div class="auction-info mb-3">
                                <div class="time-left" data-end="<?php echo $enchere['date_fin']; ?>">
                                    Temps restant : <span class="countdown"></span>
                                </div>
                                <div class="bids-count">
                                    <?php echo $enchere['nombre_offres']; ?> enchère(s)
                                </div>
                            </div>
                            
                            <a href="/pages/enchere.php?id=<?php echo $enchere['id']; ?>" class="btn btn-primary w-100">
                                Voir l'enchère
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <?php if (empty($encheresActives)): ?>
                <div class="col-12">
                    <div class="alert alert-info">
                        Aucune enchère n'est actuellement active.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Mettre à jour les compteurs
        function updateCountdowns() {
            $('.time-left').each(function() {
                const endTime = new Date($(this).data('end')).getTime();
                const now = new Date().getTime();
                const distance = endTime - now;
                
                if (distance < 0) {
                    $(this).html('Enchère terminée');
                    return;
                }
                
                const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);
                
                $(this).find('.countdown').html(
                    `${days}j ${hours}h ${minutes}m ${seconds}s`
                );
            });
        }
        
        // Mettre à jour toutes les secondes
        updateCountdowns();
        setInterval(updateCountdowns, 1000);
    });
    </script>
</body>
</html>

<?php
require_once(__DIR__ . '/../config/base_donnees.php');
require_once(__DIR__ . '/../includes/authentification.php');
require_once(__DIR__ . '/../includes/panier.php');

// Obtenir le contenu du panier
$contenuPanier = $panier->obtenirContenu();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panier - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/entete.php'; ?>

    <main class="container mt-4">
        <h1 class="mb-4">Votre Panier</h1>
        
        <?php if (empty($contenuPanier['articles'])): ?>
            <div class="alert alert-info">
                <i class="bi bi-cart-x"></i> Votre panier est vide. <a href="/pages/produits.php">Continuez vos achats</a>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="cart-items">
                        <?php foreach ($contenuPanier['articles'] as $article): ?>
                            <div class="card mb-3" id="cart-item-<?php echo $article['id_produit']; ?>">
                                <div class="row g-0">
                                    <div class="col-md-3">
                                        <?php if ($article['image_principale']): ?>
                                            <img src="<?php echo htmlspecialchars($article['image_principale']); ?>" 
                                                 class="img-fluid rounded-start" 
                                                 alt="<?php echo htmlspecialchars($article['nom']); ?>">
                                        <?php else: ?>
                                            <div class="no-image">
                                                <i class="bi bi-image text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <h5 class="card-title">
                                                    <?php echo htmlspecialchars($article['nom']); ?>
                                                </h5>
                                                <button type="button" class="btn-close remove-item" 
                                                        data-product-id="<?php echo $article['id_produit']; ?>">
                                                </button>
                                            </div>
                                            <p class="card-text">
                                                <?php echo htmlspecialchars(substr($article['description'], 0, 100)) . '...'; ?>
                                            </p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="input-group" style="max-width: 150px;">
                                                    <button class="btn btn-outline-secondary update-quantity" 
                                                            type="button" data-action="decrease" 
                                                            data-product-id="<?php echo $article['id_produit']; ?>">-</button>
                                                    <input type="number" class="form-control text-center quantity-input" 
                                                           value="<?php echo $article['quantite']; ?>" 
                                                           min="1" max="99" 
                                                           data-product-id="<?php echo $article['id_produit']; ?>">
                                                    <button class="btn btn-outline-secondary update-quantity" 
                                                            type="button" data-action="increase" 
                                                            data-product-id="<?php echo $article['id_produit']; ?>">+</button>
                                                </div>
                                                <div class="price">
                                                    <span class="item-price">
                                                        <?php echo number_format($article['prix'], 2, ',', ' '); ?> €
                                                    </span>
                                                    <span class="item-total">
                                                        (<?php echo number_format($article['sous_total'], 2, ',', ' '); ?> €)
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Résumé de la commande</h5>
                            <div class="d-flex justify-content-between mb-3">
                                <span>Sous-total</span>
                                <span><?php echo number_format($contenuPanier['total'], 2, ',', ' '); ?> €</span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-3">
                                <span class="fw-bold">Total</span>
                                <span class="fw-bold"><?php echo number_format($contenuPanier['total'], 2, ',', ' '); ?> €</span>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="/pages/paiement.php" class="btn btn-primary">
                                    Procéder au paiement
                                </a>
                                <button type="button" class="btn btn-outline-danger" id="empty-cart">
                                    Vider le panier
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php include '../includes/pied.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="../js/panier.js"></script>
</body>
</html>

<?php
require_once('../includes/auth.php');
require_once('../includes/cart.php');

// Vérifier si l'utilisateur est connecté
if (!$auth->estConnecte()) {
    header('Location: /pages/login.php');
    exit;
}

// Vider le panier après la confirmation
$panier->vider();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation de commande - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body text-center">
                        <i class="bi bi-check-circle text-success" style="font-size: 4rem;"></i>
                        <h1 class="mt-3">Commande confirmée !</h1>
                        <p class="lead">Merci pour votre achat sur Agora Francia.</p>
                        <p>Un email de confirmation a été envoyé à votre adresse.</p>
                        <hr>
                        <p>Numéro de commande : #<?php echo date('YmdHis'); ?></p>
                        <div class="mt-4">
                            <a href="/" class="btn btn-primary me-2">Retour à l'accueil</a>
                            <a href="/pages/orders.php" class="btn btn-outline-primary">Voir mes commandes</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

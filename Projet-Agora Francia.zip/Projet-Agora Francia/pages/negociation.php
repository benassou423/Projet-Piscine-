<?php
require_once('../includes/auth.php');
require_once('../includes/negociations.php');

// Vérifier si l'utilisateur est connecté
if (!$auth->estConnecte()) {
    header('Location: /pages/login.php');
    exit;
}

// Vérifier si l'ID de la négociation est fourni
if (!isset($_GET['id'])) {
    header('Location: /pages/negociations.php');
    exit;
}

$negociationId = (int)$_GET['id'];
$negociation = $gestionnaireNegociations->obtenirDetailNegociation($negociationId);

if (!$negociation) {
    header('Location: /pages/negociations.php');
    exit;
}

// Vérifier si l'utilisateur est autorisé à voir cette négociation
$estVendeur = $auth->estVendeur() && $negociation['vendeur_id'] === $_SESSION['utilisateur_id'];
$estAcheteur = $negociation['acheteur_id'] === $_SESSION['utilisateur_id'];

if (!$estVendeur && !$estAcheteur) {
    header('Location: /pages/negociations.php');
    exit;
}

// Traiter une nouvelle offre
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['montant'])) {
    $resultat = $gestionnaireNegociations->faireOffre(
        $negociationId,
        (float)$_POST['montant'],
        $estVendeur
    );
    
    if ($resultat['succes']) {
        header("Location: /pages/negociation.php?id={$negociationId}&status=success");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Négociation - <?php echo htmlspecialchars($negociation['nom_produit']); ?> - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container mt-4">
        <?php if (isset($_GET['status']) && $_GET['status'] === 'success'): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Votre offre a été envoyée avec succès !
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h1 class="h3 mb-0"><?php echo htmlspecialchars($negociation['nom_produit']); ?></h1>
                    </div>
                    
                    <?php if ($negociation['chemin_image']): ?>
                        <img src="<?php echo htmlspecialchars($negociation['chemin_image']); ?>" 
                             class="card-img-top" 
                             alt="<?php echo htmlspecialchars($negociation['nom_produit']); ?>">
                    <?php endif; ?>
                    
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h5>Prix initial</h5>
                                <p class="h3"><?php echo number_format($negociation['prix_initial'], 2); ?> €</p>
                            </div>
                            <div class="col-md-6">
                                <h5>Prix actuel</h5>
                                <p class="h3"><?php echo number_format($negociation['prix_actuel'], 2); ?> €</p>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h5>Description</h5>
                            <p><?php echo nl2br(htmlspecialchars($negociation['description'])); ?></p>
                        </div>
                        
                        <?php if ($negociation['tentatives_restantes'] > 0): ?>
                            <div class="negotiation-form mb-4">
                                <h5>Faire une offre</h5>
                                <form method="POST" id="offerForm" class="needs-validation" novalidate>
                                    <div class="input-group">
                                        <input type="number" class="form-control" name="montant" id="montant" 
                                               step="0.01" 
                                               <?php if ($estVendeur): ?>
                                                   max="<?php echo $negociation['prix_actuel']; ?>"
                                                   placeholder="Proposer un prix inférieur"
                                               <?php else: ?>
                                                   min="<?php echo $negociation['prix_actuel']; ?>"
                                                   placeholder="Proposer un prix supérieur"
                                               <?php endif; ?>
                                               required>
                                        <button type="submit" class="btn btn-primary">Envoyer l'offre</button>
                                    </div>
                                    <small class="form-text text-muted">
                                        <?php echo $negociation['tentatives_restantes']; ?> tentatives restantes
                                    </small>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                Le nombre maximum de tentatives a été atteint.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Informations</h5>
                    </div>
                    <div class="card-body">
                        <p>
                            <strong>Vendeur :</strong><br>
                            <?php echo htmlspecialchars($negociation['prenom_vendeur'] . ' ' . substr($negociation['nom_vendeur'], 0, 1) . '.'); ?>
                        </p>
                        <p>
                            <strong>Acheteur :</strong><br>
                            <?php echo htmlspecialchars($negociation['prenom_acheteur'] . ' ' . substr($negociation['nom_acheteur'], 0, 1) . '.'); ?>
                        </p>
                        <p>
                            <strong>Date de début :</strong><br>
                            <?php echo date('d/m/Y H:i', strtotime($negociation['date_creation'])); ?>
                        </p>
                        <hr>
                        <div class="progress mb-2">
                            <div class="progress-bar" role="progressbar" 
                                 style="width: <?php echo (5 - $negociation['tentatives_restantes']) * 20; ?>%">
                            </div>
                        </div>
                        <small class="text-muted">
                            <?php echo $negociation['tentatives_restantes']; ?> tentatives restantes sur 5
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Validation du formulaire
        $('#offerForm').on('submit', function(e) {
            const montant = parseFloat($('#montant').val());
            const prixActuel = <?php echo $negociation['prix_actuel']; ?>;
            
            <?php if ($estVendeur): ?>
                if (montant >= prixActuel) {
                    e.preventDefault();
                    alert('Le prix proposé doit être inférieur au prix actuel');
                }
            <?php else: ?>
                if (montant <= prixActuel) {
                    e.preventDefault();
                    alert('Le prix proposé doit être supérieur au prix actuel');
                }
            <?php endif; ?>
        });
    });
    </script>
</body>
</html>

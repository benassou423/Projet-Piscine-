<?php
require_once __DIR__ . '/../config/base_donnees.php';
require_once __DIR__ . '/../includes/authentification.php';

// Déconnecter l'utilisateur
$auth->deconnexion();

// Rediriger vers la page d'accueil
header('Location: /');
exit;
?>

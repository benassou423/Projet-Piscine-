<?php
require_once('../includes/auth.php');
require_once('../includes/negociations.php');

// Vérifier si l'utilisateur est connecté
if (!$auth->estConnecte()) {
    header('Location: /pages/login.php');
    exit;
}

// Déterminer si l'utilisateur est vendeur
$estVendeur = $auth->estVendeur();

// Obtenir les négociations actives
$negociations = $gestionnaireNegociations->obtenirNegociationsUtilisateur(
    $_SESSION['utilisateur_id'],
    $estVendeur
);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Négociations - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container mt-4">
        <h1 class="mb-4">Mes Négociations</h1>
        
        <?php if (empty($negociations)): ?>
            <div class="alert alert-info">
                Vous n'avez aucune négociation en cours.
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($negociations as $negociation): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="card-header">
                                <h5 class="card-title mb-0">
                                    <?php echo htmlspecialchars($negociation['nom_produit']); ?>
                                </h5>
                            </div>
                            
                            <?php if ($negociation['chemin_image']): ?>
                                <img src="<?php echo htmlspecialchars($negociation['chemin_image']); ?>" 
                                     class="card-img-top" style="height: 200px; object-fit: cover;"
                                     alt="<?php echo htmlspecialchars($negociation['nom_produit']); ?>">
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <strong>Prix initial :</strong><br>
                                        <?php echo number_format($negociation['prix_initial'], 2); ?> €
                                    </div>
                                    <div class="col-6">
                                        <strong>Prix actuel :</strong><br>
                                        <?php echo number_format($negociation['prix_actuel'], 2); ?> €
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <strong>Tentatives restantes :</strong>
                                    <?php echo $negociation['tentatives_restantes']; ?>/5
                                </div>
                                
                                <?php if ($estVendeur): ?>
                                    <p>
                                        <strong>Acheteur :</strong>
                                        <?php echo htmlspecialchars($negociation['prenom_acheteur'] . ' ' . substr($negociation['nom_acheteur'], 0, 1) . '.'); ?>
                                    </p>
                                <?php else: ?>
                                    <p>
                                        <strong>Vendeur :</strong>
                                        <?php echo htmlspecialchars($negociation['prenom_vendeur'] . ' ' . substr($negociation['nom_vendeur'], 0, 1) . '.'); ?>
                                    </p>
                                <?php endif; ?>
                                
                                <div class="text-center">
                                    <a href="/pages/negociation.php?id=<?php echo $negociation['id']; ?>" 
                                       class="btn btn-primary">
                                        Voir les détails
                                    </a>
                                </div>
                            </div>
                            
                            <div class="card-footer text-muted">
                                Démarré le <?php echo date('d/m/Y', strtotime($negociation['date_creation'])); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <?php include '../includes/footer.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

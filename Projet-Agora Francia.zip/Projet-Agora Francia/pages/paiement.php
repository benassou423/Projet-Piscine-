<?php
require_once('../includes/auth.php');
require_once('../includes/cart.php');

// Vérifier si l'utilisateur est connecté
if (!$auth->estConnecte()) {
    header('Location: /pages/login.php?redirect=checkout');
    exit;
}

$utilisateur = $auth->obtenirUtilisateurCourant();
$contenuPanier = $panier->obtenirContenu();

if (empty($contenuPanier['articles'])) {
    header('Location: /pages/cart.php');
    exit;
}

// Traiter le formulaire de paiement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // TODO: Intégrer avec un système de paiement réel
    $commande = [
        'adresse_livraison' => $_POST['adresse_ligne1'],
        'adresse_ligne2' => $_POST['adresse_ligne2'],
        'ville' => $_POST['ville'],
        'code_postal' => $_POST['code_postal'],
        'pays' => $_POST['pays'],
        'telephone' => $_POST['telephone']
    ];
    
    // Simuler un paiement réussi
    header('Location: /pages/confirmation.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container mt-4">
        <h1 class="mb-4">Finaliser votre commande</h1>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Adresse de livraison</h5>
                        <form id="checkoutForm" method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="prenom" class="form-label">Prénom</label>
                                    <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo htmlspecialchars($utilisateur['prenom']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="nom" class="form-label">Nom</label>
                                    <input type="text" class="form-control" id="nom" name="nom" value="<?php echo htmlspecialchars($utilisateur['nom']); ?>" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="adresse_ligne1" class="form-label">Adresse</label>
                                <input type="text" class="form-control" id="adresse_ligne1" name="adresse_ligne1" value="<?php echo htmlspecialchars($utilisateur['adresse_ligne1']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="adresse_ligne2" class="form-label">Complément d'adresse</label>
                                <input type="text" class="form-control" id="adresse_ligne2" name="adresse_ligne2" value="<?php echo htmlspecialchars($utilisateur['adresse_ligne2']); ?>">
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="ville" class="form-label">Ville</label>
                                    <input type="text" class="form-control" id="ville" name="ville" value="<?php echo htmlspecialchars($utilisateur['ville']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="code_postal" class="form-label">Code postal</label>
                                    <input type="text" class="form-control" id="code_postal" name="code_postal" value="<?php echo htmlspecialchars($utilisateur['code_postal']); ?>" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="pays" class="form-label">Pays</label>
                                <select class="form-select" id="pays" name="pays" required>
                                    <option value="FR" <?php echo $utilisateur['pays'] === 'FR' ? 'selected' : ''; ?>>France</option>
                                    <option value="BE" <?php echo $utilisateur['pays'] === 'BE' ? 'selected' : ''; ?>>Belgique</option>
                                    <option value="CH" <?php echo $utilisateur['pays'] === 'CH' ? 'selected' : ''; ?>>Suisse</option>
                                    <option value="LU" <?php echo $utilisateur['pays'] === 'LU' ? 'selected' : ''; ?>>Luxembourg</option>
                                </select>
                            </div>

                            <div class="mb-4">
                                <label for="telephone" class="form-label">Téléphone</label>
                                <input type="tel" class="form-control" id="telephone" name="telephone" value="<?php echo htmlspecialchars($utilisateur['telephone']); ?>" required>
                            </div>

                            <h5 class="mb-3">Informations de paiement</h5>
                            <div class="mb-3">
                                <label for="type_carte" class="form-label">Type de carte</label>
                                <select class="form-select" id="type_carte" name="type_carte" required>
                                    <option value="visa">Visa</option>
                                    <option value="mastercard">MasterCard</option>
                                    <option value="amex">American Express</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="numero_carte" class="form-label">Numéro de carte</label>
                                <input type="text" class="form-control" id="numero_carte" name="numero_carte" required pattern="\d{16}">
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="date_expiration" class="form-label">Date d'expiration</label>
                                    <input type="text" class="form-control" id="date_expiration" name="date_expiration" placeholder="MM/AA" required pattern="\d{2}/\d{2}">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="cvv" class="form-label">Code de sécurité (CVV)</label>
                                    <input type="text" class="form-control" id="cvv" name="cvv" required pattern="\d{3,4}">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Récapitulatif de la commande</h5>
                        <?php foreach ($contenuPanier['articles'] as $article): ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span><?php echo htmlspecialchars($article['nom']); ?> (x<?php echo $article['quantite']; ?>)</span>
                                <span><?php echo number_format($article['sous_total'], 2); ?> €</span>
                            </div>
                        <?php endforeach; ?>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span>Sous-total :</span>
                            <span><?php echo number_format($contenuPanier['total'], 2); ?> €</span>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span>Frais de livraison :</span>
                            <span>Gratuit</span>
                        </div>
                        
                        <hr>
                        
                        <div class="d-flex justify-content-between mb-3">
                            <strong>Total :</strong>
                            <strong><?php echo number_format($contenuPanier['total'], 2); ?> €</strong>
                        </div>
                        
                        <button type="submit" form="checkoutForm" class="btn btn-primary w-100">Payer maintenant</button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Formater le numéro de carte
        $('#numero_carte').on('input', function() {
            $(this).val($(this).val().replace(/\D/g, ''));
        });
        
        // Formater la date d'expiration
        $('#date_expiration').on('input', function() {
            let val = $(this).val().replace(/\D/g, '');
            if (val.length > 2) {
                val = val.substring(0, 2) + '/' + val.substring(2, 4);
            }
            $(this).val(val);
        });
        
        // Formater le CVV
        $('#cvv').on('input', function() {
            $(this).val($(this).val().replace(/\D/g, ''));
        });
        
        // Validation du formulaire
        $('#checkoutForm').on('submit', function(e) {
            const numeroCarteValide = /^\d{16}$/.test($('#numero_carte').val());
            const dateExpirationValide = /^\d{2}\/\d{2}$/.test($('#date_expiration').val());
            const cvvValide = /^\d{3,4}$/.test($('#cvv').val());
            
            if (!numeroCarteValide || !dateExpirationValide || !cvvValide) {
                e.preventDefault();
                alert('Veuillez vérifier vos informations de paiement.');
            }
        });
    });
    </script>
</body>
</html>

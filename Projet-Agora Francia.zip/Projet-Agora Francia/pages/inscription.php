<?php
require_once __DIR__ . '/../config/base_donnees.php';
require_once __DIR__ . '/../includes/authentification.php';

// Gestion de l'inscription
$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donneesUtilisateur = [
        'email' => trim($_POST['email'] ?? ''),
        'mot_de_passe' => $_POST['mot_de_passe'] ?? '',
        'prenom' => trim($_POST['prenom'] ?? ''),
        'nom' => trim($_POST['nom'] ?? ''),
        'type_utilisateur' => 'acheteur', // Type par défaut pour l'inscription
        'adresse_ligne1' => trim($_POST['adresse_ligne1'] ?? ''),
        'adresse_ligne2' => trim($_POST['adresse_ligne2'] ?? ''),
        'ville' => trim($_POST['ville'] ?? ''),
        'code_postal' => trim($_POST['code_postal'] ?? ''),
        'pays' => trim($_POST['pays'] ?? ''),
        'telephone' => trim($_POST['telephone'] ?? '')
    ];
      // Validation du mot de passe
    if ($_POST['mot_de_passe'] !== $_POST['confirmation_mot_de_passe']) {
        $message = 'Les mots de passe ne correspondent pas';
    } else {
        $resultat = $auth->inscription($donneesUtilisateur);
        
        if ($resultat['succes']) {
            $success = true;
            $message = 'Inscription réussie ! Vous pouvez maintenant vous connecter.';
        } else {
            $message = $resultat['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - Agora Francia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>    <?php include '../includes/entete.php'; ?>

    <main class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center mb-0">Inscription</h3>
                    </div>
                    <div class="card-body">                        <?php if ($message): ?>
                            <div class="alert <?= $success ? 'alert-success' : 'alert-danger' ?>">
                                <?= htmlspecialchars($message) ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="text-center">
                                <a href="connexion.php" class="btn btn-primary">Se connecter</a>
                            </div>
                        <?php else: ?>
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="prenom" class="form-label">Prénom</label>
                                        <input type="text" class="form-control" id="prenom" name="prenom" 
                                               value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="nom" class="form-label">Nom</label>
                                        <input type="text" class="form-control" id="nom" name="nom" 
                                               value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="mot_de_passe" class="form-label">Mot de passe</label>
                                        <input type="password" class="form-control" id="mot_de_passe" 
                                               name="mot_de_passe" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="confirmation_mot_de_passe" class="form-label">Confirmer le mot de passe</label>
                                        <input type="password" class="form-control" id="confirmation_mot_de_passe" 
                                               name="confirmation_mot_de_passe" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="adresse_ligne1" class="form-label">Adresse (ligne 1)</label>
                                    <input type="text" class="form-control" id="adresse_ligne1" name="adresse_ligne1" 
                                           value="<?= htmlspecialchars($_POST['adresse_ligne1'] ?? '') ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="address_line2" class="form-label">Adresse (ligne 2)</label>
                                    <input type="text" class="form-control" id="address_line2" name="address_line2">
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="city" class="form-label">Ville</label>
                                        <input type="text" class="form-control" id="city" name="city" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="postal_code" class="form-label">Code postal</label>
                                        <input type="text" class="form-control" id="postal_code" name="postal_code" required>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="country" class="form-label">Pays</label>
                                        <input type="text" class="form-control" id="country" name="country" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="phone" class="form-label">Téléphone</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                                    <label class="form-check-label" for="terms">
                                        J'accepte les <a href="../pages/terms.php">conditions d'utilisation</a> et la 
                                        <a href="../pages/privacy.php">politique de confidentialité</a>
                                    </label>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">S'inscrire</button>
                                </div>
                            </form>
                        <?php endif; ?>
                        
                        <hr>
                          <div class="text-center">
                            <p>Vous avez déjà un compte ? <a href="connexion.php">Connectez-vous</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>    </main>

    <?php include '../includes/pied.php'; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

// Document Ready
$(document).ready(function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Cart functionality
    updateCartCount();
    
    // Product search
    initializeSearch();
    
    // Auction timers
    initializeAuctionTimers();
});

// Cart Functions
function updateCartCount() {
    $.ajax({
        url: '/scripts/cart_count.php',
        method: 'GET',
        success: function(response) {
            $('.cart-count').text(response.count);
        }
    });
}

function addToCart(productId, type) {
    $.ajax({
        url: '/scripts/add_to_cart.php',
        method: 'POST',
        data: {
            product_id: productId,
            purchase_type: type
        },
        success: function(response) {
            if (response.success) {
                updateCartCount();
                showNotification('Produit ajouté au panier', 'success');
            } else {
                showNotification(response.message, 'error');
            }
        }
    });
}

// Search Functions
function initializeSearch() {
    $('#searchInput').on('input', debounce(function() {
        const query = $(this).val();
        if (query.length >= 3) {
            performSearch(query);
        }
    }, 500));
}

function performSearch(query) {
    $.ajax({
        url: '/scripts/search.php',
        method: 'GET',
        data: { q: query },
        success: function(response) {
            displaySearchResults(response);
        }
    });
}

// Auction Functions
function initializeAuctionTimers() {
    $('.auction-timer').each(function() {
        const endTime = $(this).data('end-time');
        updateTimer($(this), endTime);
    });
}

function updateTimer(element, endTime) {
    const timer = setInterval(function() {
        const now = new Date().getTime();
        const distance = new Date(endTime).getTime() - now;

        if (distance < 0) {
            clearInterval(timer);
            element.html('Enchère terminée');
            return;
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        element.html(`${days}j ${hours}h ${minutes}m ${seconds}s`);
    }, 1000);
}

// Negotiation Functions
function submitOffer(productId, price) {
    $.ajax({
        url: '/scripts/submit_offer.php',
        method: 'POST',
        data: {
            product_id: productId,
            offer_price: price
        },
        success: function(response) {
            if (response.success) {
                showNotification('Offre soumise avec succès', 'success');
                updateNegotiationStatus(productId);
            } else {
                showNotification(response.message, 'error');
            }
        }
    });
}

// Utility Functions
function showNotification(message, type = 'info') {
    const toast = $(`
        <div class="toast" role="alert">
            <div class="toast-body ${type}">
                ${message}
            </div>
        </div>
    `);
    
    $('.toast-container').append(toast);
    toast.toast('show');
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

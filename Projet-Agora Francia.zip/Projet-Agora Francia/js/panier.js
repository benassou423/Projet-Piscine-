// Gestionnaire du panier
document.addEventListener('DOMContentLoaded', function() {
    // Mettre à jour la quantité
    function updateQuantity(productId, newQuantity) {
        fetch('/pages/panier.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=actualiser&produit_id=${productId}&quantite=${newQuantity}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.succes) {
                // Recharger la page pour mettre à jour les totaux
                window.location.reload();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
            alert('Une erreur est survenue lors de la mise à jour du panier');
        });
    }

    // Supprimer un article
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            
            fetch('/pages/panier.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=supprimer&produit_id=${productId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.succes) {
                    window.location.reload();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Erreur:', error);
                alert('Une erreur est survenue lors de la suppression de l\'article');
            });
        });
    });

    // Gérer les boutons + et -
    document.querySelectorAll('.update-quantity').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const input = document.querySelector(`.quantity-input[data-product-id="${productId}"]`);
            let currentQuantity = parseInt(input.value);
            
            if (this.dataset.action === 'increase') {
                currentQuantity++;
            } else if (this.dataset.action === 'decrease' && currentQuantity > 1) {
                currentQuantity--;
            }
            
            updateQuantity(productId, currentQuantity);
        });
    });

    // Gérer la saisie directe de quantité
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', function() {
            const productId = this.dataset.productId;
            const newQuantity = parseInt(this.value);
            
            if (newQuantity < 1) {
                this.value = 1;
                return;
            }
            
            updateQuantity(productId, newQuantity);
        });
    });

    // Vider le panier
    const emptyCartButton = document.getElementById('empty-cart');
    if (emptyCartButton) {
        emptyCartButton.addEventListener('click', function() {
            if (confirm('Êtes-vous sûr de vouloir vider votre panier ?')) {
                fetch('/pages/panier.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=vider'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.succes) {
                        window.location.reload();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    alert('Une erreur est survenue lors de la vidange du panier');
                });
            }
        });
    }
});

<?php
require_once('../includes/auth.php');
require_once('../includes/cart.php');

header('Content-Type: application/json');

// Return cart count
echo json_encode(['count' => $cart->getCount()]);
?>

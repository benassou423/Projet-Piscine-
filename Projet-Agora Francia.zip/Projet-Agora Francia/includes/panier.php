<?php
require_once(__DIR__ . '/../config/base_donnees.php');
require_once(__DIR__ . '/authentification.php');

class Panier {
    private PDO $connexion;
    private $utilisateurId;
    
    public function __construct(PDO $connexion_bdd, $utilisateurId = null) {
        $this->connexion = $connexion_bdd;
        $this->utilisateurId = $utilisateurId;
        
        if (!isset($_SESSION['panier'])) {
            $_SESSION['panier'] = [];
        }
    }
    
    // Ajouter un article au panier
    public function ajouterArticle($produitId, $quantite = 1) {
        try {
            // Vérifier si le produit existe et est disponible
            $stmt = $this->connexion->prepare("
                SELECT id_produit, nom, prix_initial as prix, etat as stock, type_vente, statut 
                FROM produits 
                WHERE id_produit = ? AND statut = 'disponible'
            ");
            $stmt->execute([$produitId]);
            
            $produit = $stmt->fetch();
            if (!$produit) {
                return ['succes' => false, 'message' => 'Produit non disponible'];
            }
            
            if ($produit['type_vente'] === 'enchere') {
                return ['succes' => false, 'message' => 'Les produits aux enchères ne peuvent pas être ajoutés au panier'];
            }
            
            if (isset($_SESSION['panier'][$produitId])) {
                $_SESSION['panier'][$produitId] += $quantite;
            } else {
                $_SESSION['panier'][$produitId] = $quantite;
            }
            
            return ['succes' => true, 'message' => 'Produit ajouté au panier'];
        } catch (PDOException $e) {
            return ['succes' => false, 'message' => 'Erreur lors de l\'ajout au panier'];
        }
    }
    
    // Supprimer un article du panier
    public function supprimerArticle($produitId) {
        if (isset($_SESSION['panier'][$produitId])) {
            unset($_SESSION['panier'][$produitId]);
            return ['succes' => true, 'message' => 'Produit retiré du panier'];
        }
        return ['succes' => false, 'message' => 'Produit non trouvé dans le panier'];
    }
    
    // Mettre à jour la quantité
    public function mettreAJourQuantite($produitId, $quantite) {
        if ($quantite <= 0) {
            return $this->supprimerArticle($produitId);
        }
        
        try {
            $stmt = $this->connexion->prepare("SELECT etat as stock FROM produits WHERE id_produit = ?");
            $stmt->execute([$produitId]);
            
            $produit = $stmt->fetch();
            if (!$produit) {
                return ['succes' => false, 'message' => 'Produit non trouvé'];
            }
            
            $_SESSION['panier'][$produitId] = $quantite;
            return ['succes' => true, 'message' => 'Quantité mise à jour'];
        } catch (PDOException $e) {
            return ['succes' => false, 'message' => 'Erreur lors de la mise à jour'];
        }
    }
    
    // Obtenir le contenu du panier
    public function obtenirContenu() {
        if (empty($_SESSION['panier'])) {
            return [];
        }
        
        $articles = [];
        $total = 0;
        
        foreach ($_SESSION['panier'] as $produitId => $quantite) {
            try {
                $stmt = $this->connexion->prepare("
                    SELECT p.id_produit, p.nom, p.prix_initial as prix, p.description,
                           p.photos as images
                    FROM produits p 
                    WHERE p.id_produit = ?
                ");
                $stmt->execute([$produitId]);
                
                if ($produit = $stmt->fetch()) {
                    $images = json_decode($produit['images'], true);
                    $produit['image_principale'] = $images[0] ?? null;
                    $produit['quantite'] = $quantite;
                    $produit['sous_total'] = $produit['prix'] * $quantite;
                    $total += $produit['sous_total'];
                    $articles[] = $produit;
                }
            } catch (PDOException $e) {
                continue;
            }
        }
        
        return [
            'articles' => $articles,
            'total' => $total,
            'nombre' => count($articles)
        ];
    }
    
    // Vider le panier
    public function vider() {
        $_SESSION['panier'] = [];
        return ['succes' => true, 'message' => 'Panier vidé'];
    }
    
    // Obtenir le nombre d'articles
    public function obtenirNombre() {
        return count($_SESSION['panier']);
    }
    
    // Vérifier si un article est dans le panier
    public function contientArticle($produitId) {
        return isset($_SESSION['panier'][$produitId]);
    }
    
    // Obtenir la quantité d'un article
    public function obtenirQuantiteArticle($produitId) {
        return $_SESSION['panier'][$produitId] ?? 0;
    }
}

// Créer une instance du panier
$panier = new Panier($bdd, $auth->estConnecte() ? $_SESSION['utilisateur_id'] : null);

// Gérer les requêtes AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $reponse = ['succes' => false, 'message' => 'Action non valide'];
    
    switch ($_POST['action']) {
        case 'ajouter':
            if (isset($_POST['produit_id'])) {
                $quantite = isset($_POST['quantite']) ? (int)$_POST['quantite'] : 1;
                $reponse = $panier->ajouterArticle($_POST['produit_id'], $quantite);
            }
            break;
            
        case 'supprimer':
            if (isset($_POST['produit_id'])) {
                $reponse = $panier->supprimerArticle($_POST['produit_id']);
            }
            break;
            
        case 'actualiser':
            if (isset($_POST['produit_id']) && isset($_POST['quantite'])) {
                $reponse = $panier->mettreAJourQuantite($_POST['produit_id'], (int)$_POST['quantite']);
            }
            break;
            
        case 'vider':
            $reponse = $panier->vider();
            break;
    }
    
    echo json_encode($reponse);
    exit;
}
?>

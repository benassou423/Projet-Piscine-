<?php
require_once __DIR__ . '/../config/base_donnees.php';

class GestionProduits {
    private $bdd;
    
    public function __construct($bdd) {
        $this->bdd = $bdd;
    }
    
    public function ajouterProduit($donnees) {
        try {
            $this->bdd->beginTransaction();
            
            $stmt = $this->bdd->prepare("
                INSERT INTO produits (
                    nom, description, prix_initial, type_vente, etat,
                    photos, video, id_categorie, id_vendeur, date_fin
                ) VALUES (
                    :nom, :description, :prix_initial, :type_vente, :etat,
                    :photos, :video, :id_categorie, :id_vendeur, :date_fin
                )
            ");
            
            $stmt->execute([
                'nom' => $donnees['nom'],
                'description' => $donnees['description'],
                'prix_initial' => $donnees['prix_initial'],
                'type_vente' => $donnees['type_vente'],
                'etat' => $donnees['etat'],
                'photos' => json_encode($donnees['photos']),
                'video' => $donnees['video'] ?? null,
                'id_categorie' => $donnees['id_categorie'],
                'id_vendeur' => $donnees['id_vendeur'],
                'date_fin' => $donnees['date_fin'] ?? null
            ]);
            
            $id_produit = $this->bdd->lastInsertId();
            $this->bdd->commit();
            
            return ['succes' => true, 'id_produit' => $id_produit];
            
        } catch (PDOException $e) {
            $this->bdd->rollBack();
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }
    
    public function obtenirProduit($id_produit) {
        $stmt = $this->bdd->prepare("
            SELECT p.*, c.nom as categorie, u.nom as vendeur_nom, u.prenom as vendeur_prenom
            FROM produits p
            JOIN categories c ON p.id_categorie = c.id_categorie
            JOIN utilisateurs u ON p.id_vendeur = u.id_utilisateur
            WHERE p.id_produit = ?
        ");
        
        $stmt->execute([$id_produit]);
        return $stmt->fetch();
    }
    
    public function listerProduits($filtres = []) {
        $sql = "SELECT p.*, c.nom as categorie, u.nom as vendeur_nom, u.prenom as vendeur_prenom
                FROM produits p
                JOIN categories c ON p.id_categorie = c.id_categorie
                JOIN utilisateurs u ON p.id_vendeur = u.id_utilisateur
                WHERE 1=1";
        
        $params = [];
        
        if (!empty($filtres['type_vente'])) {
            $sql .= " AND p.type_vente = ?";
            $params[] = $filtres['type_vente'];
        }
        
        if (!empty($filtres['categorie'])) {
            $sql .= " AND p.id_categorie = ?";
            $params[] = $filtres['categorie'];
        }
        
        if (!empty($filtres['statut'])) {
            $sql .= " AND p.statut = ?";
            $params[] = $filtres['statut'];
        }
        
        $sql .= " ORDER BY p.date_creation DESC";
        
        $stmt = $this->bdd->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function mettreAJourProduit($id_produit, $donnees) {
        try {
            $this->bdd->beginTransaction();
            
            $stmt = $this->bdd->prepare("
                UPDATE produits SET
                    nom = :nom,
                    description = :description,
                    prix_initial = :prix_initial,
                    etat = :etat,
                    photos = :photos,
                    video = :video,
                    id_categorie = :id_categorie,
                    statut = :statut,
                    date_fin = :date_fin
                WHERE id_produit = :id_produit AND id_vendeur = :id_vendeur
            ");
            
            $resultat = $stmt->execute([
                'nom' => $donnees['nom'],
                'description' => $donnees['description'],
                'prix_initial' => $donnees['prix_initial'],
                'etat' => $donnees['etat'],
                'photos' => json_encode($donnees['photos']),
                'video' => $donnees['video'] ?? null,
                'id_categorie' => $donnees['id_categorie'],
                'statut' => $donnees['statut'],
                'date_fin' => $donnees['date_fin'] ?? null,
                'id_produit' => $id_produit,
                'id_vendeur' => $donnees['id_vendeur']
            ]);
            
            $this->bdd->commit();
            return ['succes' => true];
            
        } catch (PDOException $e) {
            $this->bdd->rollBack();
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }
}

// Créer une instance
$gestionProduits = new GestionProduits($bdd);
?>

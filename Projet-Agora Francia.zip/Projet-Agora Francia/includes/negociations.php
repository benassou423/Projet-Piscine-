<?php
require_once(__DIR__ . '/../config/base_donnees.php');
global $bdd;

class GestionnaireNegociations {
    private PDO $connexion;
    
    public function __construct(PDO $connexion_bdd) {
        $this->connexion = $connexion_bdd;
    }
    
    /**
     * Démarre une négociation pour un produit
     */
    public function demarrerNegociation($produitId, $acheteurId, $prixPropose) {
        try {
            $this->connexion->beginTransaction();
            
            // Vérifier si le produit est disponible pour la négociation
            $stmt = $this->connexion->prepare("
                SELECT id_produit, type_vente, statut, prix_initial, id_vendeur 
                FROM produits 
                WHERE id_produit = ? AND type_vente = 'negociation' AND statut = 'disponible'
            ");
            $stmt->execute([$produitId]);
            
            $produit = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$produit) {
                throw new Exception('Ce produit n\'est pas disponible pour la négociation');
            }
            
            // Vérifier si une négociation est déjà en cours pour ce produit et cet acheteur
            $stmt = $this->connexion->prepare("
                SELECT id_negociation 
                FROM negociations 
                WHERE id_produit = ? AND id_acheteur = ? AND statut = 'en_cours'
            ");
            $stmt->execute([$produitId, $acheteurId]);
            
            if ($stmt->fetch()) {
                throw new Exception('Une négociation est déjà en cours pour ce produit');
            }
            
            // Créer la négociation
            $stmt = $this->connexion->prepare("
                INSERT INTO negociations (id_produit, id_acheteur, prix_propose, nombre_echanges, statut)
                VALUES (?, ?, ?, 1, 'en_cours')
            ");
            
            $stmt->execute([$produitId, $acheteurId, $prixPropose]);
            $negociationId = $this->connexion->lastInsertId();
            
            // Créer une notification pour le vendeur
            $this->creerNotification(
                $produit['id_vendeur'],
                'Nouvelle négociation',
                "Une nouvelle offre de {$prixPropose}€ a été faite pour votre produit",
                'negociation'
            );
            
            $this->connexion->commit();
            return ['succes' => true, 'id_negociation' => $negociationId];
            
        } catch (Exception $e) {
            $this->connexion->rollBack();
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Faire une contre-offre sur une négociation
     */
    public function faireContreOffre($negociationId, $montant, $estVendeur) {
        try {
            $this->connexion->beginTransaction();
            
            // Récupérer les détails de la négociation
            $stmt = $this->connexion->prepare("
                SELECT n.*, p.nom as nom_produit, p.id_vendeur, p.prix_initial
                FROM negociations n
                JOIN produits p ON n.id_produit = p.id_produit
                WHERE n.id_negociation = ? AND n.statut = 'en_cours'
            ");
            
            $stmt->execute([$negociationId]);
            $negociation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$negociation) {
                throw new Exception('Négociation non trouvée ou terminée');
            }
            
            // Vérifier le nombre d'échanges (max 5)
            if ($negociation['nombre_echanges'] >= 5) {
                throw new Exception('Le nombre maximum de négociations a été atteint');
            }
            
            // Mettre à jour la négociation
            $stmt = $this->connexion->prepare("
                UPDATE negociations 
                SET prix_contre_offre = ?, 
                    nombre_echanges = nombre_echanges + 1,
                    statut = ?,
                    date_mise_a_jour = CURRENT_TIMESTAMP
                WHERE id_negociation = ?
            ");
            
            $statut = 'en_cours';
            // Si le vendeur accepte un prix supérieur ou égal au prix proposé
            // Ou si l'acheteur accepte un prix inférieur ou égal à la contre-offre
            if (($estVendeur && $montant <= $negociation['prix_propose']) || 
                (!$estVendeur && $montant >= $negociation['prix_contre_offre'])) {
                $statut = 'acceptee';
            }
            
            $stmt->execute([$montant, $statut, $negociationId]);
            
            // Créer une notification pour l'autre partie
            $destinataireId = $estVendeur ? $negociation['id_acheteur'] : $negociation['id_vendeur'];
            $this->creerNotification(
                $destinataireId,
                'Nouvelle contre-offre',
                "Une contre-offre de {$montant}€ a été faite pour {$negociation['nom_produit']}",
                'negociation'
            );
            
            // Si la négociation est acceptée, mettre à jour le statut du produit
            if ($statut === 'acceptee') {
                $stmt = $this->connexion->prepare("
                    UPDATE produits 
                    SET statut = 'vendu' 
                    WHERE id_produit = ?
                ");
                $stmt->execute([$negociation['id_produit']]);
            }
            
            $this->connexion->commit();
            return [
                'succes' => true, 
                'statut' => $statut, 
                'nombre_echanges' => $negociation['nombre_echanges'] + 1
            ];
            
        } catch (Exception $e) {
            $this->connexion->rollBack();
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Refuser une négociation
     */
    public function refuserNegociation($negociationId, $estVendeur) {
        try {
            $this->connexion->beginTransaction();
            
            $stmt = $this->connexion->prepare("
                SELECT n.*, p.nom as nom_produit, p.id_vendeur
                FROM negociations n
                JOIN produits p ON n.id_produit = p.id_produit
                WHERE n.id_negociation = ? AND n.statut = 'en_cours'
            ");
            
            $stmt->execute([$negociationId]);
            $negociation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$negociation) {
                throw new Exception('Négociation non trouvée ou déjà terminée');
            }
            
            // Mettre à jour le statut de la négociation
            $stmt = $this->connexion->prepare("
                UPDATE negociations 
                SET statut = 'refusee',
                    date_mise_a_jour = CURRENT_TIMESTAMP
                WHERE id_negociation = ?
            ");
            
            $stmt->execute([$negociationId]);
            
            // Créer une notification pour l'autre partie
            $destinataireId = $estVendeur ? $negociation['id_acheteur'] : $negociation['id_vendeur'];
            $this->creerNotification(
                $destinataireId,
                'Négociation refusée',
                "La négociation pour {$negociation['nom_produit']} a été refusée",
                'negociation'
            );
            
            $this->connexion->commit();
            return ['succes' => true];
            
        } catch (Exception $e) {
            $this->connexion->rollBack();
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Récupérer l'historique des négociations d'un utilisateur
     */
    public function getHistoriqueNegociations($utilisateurId, $estVendeur = false) {
        $query = "
            SELECT n.*, p.nom as nom_produit, p.photos, p.prix_initial,
                   u.nom as nom_autre_partie
            FROM negociations n
            JOIN produits p ON n.id_produit = p.id_produit
            JOIN utilisateurs u ON u.id_utilisateur = ?
            WHERE " . ($estVendeur ? "p.id_vendeur" : "n.id_acheteur") . " = ?
            ORDER BY n.date_creation DESC
        ";
        
        try {
            $stmt = $this->connexion->prepare($query);
            $joinId = $estVendeur ? 'n.id_acheteur' : 'p.id_vendeur';
            $stmt->execute([$joinId, $utilisateurId]);
            
            return [
                'succes' => true,
                'negociations' => $stmt->fetchAll(PDO::FETCH_ASSOC)
            ];
            
        } catch (Exception $e) {
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }

    private function creerNotification($destinataireId, $titre, $message, $type) {
        $stmt = $this->connexion->prepare("
            INSERT INTO notifications (id_utilisateur, titre, message, type)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$destinataireId, $titre, $message, $type]);
    }
}

// Créer une instance du gestionnaire de négociations
$gestionnaireNegociations = new GestionnaireNegociations($bdd);
?>

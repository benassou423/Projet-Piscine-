<?php
require_once __DIR__ . '/../config/base_donnees.php';

class GestionEncheres {
    private $bdd;
    
    public function __construct($bdd) {
        $this->bdd = $bdd;
    }
    
    public function placerEnchere($donnees) {
        try {
            $this->bdd->beginTransaction();
            
            // Vérifier si le produit est toujours disponible pour enchérir
            $stmt = $this->bdd->prepare("
                SELECT prix_initial, statut, date_fin
                FROM produits 
                WHERE id_produit = ? AND type_vente = 'enchere'
            ");
            $stmt->execute([$donnees['id_produit']]);
            $produit = $stmt->fetch();
            
            if (!$produit || $produit['statut'] !== 'disponible' || 
                ($produit['date_fin'] && strtotime($produit['date_fin']) < time())) {
                throw new Exception("Le produit n'est plus disponible pour enchérir");
            }
            
            // Vérifier si c'est la meilleure offre
            $stmt = $this->bdd->prepare("
                SELECT montant 
                FROM encheres 
                WHERE id_produit = ? 
                ORDER BY montant DESC 
                LIMIT 1
            ");
            $stmt->execute([$donnees['id_produit']]);
            $meilleureOffre = $stmt->fetch();
            
            if ($meilleureOffre && $donnees['montant'] <= $meilleureOffre['montant']) {
                throw new Exception("Votre enchère doit être supérieure à la meilleure offre actuelle");
            }
            
            // Créer la nouvelle enchère
            $stmt = $this->bdd->prepare("
                INSERT INTO encheres (
                    id_produit, id_acheteur, montant, montant_max
                ) VALUES (?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $donnees['id_produit'],
                $donnees['id_acheteur'],
                $donnees['montant'],
                $donnees['montant_max']
            ]);
            
            $this->bdd->commit();
            return ['succes' => true];
            
        } catch (Exception $e) {
            $this->bdd->rollBack();
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }
    
    public function obtenirEncheresProduit($id_produit) {
        $stmt = $this->bdd->prepare("
            SELECT e.*, u.nom, u.prenom
            FROM encheres e
            JOIN utilisateurs u ON e.id_acheteur = u.id_utilisateur
            WHERE e.id_produit = ?
            ORDER BY e.montant DESC
        ");
        
        $stmt->execute([$id_produit]);
        return $stmt->fetchAll();
    }
    
    public function terminerEnchere($id_produit) {
        try {
            $this->bdd->beginTransaction();
            
            // Trouver la meilleure enchère
            $stmt = $this->bdd->prepare("
                SELECT e.*, u.email 
                FROM encheres e
                JOIN utilisateurs u ON e.id_acheteur = u.id_utilisateur
                WHERE e.id_produit = ?
                ORDER BY e.montant DESC
                LIMIT 1
            ");
            $stmt->execute([$id_produit]);
            $meilleureEnchere = $stmt->fetch();
            
            if ($meilleureEnchere) {
                // Mettre à jour le statut de l'enchère gagnante
                $stmt = $this->bdd->prepare("
                    UPDATE encheres 
                    SET statut = CASE 
                        WHEN id_enchere = ? THEN 'gagnante'
                        ELSE 'perdue'
                    END
                    WHERE id_produit = ?
                ");
                $stmt->execute([$meilleureEnchere['id_enchere'], $id_produit]);
                
                // Mettre à jour le statut du produit
                $stmt = $this->bdd->prepare("
                    UPDATE produits 
                    SET statut = 'vendu'
                    WHERE id_produit = ?
                ");
                $stmt->execute([$id_produit]);
            }
            
            $this->bdd->commit();
            return ['succes' => true, 'gagnant' => $meilleureEnchere];
            
        } catch (Exception $e) {
            $this->bdd->rollBack();
            return ['succes' => false, 'message' => $e->getMessage()];
        }
    }
}

// Créer une instance
$gestionEncheres = new GestionEncheres($bdd);
require_once(__DIR__ . '/../config/database.php');

class GestionnaireEncheres {
    private $connexion;
    
    public function __construct($connexion_bdd) {
        $this->connexion = $connexion_bdd;
    }
    
    // Créer une nouvelle enchère
    public function creerEnchere($produitId, $prixDepart, $dateDebut, $dateFin) {
        $stmt = $this->connexion->prepare("
            INSERT INTO encheres (produit_id, prix_depart, prix_actuel, date_debut, date_fin, statut)
            VALUES (?, ?, ?, ?, ?, 'en_attente')
        ");
        
        $stmt->bind_param("dddss", $produitId, $prixDepart, $prixDepart, $dateDebut, $dateFin);
        
        if (!$stmt->execute()) {
            return ['succes' => false, 'message' => 'Erreur lors de la création de l\'enchère'];
        }
        
        return ['succes' => true, 'id' => $stmt->insert_id];
    }
    
    // Placer une enchère
    public function placerEnchere($enchereId, $utilisateurId, $montant) {
        // Vérifier si l'enchère est toujours active
        $stmt = $this->connexion->prepare("
            SELECT e.*, p.nom as nom_produit 
            FROM encheres e
            JOIN produits p ON e.produit_id = p.id
            WHERE e.id = ? AND e.statut = 'active'
            AND NOW() BETWEEN e.date_debut AND e.date_fin
        ");
        
        $stmt->bind_param("i", $enchereId);
        $stmt->execute();
        $resultat = $stmt->get_result();
        
        if ($resultat->num_rows === 0) {
            return ['succes' => false, 'message' => 'Cette enchère n\'est pas active'];
        }
        
        $enchere = $resultat->fetch_assoc();
        
        // Vérifier si le montant est supérieur au prix actuel
        if ($montant <= $enchere['prix_actuel']) {
            return ['succes' => false, 'message' => 'Le montant doit être supérieur à l\'enchère actuelle'];
        }
        
        // Enregistrer l'enchère
        $this->connexion->begin_transaction();
        
        try {
            // Mettre à jour le prix actuel
            $stmt = $this->connexion->prepare("
                UPDATE encheres 
                SET prix_actuel = ?, gagnant_id = ?
                WHERE id = ?
            ");
            $stmt->bind_param("dii", $montant, $utilisateurId, $enchereId);
            $stmt->execute();
            
            // Enregistrer l'offre
            $stmt = $this->connexion->prepare("
                INSERT INTO offres (enchere_id, utilisateur_id, montant)
                VALUES (?, ?, ?)
            ");
            $stmt->bind_param("iid", $enchereId, $utilisateurId, $montant);
            $stmt->execute();
            
            // Notifier l'ancien meilleur enchérisseur
            if ($enchere['gagnant_id'] && $enchere['gagnant_id'] != $utilisateurId) {
                $this->creerNotification(
                    $enchere['gagnant_id'],
                    'Surenchère',
                    "Quelqu'un a surenchéri sur {$enchere['nom_produit']}",
                    'enchere'
                );
            }
            
            $this->connexion->commit();
            return ['succes' => true, 'message' => 'Enchère placée avec succès'];
            
        } catch (Exception $e) {
            $this->connexion->rollback();
            return ['succes' => false, 'message' => 'Erreur lors de l\'enregistrement de l\'enchère'];
        }
    }
    
    // Obtenir les enchères actives
    public function obtenirEncheresActives($limite = 10) {
        $stmt = $this->connexion->prepare("
            SELECT e.*, p.nom, p.description, pi.chemin_image,
                   COUNT(DISTINCT o.id) as nombre_offres
            FROM encheres e
            JOIN produits p ON e.produit_id = p.id
            LEFT JOIN images_produits pi ON p.id = pi.produit_id AND pi.est_principale = 1
            LEFT JOIN offres o ON e.id = o.enchere_id
            WHERE e.statut = 'active'
            AND NOW() BETWEEN e.date_debut AND e.date_fin
            GROUP BY e.id
            ORDER BY e.date_fin ASC
            LIMIT ?
        ");
        
        $stmt->bind_param("i", $limite);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Obtenir le détail d'une enchère
    public function obtenirDetailEnchere($enchereId) {
        $stmt = $this->connexion->prepare("
            SELECT e.*, p.nom, p.description, pi.chemin_image,
                   u.prenom as gagnant_prenom, u.nom as gagnant_nom,
                   COUNT(DISTINCT o.id) as nombre_offres
            FROM encheres e
            JOIN produits p ON e.produit_id = p.id
            LEFT JOIN images_produits pi ON p.id = pi.produit_id AND pi.est_principale = 1
            LEFT JOIN utilisateurs u ON e.gagnant_id = u.id
            LEFT JOIN offres o ON e.id = o.enchere_id
            WHERE e.id = ?
            GROUP BY e.id
        ");
        
        $stmt->bind_param("i", $enchereId);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_assoc();
    }
    
    // Obtenir l'historique des offres
    public function obtenirHistoriqueOffres($enchereId) {
        $stmt = $this->connexion->prepare("
            SELECT o.*, u.prenom, u.nom
            FROM offres o
            JOIN utilisateurs u ON o.utilisateur_id = u.id
            WHERE o.enchere_id = ?
            ORDER BY o.montant DESC
        ");
        
        $stmt->bind_param("i", $enchereId);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Créer une notification
    private function creerNotification($utilisateurId, $titre, $message, $type) {
        $stmt = $this->connexion->prepare("
            INSERT INTO notifications (utilisateur_id, titre, message, type)
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->bind_param("isss", $utilisateurId, $titre, $message, $type);
        $stmt->execute();
    }
}

// Créer une instance du gestionnaire d'enchères
$gestionnaireEncheres = new GestionnaireEncheres($conn);
?>

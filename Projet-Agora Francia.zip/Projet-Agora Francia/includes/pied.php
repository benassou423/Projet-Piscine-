<footer class="bg-light mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h5>À propos d'Agora Francia</h5>
                <p>Une plateforme de commerce en ligne inspirée du marché grec antique, offrant une expérience unique d'achat et de vente.</p>
            </div>
            
            <div class="col-md-4 mb-4">
                <h5>Liens Rapides</h5>
                <ul class="list-unstyled">
                    <li><a href="/pages/about.php" class="text-decoration-none">À Propos</a></li>
                    <li><a href="/pages/contact.php" class="text-decoration-none">Contact</a></li>
                    <li><a href="/pages/terms.php" class="text-decoration-none">Conditions d'Utilisation</a></li>
                    <li><a href="/pages/privacy.php" class="text-decoration-none">Politique de Confidentialité</a></li>
                    <li><a href="/pages/faq.php" class="text-decoration-none">FAQ</a></li>
                </ul>
            </div>
            
            <div class="col-md-4 mb-4">
                <h5>Newsletter</h5>
                <p>Restez informé de nos dernières offres et nouveautés.</p>
                <form id="newsletterForm" class="mb-3">
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Votre email" required>
                        <button class="btn btn-primary" type="submit">S'abonner</button>
                    </div>
                </form>
                <div class="social-links">
                    <a href="#" class="text-decoration-none me-2"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-decoration-none me-2"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="text-decoration-none me-2"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-decoration-none"><i class="bi bi-linkedin"></i></a>
                </div>
            </div>
        </div>
        
        <hr>
        
        <div class="row">
            <div class="col text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Agora Francia. Tous droits réservés.</p>
            </div>
        </div>
    </div>
</footer>

<!-- Toast container for notifications -->
<div class="toast-container position-fixed bottom-0 end-0 p-3"></div>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">

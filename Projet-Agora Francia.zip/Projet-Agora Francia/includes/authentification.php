<?php
session_start();
require_once __DIR__ . '/../config/base_donnees.php';

// Classe d'authentification pour gérer les opérations liées aux utilisateurs
class Authentification {
    private $bdd;
    
    public function __construct($bdd) {
        $this->bdd = $bdd;
    }
    
    // Connecter l'utilisateur
    public function connexion($email, $motDePasse) {
        $stmt = $this->bdd->prepare("
            SELECT id_utilisateur, email, mot_de_passe, prenom, nom, type_utilisateur 
            FROM utilisateurs 
            WHERE email = ?
        ");
        
        $stmt->execute([$email]);
        $utilisateur = $stmt->fetch();
        
        if (!$utilisateur) {
            return ['succes' => false, 'message' => 'Utilisateur non trouvé'];
        }
        
        if (!password_verify($motDePasse, $utilisateur['mot_de_passe'])) {
            return ['succes' => false, 'message' => 'Mot de passe incorrect'];
        }
        
        // Définir les variables de session
        $_SESSION['utilisateur_id'] = $utilisateur['id_utilisateur'];
        $_SESSION['email'] = $utilisateur['email'];
        $_SESSION['type_utilisateur'] = $utilisateur['type_utilisateur'];
        $_SESSION['nom_complet'] = $utilisateur['prenom'] . ' ' . $utilisateur['nom'];
        
        return ['succes' => true, 'utilisateur' => $utilisateur];
    }
    
    // Inscrire un nouvel utilisateur    
    public function inscription($donneesUtilisateur) {
        if (!filter_var($donneesUtilisateur['email'], FILTER_VALIDATE_EMAIL)) {
            return ['succes' => false, 'message' => 'Email invalide'];
        }
        
        try {
            // Vérifier si l'email existe déjà
            $stmt = $this->bdd->prepare("SELECT id_utilisateur FROM utilisateurs WHERE email = ?");
            $stmt->execute([$donneesUtilisateur['email']]);
            if ($stmt->fetch()) {
                return ['succes' => false, 'message' => 'Email déjà utilisé'];
            }
            
            // Commencer une transaction
            $this->bdd->beginTransaction();
            
            // Insérer l'adresse
            $stmtAdresse = $this->bdd->prepare("
                INSERT INTO adresses (ligne1, ligne2, ville, code_postal, pays, telephone)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $stmtAdresse->execute([
                $donneesUtilisateur['adresse_ligne1'],
                $donneesUtilisateur['adresse_ligne2'],
                $donneesUtilisateur['ville'],
                $donneesUtilisateur['code_postal'],
                $donneesUtilisateur['pays'],
                $donneesUtilisateur['telephone']
            ]);
            
            $idAdresse = $this->bdd->lastInsertId();
            
            // Hasher le mot de passe
            $motDePasseHash = password_hash($donneesUtilisateur['mot_de_passe'], PASSWORD_DEFAULT);
            
            // Insérer l'utilisateur
            $stmtUtilisateur = $this->bdd->prepare("
                INSERT INTO utilisateurs (email, mot_de_passe, nom, prenom, type_utilisateur, id_adresse)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $stmtUtilisateur->execute([
                $donneesUtilisateur['email'],
                $motDePasseHash,
                $donneesUtilisateur['nom'],
                $donneesUtilisateur['prenom'],
                $donneesUtilisateur['type_utilisateur'],
                $idAdresse
            ]);
            
            // Valider la transaction
            $this->bdd->commit();
            
            return ['succes' => true, 'message' => 'Inscription réussie'];
            
        } catch (Exception $e) {
            $this->bdd->rollBack();
            return ['succes' => false, 'message' => 'Erreur lors de l\'inscription: ' . $e->getMessage()];
        }
    }
    
    // Déconnecter l'utilisateur
    public function deconnexion() {
        session_destroy();
        return true;
    }
    
    // Vérifier si l'utilisateur est connecté
    public function estConnecte() {
        return isset($_SESSION['utilisateur_id']);
    }
    
    // Vérifier si l'utilisateur est administrateur
    public function estAdmin() {
        return isset($_SESSION['type_utilisateur']) && $_SESSION['type_utilisateur'] === 'admin';
    }
    
    // Vérifier si l'utilisateur est vendeur
    public function estVendeur() {
        return isset($_SESSION['type_utilisateur']) && 
               ($_SESSION['type_utilisateur'] === 'vendeur' || $_SESSION['type_utilisateur'] === 'admin');
    }
    
    // Obtenir les données de l'utilisateur courant
    public function obtenirUtilisateurCourant() {
        if (!$this->estConnecte()) {
            return null;
        }
        
        $stmt = $this->bdd->prepare("
            SELECT u.id_utilisateur, u.email, u.prenom, u.nom, u.type_utilisateur,
                   a.ligne1 as adresse_ligne1, a.ligne2 as adresse_ligne2, 
                   a.ville, a.code_postal, a.pays, a.telephone
            FROM utilisateurs u
            LEFT JOIN adresses a ON u.id_adresse = a.ID_adresse
            WHERE u.id_utilisateur = ?
        ");
        
        $stmt->execute([$_SESSION['utilisateur_id']]);
        return $stmt->fetch();
    }
}

// Créer une instance d'authentification
$auth = new Authentification($bdd);
?>

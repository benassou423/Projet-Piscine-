<?php
session_start();
$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', 'root');
$db_found = mysqli_select_db($db_handle, $database);

if (!isset($_SESSION['user_id'])) {
    header('Location: compte.php');
    exit();
}

$acheteur_id = intval($_SESSION['user_id']);
$message = "";

// Chercher ou créer le panier de l'utilisateur
$sql = "SELECT id FROM Panier WHERE acheteur_id=$acheteur_id";
$result = mysqli_query($db_handle, $sql);
if ($result && mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $panier_id = $row['id'];
} else {
    $sql = "INSERT INTO Panier (acheteur_id, date_creation) VALUES ($acheteur_id, NOW())";
    mysqli_query($db_handle, $sql);
    $panier_id = mysqli_insert_id($db_handle);
}

// Supprimer un article du panier si demandé
if (isset($_GET['suppr']) && is_numeric($_GET['suppr'])) {
    $article_id = intval($_GET['suppr']);
    $sql = "DELETE FROM ArticlePanier WHERE panier_id=$panier_id AND article_id=$article_id";
    mysqli_query($db_handle, $sql);
    $message = "Article retiré du panier.";
}

// Récupérer tous les articles du panier
$articles = [];
$sql = "SELECT ap.article_id, ap.mode_achat, a.titre, a.photo, a.prix_initial, a.type_vente, a.statut
        FROM ArticlePanier ap
        JOIN Article a ON ap.article_id = a.id
        WHERE ap.panier_id = $panier_id";
$result = mysqli_query($db_handle, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $articles[] = $row;
}

// Valider le paiement du panier (achat immédiat seulement)
if (isset($_POST['valider_panier']) && $db_found) {
    $achats_ok = 0;
    foreach ($articles as $art) {
        if ($art['type_vente'] == 'immediat' && $art['statut'] == 'disponible') {
            $article_id = intval($art['article_id']);
            $montant = floatval($art['prix_initial']);
            $date = date('Y-m-d H:i:s');
            // Mettre l'article comme vendu
            $sql1 = "UPDATE Article SET statut='vendu' WHERE id=$article_id";
            // Créer la transaction
            $sql2 = "INSERT INTO Transaction (acheteur_id, article_id, montant, mode_paiement, date_paiement)
                     VALUES ($acheteur_id, $article_id, $montant, 'carte', '$date')";
            if (mysqli_query($db_handle, $sql1) && mysqli_query($db_handle, $sql2)) {
                $achats_ok++;
                // Retirer du panier
                $sql3 = "DELETE FROM ArticlePanier WHERE panier_id=$panier_id AND article_id=$article_id";
                mysqli_query($db_handle, $sql3);
            }
        }
    }
    if ($achats_ok > 0) {
        $message = "$achats_ok article(s) acheté(s) avec succès !";
    } else {
        $message = "Aucun article disponible à l'achat immédiat.";
    }
    // Refresh pour afficher le panier à jour
    header("Location: panier.php?msg=".urlencode($message));
    exit();
}

if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon Panier | Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .panier-img { max-width: 100px; max-height: 80px; object-fit: contain; background: #f9f9f9; }
    </style>
</head>
<body>
<div class="container my-4">
    <h2 class="mb-4 text-primary text-center">Mon Panier</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>
    <?php if (empty($articles)): ?>
        <p class="text-center">Votre panier est vide.</p>
    <?php else: ?>
    <form method="post">
        <table class="table table-bordered align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>Image</th>
                    <th>Titre</th>
                    <th>Type d'achat</th>
                    <th>Prix (€)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $total = 0; foreach ($articles as $art): ?>
                <tr>
                    <td>
                        <?php if ($art['photo']): ?>
                            <img src="<?= $art['photo'] ?>" class="panier-img" alt="">
                        <?php else: ?>
                            <img src="images/placeholder.png" class="panier-img" alt="">
                        <?php endif; ?>
                    </td>
                    <td><?= $art['titre'] ?></td>
                    <td><?= $art['mode_achat'] ?></td>
                    <td>
                        <?php
                        if ($art['type_vente'] == 'immediat' && $art['statut'] == 'disponible') {
                            $total += $art['prix_initial'];
                            echo number_format($art['prix_initial'], 2, ',', ' ');
                        } else {
                            echo "-";
                        }
                        ?>
                    </td>
                    <td>
                        <a href="panier.php?suppr=<?= $art['article_id'] ?>" class="btn btn-sm btn-outline-danger">Supprimer</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" class="text-end">Total (achat immédiat) :</th>
                    <th colspan="2"><?= number_format($total,2,',',' ') ?> €</th>
                </tr>
            </tfoot>
        </table>
        <?php if ($total > 0): ?>
            <button type="submit" name="valider_panier" class="btn btn-success w-100">Valider le paiement</button>
        <?php endif; ?>
    </form>
    <?php endif; ?>
    <a href="catalogue.php" class="btn btn-secondary mt-4">Retour au catalogue</a>
</div>
</body>
</html>

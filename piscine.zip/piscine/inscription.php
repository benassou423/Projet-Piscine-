<?php
session_start();
$database = "agora"; // Mets le nom réel ici
$db_handle = mysqli_connect('localhost', 'root', ''); // ou 'root', 'root' selon ta config locale
$db_found = mysqli_select_db($db_handle, $database);

$message = "";


if ($_SERVER['REQUEST_METHOD'] == 'POST' && $db_found) {
    // Récupération sécurisée des champs
    $nom      = mysqli_real_escape_string($db_handle, trim($_POST['nom']));
    $prenom   = mysqli_real_escape_string($db_handle, trim($_POST['prenom']));
    $email    = mysqli_real_escape_string($db_handle, trim($_POST['email']));
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $adresse1 = mysqli_real_escape_string($db_handle, trim($_POST['adresse1']));
    $adresse2 = mysqli_real_escape_string($db_handle, trim($_POST['adresse2']));
    $ville    = mysqli_real_escape_string($db_handle, trim($_POST['ville']));
    $cp       = mysqli_real_escape_string($db_handle, trim($_POST['code_postal']));
    $pays     = mysqli_real_escape_string($db_handle, trim($_POST['pays']));
    $tel      = mysqli_real_escape_string($db_handle, trim($_POST['telephone']));

    // Vérif mot de passe
    if ($password !== $password2) {
        $message = "Les mots de passe ne correspondent pas.";
    } else {
        // Email déjà utilisé ?
        $sql = "SELECT id FROM Utilisateur WHERE email = '$email'";
        $result = mysqli_query($db_handle, $sql);
        if (mysqli_num_rows($result) > 0) {
            $message = "Cet email est déjà utilisé.";
        } else {
            // Hash sécurisé
            $hash = password_hash($password, PASSWORD_BCRYPT);

            $sql = "INSERT INTO Utilisateur 
                (nom, prenom, email, mot_de_passe, role, adresse_ligne1, adresse_ligne2, ville, code_postal, pays, telephone)
                VALUES 
                ('$nom', '$prenom', '$email', '$hash', 'acheteur', '$adresse1', '$adresse2', '$ville', '$cp', '$pays', '$tel')";
            if (mysqli_query($db_handle, $sql)) {
                $message = "Inscription réussie ! Vous pouvez vous connecter.";
            } else {
                $message = "Erreur lors de l'inscription : " . mysqli_error($db_handle);
            }
        }
    }
} elseif (!$db_found) {
    $message = "Base de données non trouvée.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription - Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Toujours Bootstrap en premier -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Puis TON style -->
<link rel="stylesheet" href="css/style.css">

    
</head>
<body>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Inscription Acheteur</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="mb-2"><input required name="nom" type="text" class="form-control" placeholder="Nom"></div>
        <div class="mb-2"><input required name="prenom" type="text" class="form-control" placeholder="Prénom"></div>
        <div class="mb-2"><input required name="email" type="email" class="form-control" placeholder="Email"></div>
        <div class="mb-2"><input required name="password" type="password" class="form-control" placeholder="Mot de passe"></div>
        <div class="mb-2"><input required name="password2" type="password" class="form-control" placeholder="Confirmer mot de passe"></div>
        <div class="mb-2"><input name="adresse1" type="text" class="form-control" placeholder="Adresse (ligne 1)"></div>
        <div class="mb-2"><input name="adresse2" type="text" class="form-control" placeholder="Adresse (ligne 2)"></div>
        <div class="mb-2"><input name="ville" type="text" class="form-control" placeholder="Ville"></div>
        <div class="mb-2"><input name="code_postal" type="text" class="form-control" placeholder="Code postal"></div>
        <div class="mb-2"><input name="pays" type="text" class="form-control" placeholder="Pays"></div>
        <div class="mb-3"><input name="telephone" type="text" class="form-control" placeholder="Téléphone"></div>
        <button type="submit" class="btn btn-primary w-100">S'inscrire</button>
    </form>
    <p class="mt-4 text-center">Déjà un compte ? <a href="connexion.php">Connexion</a></p>
</div>
</body>
</html>

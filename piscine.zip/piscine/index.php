<?php
session_start();
include_once "db.php";

// Sélection du jour : 6 derniers articles disponibles
$selection = [];
$sql_sel = "SELECT * FROM Article WHERE statut='disponible' ORDER BY date_creation DESC LIMIT 6";
$res_sel = mysqli_query($db_handle, $sql_sel);
while ($row = mysqli_fetch_assoc($res_sel)) {
    $selection[] = $row;
}

// Carrousel : 3 articles mis en avant (ou images à la main si tu préfères)
$carrousel = [];
$sql_car = "SELECT * FROM Article WHERE statut='disponible' ORDER BY RAND() LIMIT 3";
$res_car = mysqli_query($db_handle, $sql_car);
while ($row = mysqli_fetch_assoc($res_car)) {
    $carrousel[] = $row;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil | Agora Francia</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="wrapper">

    <!-- HEADER & NAVIGATION -->
    <?php include "header.php"; ?>

    <!-- Intro -->
    <div class="container my-5">
        <div class="row mb-4">
            <div class="col-lg-8 mx-auto">
                <h1 class="mb-3 text-primary text-center">Bienvenue sur Agora Francia</h1>
                <p class="lead text-center">
                    Agora Francia, c'est la plateforme d'achat, de vente et d'enchères la plus dynamique pour tous vos besoins en France. 
                    Découvrez chaque jour de nouveaux articles, profitez de ventes flash, ou remportez la meilleure offre !
                </p>
            </div>
        </div>

        <!-- CARROUSEL DES ARTICLES -->
        <div class="row mb-5">
            <div class="col-12">
                <div id="agoraCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php foreach ($carrousel as $i => $art): ?>
                        <div class="carousel-item <?= $i==0 ? "active" : "" ?>">
                            <img src="<?= $art['photo'] ?: 'images/placeholder.png' ?>" class="d-block w-100" style="max-height:420px; object-fit:cover;" alt="<?= $art['titre'] ?>">
                            <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded-3 p-2">
                                <h5><?= $art['titre'] ?></h5>
                                <p><?= substr($art['description'],0,50) ?>...</p>
                                <a href="article.php?id=<?= $art['id'] ?>" class="btn btn-primary btn-sm">Voir l'article</a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#agoraCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Précédent</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#agoraCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Suivant</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- SELECTION DU JOUR -->
        <div class="row mb-5">
            <h3 class="mb-3 text-center text-success">Sélection du jour</h3>
            <?php foreach ($selection as $art): ?>
                <div class="col-md-4 col-lg-2 mb-4">
                    <div class="card h-100 shadow-sm">
                        <img src="<?= $art['photo'] ?: 'images/placeholder.png' ?>" class="card-img-top" alt="<?= $art['titre'] ?>" style="max-height:110px;object-fit:contain;">
                        <div class="card-body">
                            <h6 class="card-title"><?= $art['titre'] ?></h6>
                            <p class="mb-2"><?= number_format($art['prix_initial'],2,',',' ') ?> €</p>
                            <a href="article.php?id=<?= $art['id'] ?>" class="btn btn-outline-primary btn-sm w-100">Voir</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php if (empty($selection)): ?>
                <div class="col-12 text-center"><em>Aucun article disponible pour le moment.</em></div>
            <?php endif; ?>
        </div>

        <!-- Coordonnées Contact -->
      
</div>
    <?php include "footer.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Administration - Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Espace Administration</h2>
    <ul>
        <li><a href="admin_gestion_vendeurs.php">Ajouter/Supprimer un vendeur</a></li>
        <li><a href="admin_gestion_utilisateurs.php">Gérer les utilisateurs</a></li>
        <li><a href="admin_gestion_articles.php">Gérer les articles</a></li>
        <li><a href="logout.php">Se déconnecter</a></li>

        <!-- Ajoute ici les liens vers les autres pages admin si besoin -->
    </ul>
    <a href="index.php" class="btn btn-secondary mt-4">Retour à l'accueil</a>
</div>
</body>
</html>

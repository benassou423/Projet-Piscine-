<?php
date_default_timezone_set('Europe/Paris');
session_start();
$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', 'root');
$db_found = mysqli_select_db($db_handle, $database);

$article = null;
$achat_message = "";
$enchere_message = "";
$nego_message = "";

// Récupération de l'article
$id = null;
if ($db_found) {
    if (isset($_POST['id']) && is_numeric($_POST['id'])) {
        $id = intval($_POST['id']);
    } elseif (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $id = intval($_GET['id']);
    }
    if ($id !== null) {
        $sql = "SELECT a.*, c.nom AS categorie, u.nom AS vendeur_nom, u.prenom AS vendeur_prenom, u.email AS vendeur_email
                FROM Article a
                JOIN Categorie c ON a.categorie_id = c.id
                JOIN Utilisateur u ON a.vendeur_id = u.id
                WHERE a.id = $id";
        $result = mysqli_query($db_handle, $sql);
        if ($result && mysqli_num_rows($result) == 1) {
            $article = mysqli_fetch_assoc($result);
        }
    }
}

// -------- ACHAT IMMEDIAT --------
if (
    $article &&
    isset($_POST['achat_direct']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id'] &&
    $article['type_vente'] == 'immediat' &&
    $article['statut'] == 'disponible'
) {
    $acheteur_id = intval($_SESSION['user_id']);
    $article_id = intval($article['id']);

    // Chercher ou créer le panier de l'utilisateur
    $sql = "SELECT id FROM Panier WHERE acheteur_id=$acheteur_id";
    $result = mysqli_query($db_handle, $sql);
    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $panier_id = $row['id'];
    } else {
        $sql = "INSERT INTO Panier (acheteur_id, date_creation) VALUES ($acheteur_id, NOW())";
        mysqli_query($db_handle, $sql);
        $panier_id = mysqli_insert_id($db_handle);
    }
    // Ajouter l'article au panier (si pas déjà présent)
    $sql = "SELECT * FROM ArticlePanier WHERE panier_id=$panier_id AND article_id=$article_id";
    $result = mysqli_query($db_handle, $sql);
    if (!$result || mysqli_num_rows($result) == 0) {
        $sql = "INSERT INTO ArticlePanier (panier_id, article_id, mode_achat)
                VALUES ($panier_id, $article_id, 'immediat')";
        mysqli_query($db_handle, $sql);
    }
    header("Location: panier.php");
    exit();
}

// -------- ENCHERE --------
$maintenant = date('Y-m-d H:i:s');
$en_cours = false;
if ($article && $article['type_vente'] == 'enchere') {
    $en_cours = ($maintenant >= $article['date_debut_enchere'] && $maintenant <= $article['date_fin_enchere']);
}
if (
    $article &&
    $article['type_vente'] == 'enchere' &&
    $en_cours &&
    isset($_POST['placer_enchere']) &&
    isset($_POST['prix_max']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id']
) {
    $prix_max = floatval($_POST['prix_max']);
    $acheteur_id = intval($_SESSION['user_id']);
    $article_id = intval($article['id']);
    $prix_actuel = floatval($article['prix_actuel']);
    if ($prix_max < $prix_actuel + 1) {
        $enchere_message = "Votre enchère maximum doit être supérieure au prix actuel.";
    } else {
        // Cherche si déjà enchère
        $sql = "SELECT id FROM Enchere WHERE article_id=$article_id AND acheteur_id=$acheteur_id";
        $result = mysqli_query($db_handle, $sql);
        if ($result && mysqli_num_rows($result) > 0) {
            $sql = "UPDATE Enchere SET prix_max=$prix_max, date_enchere=NOW() WHERE article_id=$article_id AND acheteur_id=$acheteur_id";
            mysqli_query($db_handle, $sql);
            $enchere_message = "Votre enchère maximum a été modifiée.";
        } else {
            $sql = "INSERT INTO Enchere (article_id, acheteur_id, prix_max, date_enchere)
                    VALUES ($article_id, $acheteur_id, $prix_max, NOW())";
            mysqli_query($db_handle, $sql);
            $enchere_message = "Votre enchère a bien été enregistrée.";
        }
        // Notif vendeur
        $vendeur_id = $article['vendeur_id'];
        $acheteur_nom = $_SESSION['user_prenom']." ".$_SESSION['user_nom'];
        $contenu = "Nouvelle enchère de $acheteur_nom sur l'article : ".$article['titre']." (offre max : ".number_format($prix_max,2,',',' ')." €)";
        $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
        $date_notif = date('Y-m-d H:i:s');
      $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
              VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";


        mysqli_query($db_handle, $sql_notif);

        // Proxy-bid: maj prix actuel
        $sql = "SELECT prix_max FROM Enchere WHERE article_id=$article_id ORDER BY prix_max DESC, date_enchere ASC";
        $result = mysqli_query($db_handle, $sql);
        $prix1 = $prix2 = $article['prix_initial'];
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $prix1 = $row['prix_max'];
            if (mysqli_num_rows($result) > 1) {
                $row2 = mysqli_fetch_assoc($result);
                $prix2 = $row2['prix_max'];
            }
        }
        $nouveau_prix = ($prix1 && $prix2 && $prix2 + 1 > $article['prix_initial']) ? $prix2 + 1 : max($article['prix_initial'], $prix1);
        $sql = "UPDATE Article SET prix_actuel=$nouveau_prix WHERE id=$article_id";
        mysqli_query($db_handle, $sql);
        // Recharge l'article
        $sql = "SELECT a.*, c.nom AS categorie, u.nom AS vendeur_nom, u.prenom AS vendeur_prenom, u.email AS vendeur_email
                FROM Article a
                JOIN Categorie c ON a.categorie_id = c.id
                JOIN Utilisateur u ON a.vendeur_id = u.id
                WHERE a.id = $article_id";
        $result = mysqli_query($db_handle, $sql);
        if ($result && mysqli_num_rows($result) == 1) {
            $article = mysqli_fetch_assoc($result);
        }
    }
}

// -------- NEGOCIATION --------
// Acheteur propose une offre
if (
    $article &&
    $article['type_vente'] == 'negociation' &&
    isset($_POST['faire_offre']) &&
    isset($_POST['prix_offre']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id']
) {
    $acheteur_id = intval($_SESSION['user_id']);
    $vendeur_id = intval($article['vendeur_id']);
    $article_id = intval($article['id']);
    $prix_offre = floatval($_POST['prix_offre']);
    // Cherche négociation en cours
    $sql = "SELECT * FROM Negociation WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND etat='en cours' ORDER BY tour DESC LIMIT 1";
    $res = mysqli_query($db_handle, $sql);
    if ($res && mysqli_num_rows($res) > 0) {
        $nego = mysqli_fetch_assoc($res);
        if ($nego['tour'] >= 5) {
            $nego_message = "Vous avez atteint la limite de 5 tentatives de négociation.";
            // Notification au vendeur


        } else {
            $tour = $nego['tour'] + 1;
            $sql2 = "INSERT INTO Negociation (article_id, acheteur_id, vendeur_id, tour, offre_acheteur, date_action) 
                     VALUES ($article_id, $acheteur_id, $vendeur_id, $tour, $prix_offre, NOW())";
            mysqli_query($db_handle, $sql2);
            $nego_message = "Votre nouvelle offre a été soumise au vendeur.";
            // Notification au vendeur
if (isset($vendeur_id)) {
    $acheteur_nom = $_SESSION['user_prenom'] . " " . $_SESSION['user_nom'];
    $contenu = "Nouvelle offre de $acheteur_nom sur l'article : " . $article['titre'] . " (" . number_format($prix_offre,2,',',' ') . " €)";
    $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
    $date_notif = date('Y-m-d H:i:s');
  $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
              VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";

    mysqli_query($db_handle, $sql_notif);
}

        }
    } else {
        $sql2 = "INSERT INTO Negociation (article_id, acheteur_id, vendeur_id, tour, offre_acheteur, date_action) 
                 VALUES ($article_id, $acheteur_id, $vendeur_id, 1, $prix_offre, NOW())";
        mysqli_query($db_handle, $sql2);
        $nego_message = "Votre offre a été soumise au vendeur.";
    }
}
if (
    $article &&
    $article['type_vente'] == 'negociation' &&
    isset($_POST['accept_contre_offre']) &&
    isset($_POST['tour']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] != $article['vendeur_id']
) {
    $acheteur_id = intval($_SESSION['user_id']);
    $tour = intval($_POST['tour']);
    $article_id = intval($article['id']);

    // Marque la négo comme acceptée, notif vendeur, article vendu
    $sql = "UPDATE Negociation SET etat='accepte' WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
    mysqli_query($db_handle, $sql);

    $sql2 = "UPDATE Article SET statut='vendu' WHERE id=$article_id";
    mysqli_query($db_handle, $sql2);

    $nego_message = "Vous avez accepté la contre-offre du vendeur !";

    // NOTIF vendeur
    $contenu = "L'acheteur a accepté votre contre-offre sur l'article « " . $article['titre'] . " » !";
    $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
    $date_notif = date('Y-m-d H:i:s');
    $vendeur_id = intval($article['vendeur_id']);
    $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
                  VALUES ($vendeur_id, '$contenu_sql', '$date_notif', $article_id)";
    mysqli_query($db_handle, $sql_notif);
}


// Vendeur répond (accepte, refuse, contre-offre)
if (
    $article &&
    $article['type_vente'] == 'negociation' &&
    isset($_POST['repondre_nego']) &&
    isset($_SESSION['user_id']) &&
    $_SESSION['user_id'] == $article['vendeur_id'] &&
    isset($_POST['acheteur_id']) &&
    isset($_POST['tour'])
) {
    $acheteur_id = intval($_POST['acheteur_id']);
    $tour = intval($_POST['tour']);
    $article_id = intval($article['id']);

    if (isset($_POST['accepter'])) {
        $sql = "UPDATE Negociation SET etat='accepte' WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
        mysqli_query($db_handle, $sql);
        $nego_message = "Vous avez accepté l'offre de l'acheteur !";

    // NOTIF à l'acheteur
    $contenu = "Votre offre sur l'article « " . $article['titre'] . " » a été refusée par le vendeur.";
    $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
    $date_notif = date('Y-m-d H:i:s');
 $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
              VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";

    mysqli_query($db_handle, $sql_notif);
         // NOTIF à l'acheteur
    $sql_user = "SELECT prenom, nom FROM Utilisateur WHERE id=$acheteur_id";
    $res_user = mysqli_query($db_handle, $sql_user);
    $a = mysqli_fetch_assoc($res_user);
    $nom_acheteur = $a ? $a['prenom'] . " " . $a['nom'] : "Acheteur";
    $contenu = "Votre offre sur l'article « " . $article['titre'] . " » a été acceptée par le vendeur !";
    $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
    $date_notif = date('Y-m-d H:i:s');
 $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
              VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";

    mysqli_query($db_handle, $sql_notif);
    } elseif (isset($_POST['refuser'])) {
        $sql = "UPDATE Negociation SET etat='refuse' WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
        mysqli_query($db_handle, $sql);
        $nego_message = "Vous avez refusé l'offre.";
    } elseif (isset($_POST['contre_offre']) && isset($_POST['prix_contre_offre'])) {
        $prix_contre = floatval($_POST['prix_contre_offre']);
        $sql = "UPDATE Negociation SET contre_offre_vendeur=$prix_contre WHERE article_id=$article_id AND acheteur_id=$acheteur_id AND tour=$tour";
        mysqli_query($db_handle, $sql);
        $nego_message = "Votre contre-offre a été envoyée à l'acheteur.";
           // NOTIF à l'acheteur
    $contenu = "Le vendeur a fait une contre-offre (" . number_format($prix_contre,2,',',' ') . " €) sur l'article « " . $article['titre'] . " ». Consultez votre historique de négociation !";
    $contenu_sql = mysqli_real_escape_string($db_handle, $contenu);
    $date_notif = date('Y-m-d H:i:s');
    $sql_notif = "INSERT INTO Notification (user_id, contenu, date_creation, article_id)
              VALUES ($acheteur_id, '$contenu_sql', '$date_notif', $article_id)";

    mysqli_query($db_handle, $sql_notif);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Article | Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .fiche-photo {max-width: 380px; max-height: 280px; object-fit: contain; background: #f9f9f9;}
        .fiche-bloc {background: #fff; border-radius: 10px; box-shadow: 0 0 8px #bbb; padding: 22px;}
    </style>
</head>
<body>
<div class="container my-4">
    <?php if (!$article): ?>
        <div class="alert alert-warning text-center">Article introuvable.</div>
        <a href="catalogue.php" class="btn btn-secondary">Retour au catalogue</a>
    <?php else: ?>
        <div class="row fiche-bloc">
            <div class="col-md-5 text-center">
                <?php if ($article['photo']): ?>
                    <img src="<?= $article['photo'] ?>" alt="photo article" class="fiche-photo img-fluid mb-3">
                <?php else: ?>
                    <img src="images/placeholder.png" alt="aperçu" class="fiche-photo img-fluid mb-3">
                <?php endif; ?>
            </div>
            <div class="col-md-7">
                <h2><?= $article['titre'] ?></h2>
                <span class="badge bg-info mb-2"><?= $article['categorie'] ?></span>
                <h4 class="text-success">
                    <?php
                    if ($article['type_vente'] == 'immediat') {
                        echo number_format($article['prix_initial'],2,',',' ') . " €";
                    } else {
                        echo number_format($article['prix_actuel'] ?? $article['prix_initial'], 2, ',', ' ');

                    }
                    ?>
                </h4>
                <p class="my-3"><?= nl2br($article['description']) ?></p>
                <ul class="mb-3 list-unstyled">
                    <li><strong>Type de vente :</strong> <?= $article['type_vente'] ?></li>
                    <li><strong>Vendeur :</strong> <?= $article['vendeur_prenom'].' '.$article['vendeur_nom'] ?> (<?= $article['vendeur_email'] ?>)</li>
                    <li><strong>Statut :</strong> <?= $article['statut'] ?></li>
                </ul>

                <!-- BLOC ACHAT IMMÉDIAT -->
                <?php if (
                    $article['type_vente'] == 'immediat' &&
                    isset($_SESSION['user_id']) &&
                    $_SESSION['user_id'] != $article['vendeur_id'] &&
                    $article['statut'] == 'disponible'
                ): ?>
                    <form method="post" class="my-3">
                        <input type="hidden" name="id" value="<?= $article['id'] ?>">
                        <button type="submit" name="achat_direct" class="btn btn-success btn-lg">Acheter maintenant</button>
                    </form>
                <?php endif; ?>

                <!-- BLOC ENCHÈRE -->
                <?php if ($article['type_vente'] == 'enchere'): ?>
                    <div class="my-3">
                        <div>Enchère&nbsp;: <strong><?= $article['date_debut_enchere'] ?></strong> → <strong><?= $article['date_fin_enchere'] ?></strong></div>
                        <div>Prix actuel : <strong><?= number_format($article['prix_actuel'],2,',',' ') ?> €</strong></div>
                        <?php if ($en_cours): ?>
                            <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $article['vendeur_id']): ?>
                                <form method="post" class="mt-2">
                                    <input type="hidden" name="id" value="<?= $article['id'] ?>">
                                    <input type="number" name="prix_max" min="<?= $article['prix_actuel']+1 ?>" step="1" required placeholder="Votre enchère maximum (€)">
                                    <button type="submit" name="placer_enchere" class="btn btn-warning btn-sm">Placer mon enchère</button>
                                </form>
                                <?php if ($enchere_message): ?><div class="alert alert-info mt-2"><?= $enchere_message ?></div><?php endif; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="alert alert-secondary mt-2">Cette enchère est terminée ou pas encore ouverte.</div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- BLOC NEGOCIATION -->
                <?php if ($article['type_vente'] == 'negociation'): ?>
                    <div class="my-4 p-3 bg-light border rounded">
                        <h5 class="mb-3">Négociation</h5>
                        <?php if ($nego_message): ?>
                            <div class="alert alert-info"><?= $nego_message ?></div>
                        <?php endif; ?>

                        <!-- Historique des négociations -->
                        <?php
                        $nego_affichee = false;
                        if (isset($_SESSION['user_id'])) {
                            $user_id = intval($_SESSION['user_id']);
                            $sql = "SELECT * FROM Negociation WHERE article_id=$id AND (acheteur_id=$user_id OR vendeur_id=$user_id) ORDER BY tour ASC";
                            $res = mysqli_query($db_handle, $sql);
                            if ($res && mysqli_num_rows($res) > 0) {
                                echo '<table class="table table-sm"><thead><tr>
                                        <th>Tour</th><th>Offre acheteur</th><th>Contre-offre vendeur</th><th>Etat</th><th>Date</th>
                                    </tr></thead><tbody>';
                                while ($n = mysqli_fetch_assoc($res)) {
                                    echo "<tr>
                                        <td>{$n['tour']}</td>
                                        <td>" . ($n['offre_acheteur'] ? number_format($n['offre_acheteur'],2,',',' ') . " €" : "-") . "</td>
                                        <td>" . ($n['contre_offre_vendeur'] ? number_format($n['contre_offre_vendeur'],2,',',' ') . " €" : "-") . "</td>
                                        <td>{$n['etat']}</td>
                                        <td>{$n['date_action']}</td>
                                    </tr>";
                                }
                                echo '</tbody></table>';
                                $nego_affichee = true;
                            }
                        }

                        // Formulaire pour l'acheteur
                        if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $article['vendeur_id']) {
                            $sql = "SELECT * FROM Negociation WHERE article_id=$id AND acheteur_id={$_SESSION['user_id']} ORDER BY tour DESC LIMIT 1";
                            $res = mysqli_query($db_handle, $sql);
                            $nego = $res && mysqli_num_rows($res) ? mysqli_fetch_assoc($res) : null;

                            // 1. Si contre-offre du vendeur, proposer le bouton accepter la contre-offre
if ($nego && $nego['etat'] == 'en cours' && $nego['contre_offre_vendeur'] && $nego['contre_offre_vendeur'] > 0) {
    echo '<div class="alert alert-warning mb-2">
            Le vendeur vous propose une contre-offre de <b>' . number_format($nego['contre_offre_vendeur'],2,',',' ') . ' €</b>.
          </div>
          <form method="post" class="d-inline-block me-2">
            <input type="hidden" name="accept_contre_offre" value="1">
            <input type="hidden" name="tour" value="'.$nego['tour'].'">
            <button type="submit" class="btn btn-success btn-sm">Accepter la contre-offre</button>
          </form>';
    // (optionnel) bouton pour refuser ou proposer encore si tours restants
}


                            if (!$nego || ($nego['etat'] == 'en cours' && $nego['tour'] < 5 && $nego['contre_offre_vendeur'])) {
                                echo '<form method="post" class="mt-3">
                                    <div class="input-group">
                                        <input type="number" name="prix_offre" step="0.01" min="0" class="form-control" placeholder="Votre offre (€)" required>
                                        <button type="submit" name="faire_offre" class="btn btn-success">Proposer</button>
                                    </div>
                                </form>';
                            } elseif ($nego && $nego['etat'] == 'en cours' && !$nego['contre_offre_vendeur']) {
                                echo '<div class="alert alert-secondary">Offre en attente de réponse du vendeur.</div>';
                            } elseif ($nego && $nego['etat'] == 'accepte') {
                                echo '<div class="alert alert-success">Votre offre a été acceptée ! L\'article est à vous.</div>';
                            } elseif ($nego && $nego['etat'] == 'refuse') {
                                echo '<div class="alert alert-danger">Votre offre a été refusée.</div>';
                            }
                        }

                        // Formulaire pour le vendeur
                        if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $article['vendeur_id']) {
                            $sql = "SELECT * FROM Negociation WHERE article_id=$id AND etat='en cours' AND (contre_offre_vendeur IS NULL OR contre_offre_vendeur=0) ORDER BY date_action ASC LIMIT 1";
                            $res = mysqli_query($db_handle, $sql);
                            if ($res && $nego = mysqli_fetch_assoc($res)) {
                                echo '<form method="post" class="mt-3">
                                    <input type="hidden" name="acheteur_id" value="'.$nego['acheteur_id'].'">
                                    <input type="hidden" name="tour" value="'.$nego['tour'].'">
                                    <div class="mb-2">
                                        <button type="submit" name="accepter" class="btn btn-success" name="repondre_nego">Accepter l\'offre ('.$nego['offre_acheteur'].' €)</button>
                                        <button type="submit" name="refuser" class="btn btn-danger" name="repondre_nego">Refuser</button>
                                    </div>
                                    <div class="input-group mb-2">
                                        <input type="number" name="prix_contre_offre" step="0.01" min="0" class="form-control" placeholder="Votre contre-offre (€)">
                                        <button type="submit" name="contre_offre" class="btn btn-warning" name="repondre_nego">Contre-offre</button>
                                    </div>
                                    <input type="hidden" name="repondre_nego" value="1">
                                </form>';
                            }
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <a href="catalogue.php" class="btn btn-secondary mt-2">Retour au catalogue</a>
            </div>
        </div>
    <?php endif; ?>
</div>
</body>
</html>

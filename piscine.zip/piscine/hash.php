<?php
echo password_hash('admin1234', PASSWORD_BCRYPT);
?>

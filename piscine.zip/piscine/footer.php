<footer class="footer" style="background:#e9eef7; font-size:0.97em; width:100vw; left:0; margin:0; padding:14px 0 8px 0; border-top:1px solid #b3c7e6;">
    <div class="text-center" style="color:#384072;">
        <div><strong>Email</strong> : agora.francia@email.fr</div>
        <div><strong>Téléphone</strong> : 01 23 45 67 89</div>
        <div><strong>Adresse</strong> : 10 avenue de la République, 75000 Paris</div>
        <div style="margin-top:2px;"><em>Notre équipe est à votre écoute du lundi au samedi de 8h à 20h.</em></div>
        <div style="margin-top:6px;">
            &copy; 2025 Agora Francia | Projet ECE Web Dynamique
        </div>
    </div>
</footer>

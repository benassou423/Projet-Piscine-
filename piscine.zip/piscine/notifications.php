<?php
session_start();
$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', 'root');
$db_found = mysqli_select_db($db_handle, $database);
// Marque toutes les notifs comme lues à l'ouverture de la page
$user_id = intval($_SESSION['user_id']);
mysqli_query($db_handle, "UPDATE Notification SET lu=1 WHERE user_id=$user_id AND lu=0");

// Marquer toutes les notifs comme lues
if (isset($_SESSION['user_id'])) {
    $user_id = intval($_SESSION['user_id']);
    mysqli_query($db_handle, "UPDATE Notification SET lu=1 WHERE user_id=$user_id AND lu=0");
}

// Puis ensuite, on les sélectionne pour les afficher
$sql = "SELECT * FROM Notification WHERE user_id=$user_id ORDER BY date_creation DESC";
$result = mysqli_query($db_handle, $sql);


$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM Notification WHERE user_id=$user_id ORDER BY date_creation DESC";
$result = mysqli_query($db_handle, $sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes notifications</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="text-primary">Mes notifications</h2>
    <a href="alertes.php" class="btn btn-outline-primary">
        + Créer une alerte
    </a>
</div>

</head>
<body>

<div class="container my-4">
    <h2>Notifications</h2>
<?php while ($notif = mysqli_fetch_assoc($result)): ?>
    <div class="alert <?= $notif['lu'] ? 'alert-secondary' : 'alert-info' ?>">
        <?= $notif['contenu'] ?><br>
        <small><?= $notif['date_creation'] ?></small>
        <?php if (!empty($notif['article_id'])): ?>
            <div>
                <a href="article.php?id=<?= $notif['article_id'] ?>" class="btn btn-link btn-sm p-0">Voir l'article</a>
            </div>
        <?php endif; ?>
    </div>
<?php endwhile; ?>

</div>
</body>
</html>

<?php
session_start();
// Sécurité : accès réservé à l’admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: compte.php');
    exit();
}

$database = "agora";
$db_handle = mysqli_connect('localhost', 'root', 'root');
$db_found = mysqli_select_db($db_handle, $database);

$message_ajout = "";

// Traitement ajout vendeur
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $db_found) {
    $nom      = mysqli_real_escape_string($db_handle, trim($_POST['nom']));
    $prenom   = mysqli_real_escape_string($db_handle, trim($_POST['prenom']));
    $email    = mysqli_real_escape_string($db_handle, trim($_POST['email']));
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    if ($password !== $password2) {
        $message_ajout = "Les mots de passe ne correspondent pas.";
    } else {
        // Vérifie si email déjà utilisé
        $sql = "SELECT id FROM Utilisateur WHERE email = '$email'";
        $result = mysqli_query($db_handle, $sql);
        if (mysqli_num_rows($result) > 0) {
            $message_ajout = "Cet email existe déjà !";
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $sql = "INSERT INTO Utilisateur 
                    (nom, prenom, email, mot_de_passe, role)
                    VALUES
                    ('$nom', '$prenom', '$email', '$hash', 'vendeur')";
            if (mysqli_query($db_handle, $sql)) {
                $message_ajout = "Vendeur ajouté avec succès !";
            } else {
                $message_ajout = "Erreur lors de l'ajout : " . mysqli_error($db_handle);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout de vendeur - Admin | Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h2 class="mb-4 text-primary text-center">Ajouter un vendeur</h2>
    <?php if ($message_ajout): ?>
        <div class="alert alert-info"><?= $message_ajout ?></div>
    <?php endif; ?>
    <form method="post" class="mb-5">
        <div class="mb-2"><input required name="nom" type="text" class="form-control" placeholder="Nom"></div>
        <div class="mb-2"><input required name="prenom" type="text" class="form-control" placeholder="Prénom"></div>
        <div class="mb-2"><input required name="email" type="email" class="form-control" placeholder="Email"></div>
        <div class="mb-2"><input required name="password" type="password" class="form-control" placeholder="Mot de passe"></div>
        <div class="mb-2"><input required name="password2" type="password" class="form-control" placeholder="Confirmer mot de passe"></div>
        <button type="submit" class="btn btn-success w-100">Créer le vendeur</button>
    </form>
    <a href="admin.php" class="btn btn-secondary">Retour à l’espace admin</a>
</div>
</body>
</html>

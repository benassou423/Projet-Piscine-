<?php
header('Content-Type: application/json');

$database = "agorafixe";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

$response = ['exists' => false, 'role' => null];

if ($db_found && isset($_GET['email'])) {
    $email = mysqli_real_escape_string($db_handle, $_GET['email']);
    $sql = "SELECT role FROM Utilisateur WHERE email = ?";
    $stmt = mysqli_prepare($db_handle, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($user = mysqli_fetch_assoc($result)) {
        $response['exists'] = true;
        $response['role'] = $user['role'];
    }
}

echo json_encode($response);
?>

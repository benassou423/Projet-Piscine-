<?php
date_default_timezone_set('Europe/Paris');
session_start();
include_once "db.php";

$achat_message = "";
$enchere_message = "";
$nego_message = "";

// Récupération de l'article
$article = null;
$id = null;
if ($db_found) {
    if (isset($_POST['id']) && is_numeric($_POST['id'])) {
        $id = intval($_POST['id']);
    } elseif (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $id = intval($_GET['id']);
    }
    if ($id !== null) {
        $sql = "SELECT a.*, c.nom AS categorie, u.nom AS vendeur_nom, u.prenom AS vendeur_prenom, u.email AS vendeur_email
                FROM Article a
                JOIN Categorie c ON a.categorie_id = c.id
                JOIN Utilisateur u ON a.vendeur_id = u.id
                WHERE a.id = $id";
        $result = mysqli_query($db_handle, $sql);
        if ($result && mysqli_num_rows($result) == 1) {
            $article = mysqli_fetch_assoc($result);
        }
    }
}

if ($article) {
    if ($article['type_vente'] == 'immediat') {
        include_once "actions/action_achat.php";
    } elseif ($article['type_vente'] == 'enchere') {
        include_once "actions/action_enchere.php";
    } elseif ($article['type_vente'] == 'negociation') {
        include_once "actions/action_nego.php";
    }
}
?>

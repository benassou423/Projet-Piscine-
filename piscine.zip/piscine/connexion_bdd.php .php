<?php
// connexion_bdd.php (mysqli procédural)
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'agora_francia';

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die('Erreur de connexion à la base de données : ' . mysqli_connect_error());
}
?>
